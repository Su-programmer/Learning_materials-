/*********************************************************
*
*********************************************************/
#include <stdlib/ks_stdint.h>

#include <tools/macros.h>

#include <config.h>
#include <allocate.h>
#include <task.h>
#include <schedule.h>
#include <dprintf.h>
#include <idle.h>
#include <interrupt.h>
#include <timer.h>
#include <test.h>
#include <addrspace.h>
#include <smp.h>

#include <caps/capability.h>

#include <uapi/initialcaps.h>

#include <arch/cpu.h>
#include <arch/systick.h>

#include <plat/platform.h>
#include <plat/dputchar.h>
#include <plat/clock.h>
#include <timer_count.h>
static void BOOTONLY early_init(void)
{
    clock_init(CONFIG_CORE_CLOCK);
    dputchar_init();
    dprintf("dprintf initialised\n");
}

tcb_t *BOOTONLY create_idle_task(void)
{
    extern int idlestack;

#ifdef CONFIG_ENABLE_SMP
    static tcb_t task_idle[CONFIG_SMP_CORES];
    unsigned int coreid = current_cpu();
    tcb_t *pidle = task_idle + coreid;
    void *pstack = (char *)&idlestack + coreid * CONFIG_STACK_SIZE;
#else
    static tcb_t pidle[1];
    void *pstack = &idlestack;
#endif

    task_init(pidle, TTYPE_KERNEL);
    tcb_get(pidle);

    task_set_entry(pidle, (unsigned long)idle);
    task_set_stack(pidle, pstack, 0, CONFIG_STACK_SIZE);
    task_set_state(pidle, TASK_IDLE);
    task_set_name(pidle, "idle");
    task_set_addrspace(pidle, kernel_addrspace());
    task_set_maxpriority(pidle, CONFIG_MAX_PRIORITY - 1);
    task_set_priority(pidle, CONFIG_MAX_PRIORITY - 1);

    return pidle;
}

tcb_t *BOOTONLY create_init_task(void)
{
    static tcb_t tinit;
    static endpoint_t faulthandler;
    static struct __stack_ipcbuffer
    {
        char stack[CONFIG_STACK_SIZE];
        ipcbuffer_t buf;
    } ALIGNED(CONFIG_STACK_SIZE) init_si;

    tcb_t *pinit = &tinit;
    addrspace_t *as;
    void *stack = (void *)init_si.stack;
    ipcbuffer_t *ipcbuf = &init_si.buf;
    bootinfo_t *bi = &ipcbuf->bi;

    bi->ipcbuffer = bi;
    dprintf("create bi addr: %d \n", bi);
    dprintf("create ipcbuffer addr: %d \n", bi->ipcbuffer);
    bi->ipcbufferlen = sizeof(ipcbuffer_t);
    bi->stack = stack;
    bi->stacklen = CONFIG_STACK_SIZE;
    bi->radix = CONFIG_INITIAL_CNODE_RADIX;
    bi->guardlen = 4;
    bi->guard = lowbitsmask(bi->guardlen);
    bi->freeindex = CAP_INDEX_COUNT;
    bi->caps_size = cap_get_capobj_size();

    task_init(pinit, TTYPE_USER);
    tcb_get(pinit); // make sure the pinit won't be freed

    task_set_stack(pinit, bi->stack, bi->ipcbuffer, bi->stacklen);
    task_set_entry(pinit, CONFIG_ROOTSERVER_EXEC_ADDR);
    task_set_retcode(pinit, (unsigned long)bi);
    task_set_priority(pinit, CONFIG_PRIORITY_ROOTSERVER);
    task_set_maxpriority(pinit, CONFIG_PRIORITY_ROOTSERVER);

    endpoint_init(&faulthandler);
    endpoint_get(&faulthandler); // make sure it won't be freed
    task_set_faulthandler(pinit, &faulthandler);

    // build the initial address space
    as = initial_addrspace_init((unsigned long)&init_si, sizeof(init_si));
    task_set_addrspace(pinit, as);

    bi->cspace = initial_cspace_init(pinit, as, &faulthandler);
    cap_cnode_init(task_get_cnode(pinit), bi->cspace,
                   bi->guardlen, bi->guard, bi->radix);

    // only for debug
    task_set_name(pinit, "rootserver");

    task_set_state(pinit, TASK_READY);
    return pinit;
}

#ifdef CONFIG_ENABLE_SMP
void BOOTONLY init_secondary_core(void)
{
    cpu_init();

    // notify the primary core and wait util primary core initialized
    smp_secondary_cores_up();

    // do some tests and active the final kernel address space
    run_self_test();
    kernel_addrspace_active();

    // todo: initialize private systick for current secondary cpu core
    systick_init(clock_system());

    // initialize scheduler for current secondary cpu core
    schedule_init(create_idle_task());

    dprintf("Core #%d running!\n", current_cpu());
    timer_next(10);
}
#endif

void BOOTONLY init_kernel(void)
{
    tcb_t *rootserver;
#ifdef CONFIG_ENABLE_SMP
    if (current_cpu() != 0)
    {
        init_secondary_core();
        return;
    }
#endif

    // intialize the clock of the whole platform and the output port for debug message
    early_init(); //时钟和串口，芯片相关

    // make sure the cpu and the platform could works well
    // cache, fpu, intterrupt controller and so on.
    cpu_init();
    platform_init(); //设置显示器和相关中断，芯片相关

    // run some basic testcases when in debug mode
    run_self_test();

    // provide the memory allocator and the manager of interrupt handlers
    allocator_init(); //初始化红黑树
    irq_handler_init();

#ifdef CONFIG_ENABLE_SMP
    // bring up secondary cores when platform initialized
    smp_init();
    platform_bring_up_secondary_cores();
#endif

    //dprintf("******uart init*****************\n");
    //uart_init(); //芯片相关
    // initialize the system tick and register its interrupt handler
    systick_init(clock_system()); //初始化定时器，当未使能定时器
    timer_init();

#if 1
    // build the kernel address space shared by all tasks
    kernel_addrspace_init();
    kernel_addrspace_active();

    // scr_invalidate_data_cache();

    // scr_enable_cpu_cache();

    // initialize the scheduler and two task: idle and rootserver
    schedule_init(create_idle_task());
    rootserver = create_init_task();
    schedule_attach(rootserver);

    // create all necessary RAM CAPS for the resource belong to rootserver
    initial_cspace_lock_ram();

#ifdef CONFIG_ENABLE_SMP
    // active cores when primary core initialized
    smp_active_secondary_cores();
#endif

    // kernel initialize completed
    allocator_dump_status();
    dprintf("kernel initialise completed!\n");

    timer_next(5000);
#endif
}
