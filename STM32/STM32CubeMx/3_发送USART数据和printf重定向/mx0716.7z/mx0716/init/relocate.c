/*****************************************************
* need four symbols to identify the postion of .data
* and .bss from relocate_r.s
******************************************************/
#include <config.h>

#include <tools/macros.h>

#include <addrspace.h>

#include <init/relocate.h>

#define LOAD_PADDR(x) (x - CONFIG_EXEC_ADDR + CONFIG_LOAD_ADDR)

static unsigned long BOOTONLY ram_pbase(unsigned long vbase)
{
    extern region_t ksram[];
    region_t *cur;

    for(cur = ksram; cur->size != 0; cur++)
    {
        if(cur->vbase != 0 && vbase >= cur->vbase && vbase < (cur->vbase + cur->size))
            return vbase - cur->vbase + cur->pbase;
    }
    return 0;
}

// Copy the .data to it's excution base(virtual base), this
// operation could be useless in some kinds of environment. For 
// example, if the kernel is loaded in RAM and the platform support
// memory map, mapping the .data to it's virtual base is enough.
void BOOTONLY copy_data(void)
{
    unsigned long *src, *dst;
    
    dst = &k_rw_start;
    src = (unsigned long*)LOAD_PADDR((unsigned long)&k_ro_shared_start);

    if(dst == src)
        return;
    
    while(dst < &k_rw_end)
    {
        *dst = *src;
        dst++, src++;
    }
}

void BOOTONLY clean_bss(void)
{
    unsigned long* dst;
    // clean .bss
    dst = &k_zi_start;
    while(dst < &k_zi_end)
    {
        *dst = 0;
        dst++;
    }
}

void BOOTONLY fill_image_info(void)
{
    region_init(&kernelinfo.code,
        CONFIG_LOAD_ADDR,
        CONFIG_EXEC_ADDR & ~0x1,
        (unsigned long)&k_ro_shared_end - CONFIG_EXEC_ADDR);
    region_init(&kernelinfo.rwdata,
        ram_pbase((unsigned long)&k_rw_start),
        (unsigned long)&k_rw_start,
        (unsigned long)&k_shared_end - (unsigned long)&k_rw_start);
    
    // let the rootserver relocate it's rw data
    region_init(&rootserverinfo.code,
        LOAD_PADDR((unsigned long)&rs_ro_start),
        CONFIG_ROOTSERVER_EXEC_ADDR & ~0x1,
        (unsigned long)&rs_ro_end - (unsigned long)&rs_ro_start);
    region_init(&rootserverinfo.rwdata, 0, 0, 0);
}

void BOOTONLY relocate_data(void)
{
    clean_bss();
    fill_image_info();
}
