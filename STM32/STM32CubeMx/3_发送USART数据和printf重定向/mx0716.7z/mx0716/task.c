/*********************************************************
*
*********************************************************/
#include <config.h>

#include <tools/list.h>

#include <addrspace.h>
#include <task.h>
#include <timer.h>

#include <caps/cnode.h>

#include <arch/context.h>

void tcb_recycle(tcb_t *tcb)
{
    if(!cap_is_empty(&tcb->cnode))
        cap_cnode_put(&tcb->cnode);
    
    if(tcb->addrspace != 0)
        addrspace_put(tcb->addrspace);
    
    // todo: if ipcbuffer if not belong to kernel
    if(tcb->ipcbuffer != 0)
        allocator_free((unsigned long)tcb->ipcbuffer, sizeof(ipcbuffer_t));
    
    allocator_free((unsigned long)tcb, sizeof(tcb_t));
    
    endpoint_clean_callers(tcb);
}

void task_init(tcb_t *tcb, int type)
{
    context_init(task_get_context(tcb), type);
    
    tcb->magic = TCB_MAGIC;
    tcb->id = 0;
    tcb->state = TASK_INACTIVE;
    tcb->flags = 0;
    tcb->readytime = timer_current();
    tcb->timeslice = CONFIG_DEFUALT_TIMESLICE;
    tcb->maxpriority = CONFIG_DEFAULT_PRIORITY;
    tcb->priority = CONFIG_DEFAULT_PRIORITY;
    tcb->ipcbuffer = 0;
    tcb->faulthandler = 0;
    
    tcb->calledep = 0;
    list_init(&tcb->callernode);
    list_init(&tcb->callers);
    
    task_set_name(tcb, "Unset");
    cap_make_empty(&tcb->cnode);
    list_init(&tcb->runlist);
    object_init(&tcb->obj);
}

void task_switch_prepare(tcb_t *to, tcb_t* from)
{
    context_switch_prepare(task_get_context(to), task_get_context(from));
    timer_next_ms(to->timeslice);// TODO: disable this when do some performance test
    addrspace_switch_to(task_get_addrspace(to), task_get_addrspace(from));  //切换页表
}

void task_clone(tcb_t* target, tcb_t* src, unsigned long id)
{
    tcb_get(src);
    
    cap_cnode_copy(&target->cnode, &src->cnode);
    
    addrspace_get(src->addrspace);
    target->addrspace = src->addrspace;
    
    if(src->faulthandler != 0)
    {
        endpoint_get(src->faulthandler);
        target->faulthandler = src->faulthandler;
    }
    
    target->priority = src->priority;
    target->maxpriority = src->maxpriority;
    target->readytime = src->readytime;
    target->timeslice = src->timeslice;
    target->id = id;
    
    tcb_put(src);
}
