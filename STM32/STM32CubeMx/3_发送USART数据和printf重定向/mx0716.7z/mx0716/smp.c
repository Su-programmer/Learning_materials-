#include <config.h>

#include <tools/macros.h>
#include <tools/list.h>

#include <dprintf.h>
#include <smp.h>
#include <atomic.h>
#include <spinlock.h>
#include <task.h>
#include <interrupt.h>
#include <schedule.h>

#include <arch/cpu.h>
#include <plat/irqn.h>

typedef struct __task_list_t{
    spinlock_t lock;
    list_t list;
}task_list_t;

atomic_t cores = ATOMIC_INIT(0);
spinlock_t lock = SPINLOCK_INIT_LOCKED;

task_list_t translist[CONFIG_SMP_CORES];

void WEAK smp_notify_core(unsigned int targetcpu)
{
    dprintf("ERROR: Implement %s() for your platform!!!\n", __FUNCTION__);
    halt();
}

void smp_tranfer_task(tcb_t* task, unsigned int targetcpu)
{
    task_list_t* li;
    int neednotify;

    if(targetcpu >= CONFIG_SMP_CORES)
    {
        dprintf("WARNING: target CPU cores doesn't exists!\n");
        targetcpu %= CONFIG_SMP_CORES;
    }

    li = translist + targetcpu;
    tcb_get(task);

    spin_lock(&li->lock);
    neednotify = list_is_empty(&li->list);
    list_append(&li->list, &task->runlist);
    spin_unlock(&li->lock);
    
    if(neednotify)
        smp_notify_core(targetcpu);
}

// WARNING: the referrence count has already been incremented
static tcb_t* smp_accept_task(task_list_t* li)
{
    tcb_t* task = 0;

    assert(li - translist < CONFIG_SMP_CORES);

    spin_lock(&li->lock);
    if(!list_is_empty(&li->list))
    {
        task = container_of(li->list.next, tcb_t, runlist);
        list_remove(&task->runlist);
    }
    spin_unlock(&li->lock);

    return task;
}

static void ipi_handler(void)
{
    unsigned int core = current_cpu();
    task_list_t* list = translist + core;
    tcb_t* task;
    
    dprintf("core#%d received a ipi!\n", core);
    
    while(1)
    {
        task = smp_accept_task(list);
        if(task == 0)
            break;
        
        if(task_get_state(task) != TASK_READY)
            dprintf("TODO: support detach when handle IPI!\n");

        dprintf("Task 0x%x has accpeted!\n", task);
        schedule_attach(task);
        tcb_put(task);
    }

    dprintf("Do schedule()\n");
    schedule();
}

void smp_secondary_cores_up(void)
{
    atomic_add(&cores, 1);
    while(spin_is_locked(&lock));

    // todo: 
    irq_setup_handler(CONFIG_IRQN_IPI, ipi_handler);
}

void smp_active_secondary_cores(void)
{
    spin_unlock(&lock);
}

unsigned int smp_current_cores(void)
{
    return atomic_load(&cores);
}

void BOOTONLY smp_init(void)
{
    int i;

    // primary cores up, increse the cores' count
    atomic_add(&cores, 1);

    for(i = 0; i < sizeof(translist)/sizeof(task_list_t); i++)
    {
        list_init(&translist[i].list);
        spin_init_unlocked(&translist[i].lock);
    }

    // register the IPI handler
    irq_setup_handler(CONFIG_IRQN_IPI, ipi_handler);
}
