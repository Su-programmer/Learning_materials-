#include <stdlib/assert.h>

#include <uapi/bootinfo.h>
#include <uapi/errors.h>

#include <dprintf.h>
#include <allocate.h>
#include <addrspace.h>

#include <init/relocate.h>
#define KB *1024
#define MB *1024 KB

static addrspace_t kspace;
addrspace_t rsspace;
image_info_t kernelinfo;
image_info_t rootserverinfo;
unsigned long addrspace_map_pbase;
unsigned long addrspace_map_vbase;
unsigned long addrspace_map_size;

static addrspace_t usspace[128];
static addrspace_t umastespace;
int threadnum = 0, elf_num = 0;

void addrspace_recycle(addrspace_t *as)
{
    page_table_recycle(&as->pg, &kspace.pg);
    if (allocator_free((unsigned long)as, sizeof(addrspace_t)) != 0)
    {
        dprintf("Failed to free the addrspace: %x, total %d bytes!\n",
                (unsigned long)as, sizeof(addrspace_t));
    }
}

void addrspace_init(addrspace_t *as)
{
    page_table_init(&as->pg);
    page_table_copy(&as->pg, &kspace.pg);
    object_init(&as->obj);
}

addrspace_t *kernel_addrspace(void)
{
    return &kspace;
}

static int BOOTONLY map_create_pt(addrspace_t *as, unsigned long vbase, unsigned long size, int level, unsigned int attr)
{
    static const unsigned long ftr[] = {
        [0] = MAP_PTL_PAGES,
        [1] = MAP_PTL_L1,
        [2] = MAP_PTL_L2,
        [3] = MAP_PTL_L3,
        [4] = MAP_PTL_L4,
    };

    unsigned long base;
    void *pt;

    base = addrspace_missing_pt(as, &vbase, &size, level);
    if (base == 0)
    {
        dprintf("error: base == 0\n");
        return -EGENERAL;
    }
    pt = allocator_alloc_block(pti[level].size, pti[level].size);
    if (pt == 0)
    {
        dprintf("Failed to get a free block for L%dPT!\n", level);
        return -ENOMEM;
    }
    unsigned long pbase = allocator_pbase((unsigned long)pt);
    // dprintf("base:0x%x%x,pt:0x%x\n", (uint32_t)(base >> 32), (uint32_t)base, (uint32_t)pt);
    return addrspace_map(as, &pbase, &base, &(pti[level].size), attr | ftr[level]);
}

int BOOTONLY map_single_region(addrspace_t *as, const region_t *r, unsigned int attr)
{
    int result;
    int level;
    int flag = 1;
    // we will not map a region to 0.
    if (r->vbase == 0 || r->size == 0)
        return 0;
    unsigned long addr_pbase = r->pbase;
    unsigned long addr_vbase = r->vbase;
    unsigned long addr_size = r->size;
    while (flag)
    {
        // result = addrspace_map(as, r->pbase, r->vbase, r->size, attr);
        result = addrspace_map(as, &addr_pbase, &addr_vbase, &addr_size, attr);

        level = 1;
        switch (result)
        {
        case -ENOL4PT:
            level += 1;
        case -ENOL3PT:
            level += 1;
        case -ENOL2PT:
            level += 1;
            result = map_create_pt(as, addr_vbase, addr_size, level, attr);
            if (result != 0)
                flag = 0;
            break;

        default:
            flag = 0;
            break;
        }
    }

    return result;
}

static int BOOTONLY map_single_region_kernelimage(addrspace_t *as, const region_t *r, unsigned int attr)
{
    int result;
    int level;
    int flag = 1;

    // we will not map a region to 0.
    if (r->vbase == 0 || r->size == 0)
        return 0;
    addrspace_map_pbase = r->pbase;
    addrspace_map_vbase = r->vbase;
    addrspace_map_size = r->size;

    while (flag)
    {
        result = addrspace_map_kernel(as, &addrspace_map_pbase, &addrspace_map_vbase, &addrspace_map_size, attr);

        level = 1;
        switch (result)
        {
        case -ENOL4PT:
            level += 1;
        case -ENOL3PT:
            level += 1;
        case -ENOL2PT:
            level += 1;
            result = map_create_pt(as, addrspace_map_vbase, addrspace_map_size, level, attr);
            if (result != 0)
                flag = 0;
            break;

        default:
            flag = 0;
            break;
        }
        dprintf("result:%d,flag:%d\n", result, flag);
    }
    dprintf("jmp out loop\n");
    return result;
}

static int BOOTONLY regions_map(addrspace_t *as, const region_t *r, unsigned int attr)
{
    const region_t *cur = r;
    int result;

    for (; cur->size > 0; cur++)
    {
        result = map_single_region(as, cur, attr);
        if (result != 0)
            break;
    }

    return result;
}

static int BOOTONLY image_map(addrspace_t *as, const image_info_t *ii, unsigned int iskernel)
{
    int result = 0;
    unsigned int ap_ro;
    unsigned int ap_rw;
    unsigned int extra = 0;

    if (iskernel)
    {
        ap_ro = MAP_AP_KRO_UNA;
        ap_rw = MAP_AP_KRW_UNA;
        extra = MAP_FLAG_GLOBAL;
    }
    else
    {
        ap_ro = MAP_AP_KRO_URO;
        ap_rw = MAP_AP_KRW_URW;
    }

#define MAP_SEGEMENT(seg, attr)                                     \
    if (ii->seg.vbase != 0)                                         \
    {                                                               \
        result = map_single_region_kernelimage(as, &ii->seg, attr); \
        assert(result == 0);                                        \
    }
    dprintf("in image_map\n");
    dprintf("start map code\n");
    MAP_SEGEMENT(code,
                 map_mk_attr(MAP_PTL_PAGES, MAP_TYPE_RAM, ap_ro,
                             extra | MAP_FLAG_EXECUTABLE | MAP_FLAG_CACHEABLE | MAP_FLAG_SHAREABLE));
    dprintf("done\nstart map rwdata\n");
    MAP_SEGEMENT(rwdata, map_mk_attr(MAP_PTL_PAGES, MAP_TYPE_RAM, ap_rw,
                                     extra | MAP_FLAG_CACHEABLE | MAP_FLAG_SHAREABLE));
    dprintf("done\n");
    return result;
}

static void BOOTONLY prepare_addrspace(addrspace_t *as,
                                       const region_t *ram, const region_t *dev, unsigned int iskernel)
{
    unsigned int ap;
    unsigned int extra = 0;

    if (iskernel)
    {
        ap = MAP_AP_KRW_UNA;
        extra = MAP_FLAG_GLOBAL;
    }
    else
        ap = MAP_AP_KRW_URW;
    dprintf("in %s\n", __FUNCTION__);
    dprintf("start map ram\n");
    regions_map(as, ram, map_mk_attr(MAP_PTL_PAGES, MAP_TYPE_RAM, ap, extra | MAP_FLAG_CACHEABLE | MAP_FLAG_SHAREABLE | MAP_FLAG_EXECUTABLE));
    dprintf("done\nstart map dev\n");
    regions_map(as, dev, map_mk_attr(MAP_PTL_PAGES, MAP_TYPE_DEVICE, ap, extra | MAP_FLAG_SHAREABLE));
    dprintf("done\n");
}

extern const region_t usram[];
extern const region_t usdev[];
extern const region_t ksram[];
extern const region_t ksdev[];
extern const region_t thread_usram[];
extern const region_t usshmram[];

static void build_kernel_space(addrspace_t *as)
{
    dprintf("in %s\n", __FUNCTION__);
    page_table_init(&as->pg);
    prepare_addrspace(as, ksram, ksdev, 1);
    prepare_addrspace(as, usram, usdev, 0);
    dprintf("start map kernelinfo\n");
    image_map(as, &kernelinfo, 1);
    dprintf("kernelinfo map done\n");
}

void BOOTONLY kernel_addrspace_init(void)
{
    dprintf("Building kernel address space.\n");
    build_kernel_space(&kspace);
}

void BOOTONLY kernel_addrspace_active(void)
{
    dprintf("in %s\n", __FUNCTION__);
    page_table_active(&kspace.pg);
    addrspace_get(&kspace);
}
void *BOOTONLY initial_addrspace_init1()
{
    const region_t *cur;
    region_t tmp;
    unsigned long attr;
    unsigned long attr_k;

    const unsigned long kcpend = kernelinfo.code.pbase + kernelinfo.code.size;

    // rebuild the kernel space in the address space of rootserver
    build_kernel_space(&umastespace);
    prepare_addrspace(&umastespace, usram, usdev, 0);
    image_map(&umastespace, &rootserverinfo, 0);
    // remap k_ro_shared
    tmp.vbase = (unsigned long)&k_ro_shared_start;
    tmp.size = (unsigned long)&k_ro_shared_end - tmp.vbase;
    tmp.pbase = allocator_pbase(tmp.vbase);
    attr = map_mk_attr(MAP_PTL_PAGES, MAP_TYPE_RAM, MAP_AP_KRO_URO,
                       MAP_FLAG_CACHEABLE | MAP_FLAG_SHAREABLE);
    attr_k = map_mk_attr(MAP_PTL_PAGES, MAP_TYPE_RAM, MAP_AP_KRO_UNA,
                         MAP_FLAG_CACHEABLE | MAP_FLAG_SHAREABLE);
    map_single_region(&umastespace, &tmp, attr);
    map_single_region(&kspace, &tmp, attr_k);

    // remap the kernel ram
    // todo: don't map the .data, .stack and .bss that not shared with rootserver
    attr = map_mk_attr(MAP_PTL_PAGES, MAP_TYPE_RAM, MAP_AP_KRW_URO,
                       MAP_FLAG_CACHEABLE | MAP_FLAG_SHAREABLE);
    attr_k = map_mk_attr(MAP_PTL_PAGES, MAP_TYPE_RAM, MAP_AP_KRW_UNA,
                         MAP_FLAG_CACHEABLE | MAP_FLAG_SHAREABLE);
    for (cur = ksram; cur->size != 0; cur++)
    {
        const unsigned long cpend = cur->pbase + cur->size;

        tmp.vbase = cur->vbase;
        tmp.pbase = cur->pbase;
        tmp.size = cur->size;
        while (tmp.pbase < cpend)
        {
            unsigned long tpend = tmp.pbase + tmp.size;

            if (tmp.pbase < kernelinfo.code.pbase)
            {
                if (tpend > kernelinfo.code.pbase)
                    tmp.size = kernelinfo.code.pbase - tmp.pbase;

                map_single_region(&umastespace, &tmp, attr);
                map_single_region(&kspace, &tmp, attr_k);

                tmp.pbase += tmp.size;
                tmp.vbase += tmp.size;
                tmp.size = cpend - tmp.pbase;
            }
            else if (tmp.pbase >= kcpend)
            {
                map_single_region(&umastespace, &tmp, attr);
                map_single_region(&kspace, &tmp, attr_k);
                break;
            }
            else
            {
                if (tpend > kcpend)
                {
                    tmp.pbase = kcpend;
                    tmp.vbase = tmp.pbase - cur->pbase + cur->vbase;
                    tmp.size = tpend - kcpend;

                    map_single_region(&umastespace, &tmp, attr);
                    map_single_region(&kspace, &tmp, attr_k);
                }
                break;
            }
        }
    }
}

addrspace_t *BOOTONLY initial_addrspace_init(unsigned long stack, unsigned long size)
{
    initial_addrspace_init1();
    // rsspace = umastespace;
    int i;
    char *psrc = &umastespace;
    char *pdst = &rsspace;
    for (i = 0; i < sizeof(umastespace); i++)
    {
        pdst[i] = psrc[i];
    }

    regions_map(&rsspace, usshmram, map_mk_attr(MAP_PTL_PAGES, MAP_TYPE_RAM, MAP_AP_KRW_URW, MAP_FLAG_SHAREABLE));
    region_t tmp;
    unsigned long attr;
    // map the stack and the ipcbuffer
    tmp.vbase = stack;
    tmp.size = size;
    tmp.pbase = allocator_pbase(tmp.vbase);
    attr = map_mk_attr(MAP_PTL_PAGES, MAP_TYPE_RAM, MAP_AP_KRW_URW,
                       MAP_FLAG_CACHEABLE | MAP_FLAG_SHAREABLE);
    map_single_region(&rsspace, &tmp, attr);

    vir_to_phy(&rsspace.pg, 0x60300100);
    vir_to_phy(&rsspace.pg, 0x40600160);
    return &rsspace;
}

addrspace_t *thread_addrsapce_init(int elf)
{
    if (threadnum > 31)
    {
        dprintf("Address space ran out!\n");
        return 0;
    }
    int i;
    char *psrc = &umastespace;
    char *pdst = &usspace[threadnum];
    for (i = 0; i < sizeof(umastespace); i++)
    {
        pdst[i] = psrc[i];
    }
    // usspace[threadnum] = umastespace;
    if (elf)
    {
        region_t tmp;
        unsigned long attr;
        tmp.vbase = 0x40f00000; // forward
        elf_num++;
        tmp.pbase = 0x58000000 + (8 MB) + (elf_num - 1) * (2 MB);
        tmp.size = 3 MB;
        attr = map_mk_attr(MAP_PTL_PAGES, MAP_TYPE_RAM, MAP_AP_KRW_URW, MAP_FLAG_CACHEABLE | MAP_FLAG_SHAREABLE | MAP_FLAG_EXECUTABLE);
        map_single_region(&usspace[threadnum], &tmp, attr);
    }
    threadnum++;
    return &usspace[threadnum - 1];
}
