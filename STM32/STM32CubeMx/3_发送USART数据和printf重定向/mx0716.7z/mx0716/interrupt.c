#include <stdlib/assert.h>

#include <config.h>
#include <tools/macros.h>
#include <dprintf.h>
#include <interrupt.h>
#include <notification.h>
#include <task.h>
#include <schedule.h>

#include <caps/capability.h>

#include <arch/exception.h>

// An locked irq means that the kernel will handle the irq and
// the user has no permission to monitor it.
// We will use the private member provided by notification_t to
// remember the handler set by kernel. Only when the private member
// of an irq is 0, then the user could monitor the irq.
static notification_t irqtable[CONFIG_IRQ_COUNT];

static inline void mark_unlocked(unsigned int irq)
{
    notification_set_private_data(irqtable + irq, 0);
}

static inline int is_locked(unsigned int irq)
{
    return notification_get_private_data(irqtable + irq) != 0;
}

notification_t* irq_register(unsigned int irq)
{
    notification_t *ntfn = 0;
    
    if(irq < CONFIG_IRQ_COUNT && ~is_locked(irq))
    {
        ntfn = irqtable + irq;
        notification_get(ntfn);
    }

    return ntfn;
}

void irq_unregister(notification_t* ntfn)
{
    unsigned int irq = ntfn - irqtable;
    
    if(notification_put(ntfn) == 1)
    {
        exception_disable_irq(irq);
        exception_ack_irq(irq);
        
        if(notification_has_waiters(ntfn))
        {
            // wakeup all waiters if there are
            notification_cancel(ntfn);
            notification_init(ntfn);
        }
    }
}

void irq_prepare_wait(notification_t* ntfn)
{
    unsigned int irq = ntfn - irqtable;
    
    exception_enable_irq(irq);
}

void irq_ack_enable(notification_t *ntfn)
{
    unsigned int irq = ntfn - irqtable;
    
    exception_ack_irq(irq);
    
    if(object_refcount(&ntfn->obj) > 1)
        exception_enable_irq(irq);
}

void irq_handler_entry(unsigned int irq)
{
    notification_t *ntfn = irqtable + irq;
    
    assert(irq < CONFIG_IRQ_COUNT);

    if(is_locked(irq))
    {
        handler_t handler = (handler_t)notification_get_private_data(ntfn);
        handler();
        exception_ack_irq(irq);
        return;
    }

//    dprintf("disable interrupt\n");
    // disable the intterupt

    exception_disable_irq(irq);

    if(object_refcount(&ntfn->obj) > 1)
    {
        // notify the interrupt controller to change the active state
        // of the irq, maybe we can create a new interface to do this(todo).
        exception_ack_irq(irq);

        notification_signal(ntfn, 0);
    }
    else
    {
        dprintf("Unexpected irq %d received! Disable it and ignore.\n", irq);
        exception_ack_irq(irq);
    }

    // do schedule to give the interrupt handler
    // an opportunity to run immediately
    schedule();
}

void BOOTONLY irq_handler_init(void)
{
    int i;
    for(i = 0; i < CONFIG_IRQ_COUNT; i++)
    {
        notification_init(irqtable + i);
        notification_get(irqtable + i);
        mark_unlocked(i);
    }
}

void BOOTONLY irq_setup_handler(unsigned int irq, handler_t handler)
{
    assert(irq < CONFIG_IRQ_COUNT);
    notification_set_private_data(irqtable + irq, (unsigned long)handler);
    exception_enable_irq(irq);
}

void BOOTONLY irq_clean_handler(unsigned int irq)
{
    assert(irq < CONFIG_IRQ_COUNT);
    mark_unlocked(irq);
    exception_disable_irq(irq);
}
