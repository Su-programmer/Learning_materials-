#include <config.h>

#include <dprintf.h>
#include <syscall.h>
#include <schedule.h>
#include <task.h>
#include <timer.h>

#include <caps/capability.h>

#include <uapi/errors.h>
#include <uapi/syscall.h>
#include <uapi/ipcbuffer.h>

#include <arch/systick.h>

#include <fault.h>
#include <caps/cnode.h>
#define SYSCALL_DEFINE(name) void sys_##name(unsigned long sn, \
                unsigned long a0, unsigned long a1, unsigned long a2)

typedef void (*syscall_t)(unsigned long, unsigned long, unsigned long, unsigned long);
syscall_t systable[SYS_COUNT]; // todo: const syscall_t syscalltable[SYSCALL_COUNT];

SYSCALL_DEFINE(exit)
{
    tcb_t *quit = current();
#if !DPRINTF_MUTEK_SYSCALL    
    dprintf("Task %x exit with %d!\n", (unsigned long)quit, a0);
    task_dump_info(quit);
#endif
    
    task_set_state(quit, TASK_EXIT_ZOMBIE);
    task_prepare_exit(quit);
    fault_report(quit, FAULT_CHILD_EXIT, a0, 0);
}

SYSCALL_DEFINE(yield)
{
    task_set_retcode(current(), ESUCCESS);
    schedule_detach(current());
}

SYSCALL_DEFINE(nanosleep)
{
    tcb_t *cur = current();
    cur->readytime = timer_current() + a0 / 1000;
    task_set_state(cur, TASK_SLEEP);
    task_set_retcode(cur, ESUCCESS);
    schedule_detach(current());
}

SYSCALL_DEFINE(usleep)
{
    tcb_t *cur = current();
    cur->readytime = timer_current() + a0;
    task_set_state(cur, TASK_SLEEP);
    task_set_retcode(cur, ESUCCESS);
    schedule_detach(current());
}

SYSCALL_DEFINE(test_prepare)
{
    systick_disable_int();
}


SYSCALL_DEFINE(test)
{
	//dprintf("syscall test\n");
	capability_t* ret = 0;
	int i;
	cptr_t cptr_start = 0xf2a00000;
	cptr_t cptr_list[10] = {0};
	for(i = 0; i < 10; i++) {
		cptr_list[i] = cptr_start;
		cptr_start += 0x100000;
	}
	cptr_t cptr = 0;

	for(i = 0; i < sizeof(cptr_list)/sizeof(cptr_t); i++)
	{
		ret = cnode_cptr_lookup(task_get_cnode(current()), cptr_list[i], sizeof(unsigned long)*8);
		if(ret != 0 && ret->cap_ext == 0x9527) {
			//dprintf("cptr finded 0x%x\n", cptr_list[i]);
			cptr = cptr_list[i];
			goto lookup_end;
		} else {
			//dprintf("loop 0x%x\n", cptr_list[i]);
		}
	}

lookup_end:
	task_set_retcode(current(), cptr);
}

SYSCALL_DEFINE(test_end)
{
    systick_enable_int();
}

extern void __flush_cache(unsigned int start,unsigned int size);

SYSCALL_DEFINE(cache_op)
{
    dprintf("flush_cache. start:0x%x,size:0x%x\n",a0,a1);
    __flush_cache(a0,a1);
}

void syscall_handler(unsigned long sn, unsigned long a0, unsigned long a1, unsigned long a2)
{
#ifdef DEBUG_DUMP_SVC
    dprintf("SVC Parameters: %x %x %x %x\n", sn, a0, a1, a2);
#endif
    
    if(sn < SYS_COUNT)
        systable[sn](sn, a0, a1, a2);
    else
        cap_dispatcher(sn, a0, a1, a2);
        
    schedule();
}


syscall_t systable[SYS_COUNT] = {
    [SYS_exit] = sys_exit,
    [SYS_yield] = sys_yield,
    [SYS_nanosleep] = sys_nanosleep,
    [SYS_usleep] = sys_usleep,
    [SYS_test_prepare] = sys_test_prepare,
    [SYS_test] = sys_test,
    [SYS_test_end] = sys_test_end,
    [SYS_cache_op] = sys_cache_op,
};
