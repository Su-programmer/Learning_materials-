/*********************************************************
*   All the blocks should be align to 8 bytes, including
* it's size and base address.
*********************************************************/
#include <config.h>

#include <stdlib/assert.h>
#include <stdlib/ks_stdint.h>

#include <dprintf.h>
#include <allocate.h>
#include <addrspace.h>
#include <object.h>

#include <tools/rbtree.h>
#include <tools/macros.h>

#include <uapi/bootinfo.h>

// low-level data structure required by this module
extern const region_t ksram[];
extern const region_t usram[];

int check_usram_region(void* begin, unsigned int size)
{
    // todo: check if the region is in the usram
    return 1;
}

static rbnode_t SHARED_BSS rbtree;
unsigned int SHARED_BSS fragment;

static inline unsigned int size_align(unsigned int size)
{
    fragment -= size;
    size = (size + 0x7) & ~(0x7); // make sure every block is aligned to 8 bytes
    fragment += size;
    
    return size;
}

static int compare_less(rbnode_t* lhs, rbnode_t* rhs)
{
    return (word_t)lhs < (word_t)rhs;
}

static int compare(rbnode_t *lhs, unsigned long target)
{
    word_t begin = (word_t)lhs;
    word_t end = lhs->data + begin;
    
    if(begin <= target && end >= target)
        return 0;
    else
        return begin - target; // this will be ok if begin < target
}

// return 0 if the block is free
int allocator_alloc(unsigned long begin, unsigned int size)
{
    rbnode_t *node = rbtree_find(&rbtree, begin, compare);
    unsigned int frontsize;
    unsigned int backsize;
    
    assert(size >= sizeof(rbnode_t));
    size = size_align(size);
    
    if(node != 0 && ((unsigned long)node + node->data) >= begin + size)
    {
        frontsize = begin - (unsigned long)node;
        backsize = (unsigned long)node + node->data - (begin + size);
        
        if(frontsize < sizeof(rbnode_t))
        {
            rbtree_delete(&rbtree, node);
            fragment += frontsize;
        }
        else
            node->data = frontsize;
        
        if(backsize >= sizeof(rbnode_t))
        {
            node = (rbnode_t*)(begin + size);
            node->data = backsize;
            rbtree_insert(&rbtree, node, compare_less);
            // todo: merge it with small blocks
        }
        
        return 0;
    }
    else
        return -1;
}

int allocator_free(unsigned long begin, unsigned int size)
{
    rbnode_t *node = rbtree_find(&rbtree, begin, compare);
    
    assert(size >= sizeof(rbnode_t) && (size & 0x7) == 0);
    
    if(node == 0)
    {
        node = (rbnode_t*) begin;
        node->data = size;
        rbtree_insert(&rbtree, node, compare_less);
        
        // todo: merge the small blocks
        return 0;
    }
    else
        return -1;
}

unsigned long allocator_pbase(unsigned long vbase)
{
    unsigned long begin;
    unsigned long end;
    int i = 0;
    
    while(ksram[i].size > 0)
    {
        begin = ksram[i].vbase;
        end = begin + ksram[i].size;
        
        if(vbase >= begin && vbase < end)
        {
            return vbase - begin + ksram[i].pbase;
        }

        i++;
    }
    
    return 0;
}

unsigned long allocator_vbase(unsigned long pbase)
{
    unsigned long begin;
    unsigned long end;
    int i = 0;
    
    while(ksram[i].size > 0)
    {
        begin = ksram[i].pbase;
        end = begin + ksram[i].size;
        
        if(pbase >= begin && pbase < end)
        {
            return pbase - begin + ksram[i].vbase;
        }

        i++;
    }
    
    return 0;
}

void *allocator_get_rbtree(void)
{
    return &rbtree;
}

void allocator_dump_status(void)
{
    unsigned long total = 0;
    rbnode_t *cur;
    
    dprintf("---------------------------------------\n");
    dprintf("Memroy Allocation Status:\n");
    
    for(cur = rbtree_left_most(&rbtree); cur != 0; cur = rbnode_next(&rbtree, cur))
    {
        dprintf("\t[%x, %x]: %d bytes\n", (unsigned long)cur, (unsigned long)cur + cur->data - 1, cur->data);
        total += cur->data;
    }
    
    dprintf("Fragment Count: %d bytes\n", fragment);
    dprintf("Total Availiable: %d bytes\n", total);
    dprintf("---------------------------------------\n");
}

void BOOTONLY shrink_region(region_t *curr, const region_t* reserved, int count)
{
    int rend;
    int bend;
    int j;
    
    for(j = 0; j < count; j++, reserved++)
    {
    	/*计算两个内存区域的包含情况*/
        rend = reserved->pbase + reserved->size;
        bend = curr->pbase + curr->size;
        dprintf("rend:0x%x,reserved->pbase:0x%x,reserved->size:0x%x\n",rend,reserved->pbase,reserved->size);
        dprintf("bend:0x%x,curr->pbase:0x%x,curr->size:0x%x\n",bend,curr->pbase,curr->size);
        /*如果预留区域的基地址包含了当前区域的基地址*/
        if(reserved->pbase <= curr->pbase)
        {
        	/*且预留区域结束地址包含当前区域基地址，即当前区域部分包含在预留区域中*/
            if(rend > curr->pbase)
            {
                if(rend >= bend)  //reserved的区域超出了curr的区域，
                {
                    curr->pbase = bend;
                    curr->size = 0;
                    break;
                }
				/*部分包含，修改当前区域基地址为预留区域结束地址，得到不重合部分size*/
                else
                {
                    curr->pbase = rend;
                    curr->size = bend - rend;
                }
            }
        }
		/*说明两个区域有交叉，有可能预留区域被完全包含在当前区域中*/
        else if(reserved->pbase < bend)
        {
        	/*更新当前区域的size，不能与预留区域重叠，会丢失掉部分内存*/
            curr->size = reserved->pbase - curr->pbase;
        }
        else
			/*此分支说明两个区域完全不重叠*/
            continue;
    }
}

// static void BOOTONLY add_region(region_t *remain)
// {
//     region_t curr;
    
//     assert((remain->pbase & 0x7) == 0); //8字节对齐
//     assert((remain->vbase & 0x7) == 0);
//     dprintf("************start add_region***************\n");
    
//     while(remain->size >= sizeof(rbnode_t))
//     {
//         curr.pbase = remain->pbase;
//         curr.size = remain->size;
//         curr.vbase = remain->vbase;
//         dprintf("before align\n");
//         dprintf("remain->pbase:0x%x,remain->vbase:0x%x,remain->size:0x%x\n",remain->pbase,remain->vbase,remain->size);
        
//         shrink_region(&curr, (region_t*)&kernelinfo, sizeof(image_info_t)/sizeof(region_t));
//         shrink_region(&curr, (region_t*)&rootserverinfo, sizeof(image_info_t)/sizeof(region_t));

// 		/*主要是为了计算之后对齐pbase时产生的碎片*/
//         if((curr.pbase & 0x7) > 0)
//         {
//             curr.size -= 8 - ( curr.pbase & 0x7);
//             fragment += 8 - ( curr.pbase & 0x7);
//         }
//         curr.size &= ~(0x7);
//         curr.pbase = align_to(curr.pbase, 8);
//         /*更新对应的虚拟地址*/
//         curr.vbase += curr.pbase - remain->pbase;
// 		/*curr中是此次循环中需要加到红黑树中的内存配置，更新下一次循环中的remain*/
// 		remain->size = remain->pbase + remain->size - (curr.pbase + curr.size);
//         remain->pbase = curr.pbase + curr.size;
//         remain->vbase = curr.vbase + curr.size;
//         /*将内存区域加入红黑树，只是要满足一个红黑树节点占用的内存size，否则认为是碎片*/
//         dprintf("after align\n");
//         dprintf("remain->pbase:0x%x,remain->vbase:0x%x,remain->size:0x%x\n",remain->pbase,remain->vbase,remain->size);
//         dprintf("curr->pbase:0x%x,curr->vbase:0x%x,curr->size:0x%x\n\n",curr.pbase,curr.vbase,curr.size);

//         if(curr.size > sizeof(rbnode_t))
//         {
//             ((rbnode_t *)curr.vbase)->data = curr.size;
//             rbtree_insert(&rbtree, (rbnode_t*)curr.vbase, compare_less);
//         }
//         else
//             fragment += curr.size;
//     }
    
//     fragment += remain->size;

//     dprintf("****************add_region end****************\n");
//     return;
// }

static void BOOTONLY add_region(region_t *remain)
{
    region_t curr;
    
    assert((remain->pbase & 0x7) == 0); //8字节对齐
    assert((remain->vbase & 0x7) == 0);
    dprintf("************start add_region***************\n");
    
    while(remain->size >= sizeof(rbnode_t))
    {
        curr.pbase = remain->pbase;
        curr.size = remain->size;
        curr.vbase = remain->vbase;
        dprintf("before align\n");
        dprintf("remain->pbase:0x%x,remain->vbase:0x%x,remain->size:0x%x\n",remain->pbase,remain->vbase,remain->size);
        
        shrink_region(&curr, (region_t*)&kernelinfo, sizeof(image_info_t)/sizeof(region_t));
		dprintf("after shrink kernelinfo curr->pbase:0x%x,curr->vbase:0x%x,curr->size:0x%x\n\n",curr.pbase,curr.vbase,curr.size);
        shrink_region(&curr, (region_t*)&rootserverinfo, sizeof(image_info_t)/sizeof(region_t));
		dprintf("after rootserverinfo curr->pbase:0x%x,curr->vbase:0x%x,curr->size:0x%x\n\n",curr.pbase,curr.vbase,curr.size);
		/*主要是为了计算之后对齐pbase时产生的碎片*/
        if((curr.pbase & 0x7) > 0)
        {
            curr.size -= 8 - ( curr.pbase & 0x7);
            fragment += 8 - ( curr.pbase & 0x7);
        }
        curr.size &= ~(0x7);
        curr.pbase = align_to(curr.pbase, 8);
        /*更新对应的虚拟地址*/
        curr.vbase += curr.pbase - remain->pbase;
		/*curr中是此次循环中需要加到红黑树中的内存配置，更新下一次循环中的remain*/
		remain->size = remain->pbase + remain->size - (curr.pbase + curr.size);
        remain->pbase = curr.pbase + curr.size;
        remain->vbase = curr.vbase + curr.size;
        /*将内存区域加入红黑树，只是要满足一个红黑树节点占用的内存size，否则认为是碎片*/
        dprintf("after align\n");
        dprintf("remain->pbase:0x%x,remain->vbase:0x%x,remain->size:0x%x\n",remain->pbase,remain->vbase,remain->size);
        dprintf("curr->pbase:0x%x,curr->vbase:0x%x,curr->size:0x%x\n\n",curr.pbase,curr.vbase,curr.size);

        if(curr.size > sizeof(rbnode_t))
        {
            ((rbnode_t *)curr.vbase)->data = curr.size;
            rbtree_insert(&rbtree, (rbnode_t*)curr.vbase, compare_less);
        }
        else
            fragment += curr.size;
    }
    
    fragment += remain->size;

    dprintf("****************add_region end****************\n");
    return;
}


void* BOOTONLY allocator_alloc_block(unsigned int size, unsigned int align)
{
    rbnode_t *cur = rbtree_left_most(&rbtree);

    while(cur != 0)
    {
        unsigned long base = align_to((unsigned long)cur, align);
        unsigned long end = (unsigned long)cur + cur->data;

        if(end - base >= size)
        {
            allocator_alloc(base, size);
            return (void*)base;
        }

        cur = rbnode_next(&rbtree, cur);
    }

    return 0;
}

void BOOTONLY allocator_init(void)
{
    int i = 0;
    region_t remain;
    
    rbtree_head_init(&rbtree);
    fragment = 0;
    
    while(ksram[i].size > 0)
    {
        remain.pbase = ksram[i].pbase;
        remain.vbase = ksram[i].vbase;
        remain.size = ksram[i].size;
        
        add_region(&remain);
        i++;
    }
}
