#include <tools/macros.h>
#include <tools/list.h>

#include <notification.h>
#include <schedule.h>

#include <uapi/errors.h>

void notification_init(notification_t *ntfn)
{
    list_init(&ntfn->waiters);
    ntfn->state = NTFN_IDLE;
    ntfn->count = 0;
    object_init(&ntfn->obj);
}

static inline void notification_enque(notification_t *ntfn, tcb_t *task)
{
    tcb_get(task);
    schedule_detach(task);
    
    task_set_state(task, TASK_BLOCKED);
    list_append(&ntfn->waiters, &task->runlist); // TODO: according to priority
}

static inline int notification_deque(tcb_t *task)
{
    list_remove(&task->runlist);
    task_set_state(task, TASK_READY);
    
    return tcb_put(task);
}

void notification_wait(notification_t *ntfn, tcb_t* receiver, int block)
{
    switch(ntfn->state)
    {
        case NTFN_WAIT:
        case NTFN_IDLE:
            if(block == 0)
                task_set_retcode(receiver, -EAGAIN);
            else
            {
                notification_enque(ntfn, receiver);
                ntfn->state = NTFN_WAIT;
            }
            break;
        
        case NTFN_ACTIVE:
            ntfn->count--;
            task_set_retcode(receiver, ESUCCESS);
        
            if(ntfn->count == 0)
                    ntfn->state = NTFN_IDLE;
            break;
        
        default:
            task_set_retcode(current(), -EINVALID);
            break;
    }
}

void notification_signal(notification_t *ntfn, tcb_t *sender)
{
    tcb_t *receiver;
    
    if(sender != 0)
        task_set_retcode(sender, ESUCCESS);
    
    switch(ntfn->state)
    {
        case NTFN_ACTIVE:
        case NTFN_IDLE:
            ntfn->count++;
            ntfn->state = NTFN_ACTIVE;
            break;
        
        case NTFN_WAIT:
            assert(!list_is_empty(&ntfn->waiters));
        
            receiver = container_of(ntfn->waiters.next, tcb_t, runlist);
            if(notification_deque(receiver) == 0)
                return;
            
            task_set_retcode(receiver, ESUCCESS);
            schedule_attach(receiver);
            
            if(list_is_empty(&ntfn->waiters))
                ntfn->state = NTFN_IDLE;
            break;
        
        default:
            task_set_retcode(sender, -EINVALID);
            break;
    }
}

void notification_cancel(notification_t *ntfn)
{
    tcb_t *waiter;
    
    while(list_is_empty(&ntfn->waiters))
    {
        waiter = container_of(ntfn->waiters.next, tcb_t, runlist);
        if(notification_deque(waiter) == 0)
            continue;
        
        task_set_retcode(waiter, -ECANCELED);
        schedule_attach(waiter);
    }
    
    ntfn->state = NTFN_DIED;
}
