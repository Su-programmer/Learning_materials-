/*********************************************************
*
*********************************************************/
#include <config.h>

#include <stdlib/ks_stdint.h>
#include <stdlib/ks_string.h>

#include <schedule.h>
#include <task.h>
#include <timer.h>

#include <arch/cpu.h>

#include <utils.h>



schedule_data_t sd[CONFIG_TOTAL_CORES];

static inline schedule_data_t *current_schedule_data(void)
{
#ifdef CONFIG_ENABLE_SMP
    return sd + current_cpu();
#else
    return sd;
#endif
}

// if there is 1 in bitmap, return the index of it
// 得到最高的优先级
static unsigned int bitmap_first_1(const schedule_data_t *sd)
{
    unsigned int l1index;
    unsigned int l2index;

    l1index = clz(sd->lvl1bit);
    l2index = clz(sd->lvl2bit[l1index]); //这位得到最高的优先级

    return l1index * ULONG_BITS + l2index;
}

static inline int bitmap_is_empty(const schedule_data_t *sd)
{
    return sd->lvl1bit == 0;
}

static inline void bitmap_set(schedule_data_t *sd, unsigned int index)
{
    unsigned int l1index = index / ULONG_BITS;
    unsigned int l2index = index % ULONG_BITS;

    assert(index < sizeof(sd->lvl2bit) * 8);

    sd->lvl2bit[l1index] |= ULONG_LEFT_MOST_BIT >> l2index;
    sd->lvl1bit |= ULONG_LEFT_MOST_BIT >> l1index;
}

static inline void bitmap_clean(schedule_data_t *sd, unsigned int index)
{
    unsigned int l1index = index / ULONG_BITS;
    unsigned int l2index = index % ULONG_BITS;

    assert(index < sizeof(sd->lvl2bit) * 8);

    sd->lvl2bit[l1index] &= ~(ULONG_LEFT_MOST_BIT >> l2index);

    if (sd->lvl2bit[l1index] == 0)
        sd->lvl1bit &= ~(ULONG_LEFT_MOST_BIT >> l1index);
}

static inline void bitmap_init(schedule_data_t *sd)
{
    sd->lvl1bit = 0;
    ks_memset(sd->lvl2bit, 0, sizeof(sd->lvl2bit));
}

static inline int readyqueue_is_empty(const schedule_data_t *sd)
{
    return bitmap_is_empty(sd);
}

static void readyqueue_deque(schedule_data_t *sd, tcb_t *tcb)
{
    list_remove(&tcb->runlist);

    if (list_is_empty(&sd->readyqueue[tcb->priority]))
        bitmap_clean(sd, tcb->priority);
}

static void readyqueue_append(schedule_data_t *sd, tcb_t *tcb)
{
    assert(tcb->state == TASK_READY);

    if (list_is_empty(&sd->readyqueue[tcb->priority]))
        bitmap_set(sd, tcb->priority);

    list_append(&sd->readyqueue[tcb->priority], &tcb->runlist);
}

static void readyqueue_enque(schedule_data_t *sd, tcb_t *tcb)
{
    assert(tcb->state == TASK_READY);

    if (list_is_empty(&sd->readyqueue[tcb->priority]))
        bitmap_set(sd, tcb->priority);

    list_insert(&sd->readyqueue[tcb->priority], &tcb->runlist);
}

//选择出最高优先级的，最先进入的task
static tcb_t *readyqueue_next(schedule_data_t *sd)
{
    int first = bitmap_first_1(sd);
    tcb_t *next;

    assert(first < CONFIG_MAX_PRIORITY);

    next = container_of(sd->readyqueue[first].next, tcb_t, runlist);
    readyqueue_deque(sd, next);

    return next;
}

static void pendqueue_enque(schedule_data_t *sd, tcb_t *tcb)
{
    tcb_t *cur;
    list_t *pos = sd->pendqueue.prev;

    list_foreach(cur, &sd->pendqueue, tcb_t, runlist)
    {
        if (cur->readytime > tcb->readytime)
        {
            pos = cur->runlist.prev;
            break;
        }
    }

    list_insert(pos, &tcb->runlist);
}

static inline void pendqueue_deque(schedule_data_t *sd, tcb_t *task)
{
    list_remove(&task->runlist);
}

void schedule_init(tcb_t *idle)
{
    int i;
    schedule_data_t *sd = current_schedule_data();

    list_init(&sd->pendqueue);

    i = sizeof(sd->readyqueue) / sizeof(list_t);
    while (i-- > 0)
        list_init(sd->readyqueue + i);

    bitmap_init(sd);

    sd->pidle = idle;
    tcb_get(sd->pidle);

    sd->pcurrent = sd->pidle;
    sd->action = ACTION_RUN_CURRENT;
}

void schedule_wakeup(unsigned int currenttime)
{
    tcb_t *cur;
    schedule_data_t *sd = current_schedule_data();
    unsigned int priority = task_get_priority(current());

    //判断pendqueue是否为空，如果不为空则执行下面的操作
    while (!list_is_empty(&sd->pendqueue))
    {
        //pandqueue队列中的task是按照时间排列的,所以如果第一个task时间不满足那么其他的task也不满足
        cur = container_of(sd->pendqueue.next, tcb_t, runlist);
        if (timer_expired(cur->readytime)) //准备时间完成
        {
            if (task_get_priority(cur) < priority) //优先级更高
                sd->action = ACTION_CHOOSE_NEW;

            list_remove(&cur->runlist);
            cur->state = TASK_READY;
            readyqueue_append(sd, cur); //添加到readyqueue
        }
        else
            break;
    }
}

void schedule_run(tcb_t *task)
{
    assert(list_is_empty(&task->runlist));
    schedule_data_t *sd = current_schedule_data();

    if (sd->action == 0)
    {
        tcb_get(task);
        sd->action = task;
    }
    else if (sd->action != task)
    {
        readyqueue_enque(sd, sd->action);

        tcb_get(task);
        sd->action = task;
    }
    else
        /*do nothing*/;
}

// if the task is not belong to the scheduler, put it
static void task_enque(schedule_data_t *sd, tcb_t *task)
{
    switch (task->state)
    {
    case TASK_READY:
        //todo but,暂时解决长时间运行内核崩溃的问题
        task->readytime = timer_current();
        assert(timer_expired(task->readytime));
        readyqueue_append(sd, task);
        break;

    case TASK_SLEEP:
        assert(!timer_expired(task->readytime));
        pendqueue_enque(sd, task);
        break;

    case TASK_IDLE:
        // do nothing for idle task
        break;

    default:
        // we lose the control of the task, put it
        tcb_put(task);
        break;
    }
}

void schedule_attach(tcb_t *task)
{
    schedule_data_t *sd = current_schedule_data();

    assert(list_is_empty(&task->runlist) && task != current() && task != sd->pidle);

    if (task->priority <= current()->priority)
        sd->action = ACTION_CHOOSE_NEW;

    tcb_get(task);
    task_enque(sd, task);
}

void schedule_detach(tcb_t *task)
{
    schedule_data_t *sd = current_schedule_data();

    if (task == current())
    {
        if (readyqueue_is_empty(sd))
            sd->action = ACTION_RUN_IDLE;
        else
            sd->action = ACTION_CHOOSE_NEW;

        // we will put it when schedule()->task_enque()
    }
    else if (task->state == TASK_READY)
    {
        readyqueue_deque(sd, task);
        if (readyqueue_is_empty(sd))
            sd->action = ACTION_RUN_IDLE;
        tcb_put(task);
    }
    else
    {
        pendqueue_deque(sd, task);
        tcb_put(task);
    }
}

//#define ENABLE_PERFORMANT_TEST
#define PERFORMANCE_COUNTER_INCREASE
#ifdef ENABLE_PERFORMANT_TEST
static inline unsigned long ts(void)
{
#if 1
    // PMU cycle counter, ARMv7-a
    unsigned long ret;
    __asm__ __volatile__("mrc p15, 0, %0, c9, c13, 0\n"
                         : "=r"(ret)
                         :);
    return ret;
#else
    // systick counter, ARMv7-M
    return *(volatile uint32_t *)0xE000E018;
#endif
}
#endif

int memcmp(const void *buffer1, const void *buffer2, int count)

{

    if (!count)

        return (0);

    while (--count && *(char *)buffer1 == *(char *)buffer2)

    {

        buffer1 = (char *)buffer1 + 1;

        buffer2 = (char *)buffer2 + 1;
    }

    return (*((unsigned char *)buffer1) - *((unsigned char *)buffer2));
}

void schedule(void)
{
#ifdef ENABLE_PERFORMANT_TEST
    unsigned long begin = ts();
    unsigned long end;
    static unsigned long tscount = 0;
    static unsigned long tss = 0;
    static unsigned long max = 0;
#endif

    tcb_t *prev = current();
    tcb_t *next;
    schedule_data_t *sd = current_schedule_data();

    if (sd->action == ACTION_CHOOSE_NEW)
    {
        next = readyqueue_next(sd);
        task_enque(sd, prev); //保存当前task
        if (readyqueue_is_empty(sd))
            sd->action = ACTION_RUN_CURRENT;
    }
    else if (sd->action == ACTION_RUN_CURRENT)
    {
        return;
    }
    else if (sd->action == ACTION_RUN_IDLE)
    {
        next = sd->pidle;
        task_enque(sd, prev);
        sd->action = ACTION_RUN_CURRENT;
    }
    else
    {
        next = sd->action;
        task_enque(sd, prev);
        if (!readyqueue_is_empty(sd))
            sd->action = ACTION_CHOOSE_NEW;
    }

#ifdef ENABLE_PERFORMANT_TEST
    end = ts();
#ifdef PERFORMANCE_COUNTER_INCREASE
    {
        unsigned long tmp = end;
        end = begin;
        begin = tmp;
    }
#endif
    if (begin > end)
    {
        tscount++;
        tss += begin - end;

        if (begin - end > max)
            max = begin - end;

        if (tscount % 5 == 0)
        {
            dprintf("%s(): count = %d, total = %d, avr = %d, max = %d\n", __FUNCTION__,
                    tscount, tss, tss / tscount, max);
        }
    }
#endif

    sd->pcurrent = next;

    if (memcmp(next->name, "shell_handler", sizeof("shell_handler")) == 0)
    {
        dprintf("PC = %x, LR = %x \n", next->context.regs[PC], next->context.regs[LR]);
    }

    if (next != prev)
        task_switch_prepare(next, prev);
}
