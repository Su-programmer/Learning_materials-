#include <uapi/ipcbuffer.h>
#include <uapi/errors.h>

#include <caps/capability.h>

#include <schedule.h>
#include <task.h>

#include <arch/smc.h>

void cap_armsmc_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1)
{
    ipcbuffer_t* buf = task_get_ipcbuffer(current());
    unsigned long *msg = ipcbuffer_get_msgs(buf);
    unsigned int msglen = msgtag_get_len(tag);
    unsigned int reply;

    msg[0] = m0;
    msg[1] = m1;

    reply = do_smc(msg, msglen);
    ipcbuffer_set_tag(buf, reply, 0, 0);
    task_set_retcode(current(), ESUCCESS);
}