
/****************************************************************************************
                    Capability Operations For Notification
****************************************************************************************/
#include <uapi/ipcops.h>
#include <uapi/errors.h>

#include <notification.h>
#include <schedule.h>

#include <caps/notification.h>

static inline void cap_ntfn_set_obj(capability_t *cap, notification_t *obj)
{
    cap_set_long_info(cap, (unsigned long)obj);
}

void cap_ntfn_init(capability_t *cap, notification_t *obj)
{
    notification_get(obj);
    cap_basic_init(cap, CAP_NTFN);
    cap_ntfn_set_obj(cap, obj);
}

void cap_ntfn_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1)
{
    notification_t *ntfn = cap_ntfn_get_obj(cap);
    
    switch(msgtag_get_op(tag))
    {
        case CAP_NTFN_OP_WAIT:
            notification_wait(ntfn, current(), msgtag_get_extra(tag) == 0); // '== 0' means do block wait
            break;
        
        case CAP_NTFN_OP_SIGNAL:
            notification_signal(ntfn, current());
            break;
        
        case CAP_NTFN_OP_CANCEL:
            notification_cancel(ntfn);
            notification_put(ntfn);
            break;
        
        default:
            task_set_retcode(current(), -ENOSYS);
            break;
    }
}
