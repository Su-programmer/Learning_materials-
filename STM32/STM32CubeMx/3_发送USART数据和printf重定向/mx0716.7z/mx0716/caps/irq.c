/****************************************************************************************
                            Capability Operations For IRQ
****************************************************************************************/
#include <interrupt.h>
#include <schedule.h>

#include <uapi/ipcops.h>
#include <uapi/errors.h>

#include <caps/capability.h>
#include <caps/irq.h>
#include <caps/cnode.h>

void cap_irqc_init(capability_t *cap)
{
    cap_basic_init(cap, CAP_IRQ_CONTROL); // todo: add irq number range?
}

static inline void cap_irqh_set_obj(capability_t *cap, notification_t *ntfn)
{
    cap_set_long_info(cap, (unsigned long)ntfn);
}

static inline notification_t *cap_irqh_get_obj(capability_t *cap)
{
    return (notification_t *)cap_get_long_info(cap);
}

void cap_irqh_init(capability_t *cap, notification_t *ntfn)
{
    cap_basic_init(cap, CAP_IRQ_HANDLER);
    cap_irqh_set_obj(cap, ntfn);
}

void cap_irqc_dispatcher(capability_t *cap, unsigned long tag, unsigned long cptr, unsigned long irqn)
{
    capability_t *to = cnode_cptr_lookup(task_get_cnode(current()), cptr, sizeof(unsigned long)*8);
    notification_t *ntfn;
    long retcode = -ENOSYS;
    
    switch(msgtag_get_op(tag))
    {
        case CAP_IRQ_OP_GET:
            if(cap_is_empty(to))
            {
                ntfn = irq_register(irqn);
                if(ntfn != 0)
                {
                    cap_irqh_init(to, ntfn);
                    retcode = ESUCCESS;
                }
                else
                    retcode = -EINVALID;
            }
            else
                retcode = -EOVERLAP;
            break;
        
        case CAP_IRQ_OP_PUT: // todo: duplicated operation
            if(cap_get_type(to) == CAP_IRQ_HANDLER)
            {
                ntfn = cap_irqh_get_obj(to);
                irq_unregister(ntfn);
                cap_make_empty(to);
                retcode = ESUCCESS;
            }
            else
                retcode = -EINVALID;
            break;
        
        default:
            retcode = -ENOSYS;
            break;
    }
    
    task_set_retcode(current(), retcode);
}

void cap_irqh_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1)
{
    notification_t *ntfn = (void*)cap_irqh_get_obj(cap);
    
    switch(msgtag_get_op(tag))
    {
        case CAP_IRQ_OP_WAIT:
            irq_prepare_wait(ntfn);
            notification_wait(ntfn, current(), 1);
            break;
        
        case CAP_IRQ_OP_ACK:
            irq_ack_enable(ntfn);
            task_set_retcode(current(), ESUCCESS);
            break;
        
        case CAP_IRQ_OP_ACK_WAIT:
            irq_ack_enable(ntfn);
            notification_wait(ntfn, current(), 1);
            break;
        
        case CAP_IRQ_OP_PUT:
            irq_unregister(ntfn);
            cap_make_empty(cap);
            task_set_retcode(current(), ESUCCESS);
            break;
        
        default:
            task_set_retcode(current(), -ENOSYS);
            break;
    }
}
