#include <caps/mutex.h>
#include <schedule.h>
#include <uapi/ipcops.h>
#include <uapi/errors.h>

static inline void cap_mutex_set_obj(capability_t *cap,mutex_t *obj)
{
	cap_set_long_info(cap,(unsigned long)obj);
}

#include <dprintf.h>
void cap_mutex_init(capability_t *cap,mutex_t *obj)
{
	mutex_get(obj);
	cap_basic_init(cap, CAP_MUTEX);
	cap_mutex_set_obj(cap, obj);
}

void cap_mutex_dispacher(capability_t *cap, unsigned long tag,unsigned long m0, unsigned long m1)
{
	mutex_t *mutex = cap_mutex_get_obj(cap);
	switch(msgtag_get_op(tag))
  {
		case CAP_MUTEX_OP_LOCK:
			mutex_lock(mutex);
			break;
		
		case CAP_MUTEX_OP_UNLOCK:		    
			mutex_unlock(mutex);
			break;
			
		case CAP_MUTEX_OP_TRYLOCK:
			task_set_retcode(current(), mutex_trylock(mutex));
			break;
			
		default:
			task_set_retcode(current(), -ENOSYS);
      break;
	}
}

