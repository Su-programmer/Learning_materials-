#include <uapi/ipcops.h>
#include <uapi/errors.h>

#include <schedule.h>
#include <task.h>

#include <caps/capability.h>
#include <caps/cnode.h>
#include <caps/task.h>

static void cap_task_set_obj(capability_t *cap, tcb_t *tcb)
{
    cap_set_long_info(cap, (unsigned long)tcb);
}

void cap_task_init(capability_t *cap, tcb_t *tcb)
{
    assert(tcb != 0);
    
    tcb_get(tcb);
    cap_basic_init(cap, CAP_THREAD);
    cap_task_set_obj(cap, tcb);
}

// todo: this is not good
static int handle_clone(capability_t *target, unsigned long cptr, unsigned long id)
{
    tcb_t *src = current();
    
    if(cptr != 0)
    {
        capability_t* cap = cnode_cptr_lookup(task_get_cnode(current()), cptr, sizeof(unsigned long)*8);
        if(cap == 0 || cap_get_type(cap) != CAP_THREAD)
            return -ENOCAP;
        
        src = cap_task_get_obj(cap);
    }
    
    task_clone(cap_task_get_obj(target), src, id);
    return ESUCCESS;
}

static int handle_config(capability_t* cap, unsigned int msglen, unsigned long entry, unsigned long ipcbuffer)
{
    tcb_t *task = cap_task_get_obj(cap);
    
    unsigned long* args = ipcbuffer_get_msgs(task_get_ipcbuffer(current()));
    unsigned long stack = args[2];
    unsigned long stacklen = args[3];

    unsigned long maxpriority = task_get_maxpriority(current());
    unsigned long priority = (args[4] < maxpriority) ? maxpriority : args[4];
    unsigned int timeslice = args[5];
    
    if(msglen < 5 || ipcbuffer == 0 || stack == 0 || stacklen < CONFIG_PAGE_SIZE || entry == 0)
        return -EINVALID;
    
    // todo: check if the stack and ipcbuffer is ok
    task_set_stack(task, (void*)stack, (void*)ipcbuffer, stacklen);
    task_set_entry(task, entry);

    unsigned int elf = args[7];
    task->addrspace = thread_addrsapce_init(elf);//����ĵ�ַ�ռ�
    
    // configure the priority
    if(priority >= CONFIG_MAX_PRIORITY)
        priority = CONFIG_MAX_PRIORITY - 1;
    // set timeslice
    task_set_timeslice(task, timeslice);
    // set priority
    task_set_priority(task, priority);
    task_set_maxpriority(task, priority);
    
    task_set_retcode(task, args[6]);
    if(msglen > 7)
        task_set_reg_param(task, args[7], args[8], args[9]);
    
    // todo: only for test
    task_set_state(task, TASK_READY);
    schedule_attach(task);
    
    return ESUCCESS;
}

void cap_task_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1)
{
    switch(msgtag_get_op(tag))
    {
        case CAP_THREAD_CLONE:
            task_set_retcode(current(), handle_clone(cap, m0, m1));
            break;

        case CAP_THREAD_CONFIG:
            task_set_retcode(current(), handle_config(cap, msgtag_get_len(tag), m0, m1));
            break;

        default:
            task_set_retcode(current(), -ENOSYS);
            break;
    }
}
