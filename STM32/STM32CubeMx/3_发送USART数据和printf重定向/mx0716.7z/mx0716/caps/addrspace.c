/****************************************************************************************
                            Capability Operations For Address Space
****************************************************************************************/
#include <caps/capability.h>
#include <caps/addrspace.h>

#include <addrspace.h>

static inline void cap_addrspace_set_obj(capability_t *cap, addrspace_t *as)
{
    cap_set_long_info(cap, (unsigned long)as);
}

void cap_addrspace_init(capability_t *cap, addrspace_t *as)
{
    addrspace_get(as);
    cap_basic_init(cap, CAP_ADDRSPACE);
    cap_addrspace_set_obj(cap, as);
}

int cap_addrspce_map(capability_t *cap, unsigned long begin, unsigned int size) // todo: attribute
{
    addrspace_t *as = cap_addrspace_get_obj(cap);

    return addrspace_map(as, &begin, &begin, &size, 0);
}
