/****************************************************************************************
                         Gerneral Capability Operations
****************************************************************************************/
#include <config.h>

#include <stdlib/assert.h>
#include <stdlib/ks_stdint.h>

#include <tools/macros.h>

#include <uapi/errors.h>
#include <uapi/ipcbuffer.h>
#include <uapi/ipcops.h>
#include <uapi/initialcaps.h>

#include <task.h>
#include <schedule.h>
#include <allocate.h>
#include <notification.h>
#include <endpoint.h>
#include <addrspace.h>
#include <task.h>

#include <caps/capability.h>
#include <caps/addrspace.h>
#include <caps/cnode.h>
#include <caps/irq.h>
#include <caps/notification.h>
#include <caps/endpoint.h>
#include <caps/ram.h>
#include <caps/task.h>
#include <caps/armsmc.h>
#include <caps/mutex.h>

capability_t SHARED_BSS ALIGNED(1 << CAP_TYPE_BITS)
    initial_cspace[1 << CONFIG_INITIAL_CNODE_RADIX];

const unsigned int SHARED_RO capobj_size[] = {
    [CAP_EMPTY] = 0,
    [CAP_CNODE] = sizeof(capability_t) * (1ul << CONFIG_THREAD_CNODE_RADIX),
    [CAP_NTFN] = sizeof(notification_t),
    [CAP_EP] = sizeof(endpoint_t),
    [CAP_IRQ_CONTROL] = 0,
    [CAP_IRQ_HANDLER] = 0,
    [CAP_THREAD] = sizeof(tcb_t),
    [CAP_RAM] = 0,
    [CAP_ADDRSPACE] = sizeof(addrspace_t),
    [CAP_ARMSMC] = 0,
    [CAP_MUTEX] = sizeof(mutex_t),
    [CAP_COUNT] = 0,
};

const cap_dispather_t capdispathers[] = {
    [CAP_CNODE] = cap_cnode_dispatcher,
    [CAP_IRQ_CONTROL] = cap_irqc_dispatcher,
    [CAP_IRQ_HANDLER] = cap_irqh_dispatcher,
    [CAP_EP] = cap_ep_dispatcher,
    [CAP_NTFN] = cap_ntfn_dispatcher,
    [CAP_RAM] = cap_ram_dispatcher,
    [CAP_THREAD] = cap_task_dispatcher,
    [CAP_ADDRSPACE] = 0, // todo
#ifdef CONFIG_FORWARD_SMC
    [CAP_ARMSMC] = cap_armsmc_dispatcher,
#endif
    [CAP_MUTEX] = cap_mutex_dispacher,
    [CAP_COUNT] = 0,
};

//#define ENABLE_PERFORMANT_TEST
#define PERFORMANCE_COUNTER_INCREASE
#ifdef ENABLE_PERFORMANT_TEST
static inline unsigned long ts(void)
{
#if 1
    // PMU cycle counter, ARMv7-a
    unsigned long ret;
    __asm__ __volatile__("mrc p15, 0, %0, c9, c13, 0\n"
                         : "=r"(ret)
                         :);
    return ret;
#else
    // systick counter, ARMv7-M
    return *(volatile uint32_t *)0xE000E018;
#endif
}
#endif

//#define DEBUG_DUMP_SVC
void cap_dispatcher(unsigned long cptr, unsigned long tag, unsigned long m0, unsigned long m1)
{
#ifdef ENABLE_PERFORMANT_TEST
    unsigned long begin = ts();
    unsigned long end;
    static unsigned long tscount = 0;
    static unsigned long tss = 0;
    static unsigned long max = 0;
#endif
    capability_t *cap = cnode_cptr_lookup(task_get_cnode(current()), cptr, sizeof(unsigned long) * 8);
    unsigned int type = cap_get_type(cap);

    assert(type < CAP_COUNT);

#ifdef DEBUG_DUMP_SVC
    dprintf("Caps Dispatcher: %x\n", cptr);
    dprintf("TAG info: len(%d bytes), op(%d), extra(0x%x).\n",
            msgtag_get_len(tag), msgtag_get_op(tag), msgtag_get_extra(tag));
    dprintf("Messages in IPCbuffer:\n");
    if (msgtag_get_len(tag) > 2)
    {
        int i;
        for (i = 2; i < msgtag_get_len(tag); i++)
            dprintf("  [%d] = 0x%x\n", i, ipcbuffer_get_msgs(task_get_ipcbuffer(current()))[i]);
    }
    else
        dprintf("  None!\n");
#endif

    if (cap == 0 || capdispathers[type] == 0)
        task_set_retcode(current(), -ENOCAP);
    else
        capdispathers[type](cap, tag, m0, m1);

#ifdef ENABLE_PERFORMANT_TEST
    end = ts();
#ifdef PERFORMANCE_COUNTER_INCREASE
    {
        unsigned long tmp = end;
        end = begin;
        begin = tmp;
    }
#endif
    if (begin > end)
    {
        tscount++;
        tss += begin - end;

        if (begin - end >= 10000)
        {
            dprintf("Caps Dispatcher: %x\n", cptr);
            dprintf("TAG info: len(%d bytes), op(%d), extra(0x%x).\n",
                    msgtag_get_len(tag), msgtag_get_op(tag), msgtag_get_extra(tag));
            dprintf("Messages in IPCbuffer:\n");
            if (msgtag_get_len(tag) > 2)
            {
                int i;
                for (i = 2; i < msgtag_get_len(tag); i++)
                    dprintf("  [%d] = 0x%x\n", i, ipcbuffer_get_msgs(task_get_ipcbuffer(current()))[i]);
            }
            else
                dprintf("  None!\n");
        }

        if (begin - end > max)
            max = begin - end;

        if (tscount % 5 == 0)
        {
            dprintf("%s(): count = %d, total = %d, avr = %d, max = %d\n", __FUNCTION__,
                    tscount, tss, tss / tscount, max);
        }
    }
#endif
}

capability_t *BOOTONLY initial_cspace_init(void *init, void *addrspace, void *faulthandler)
{
    capability_t *cspace;
    capability_t *cur;

    cspace = initial_cspace;
    assert(cspace != 0);

    // initial reference count and spin lock
    cspace_audit_init(cspace + CAP_INDEX_AUDIT);

    cur = cspace + CAP_INDEX_FAULTHANDLER;
    cap_ep_init(cur, faulthandler, 0);

    cur = cspace + CAP_INDEX_THREAD;
    cap_task_init(cur, init);

    cur = cspace + CAP_INDEX_ADDRSPACE;
    cap_addrspace_init(cur, addrspace);

    cur = cspace + CAP_INDEX_IRQ_CONTROL;
    cap_irqc_init(cur);

    cur = cspace + CAP_INDEX_COUNT;
#ifdef CONFIG_FORWARD_SMC
    cap_armsmc_init(cur++); // todo: ARM Only
#endif
    while (cur != (cspace + CONFIG_INITIAL_CNODE_COUNT))
    {
        cap_make_empty(cur);
        cur++;
    }

    return cspace;
}

static capability_t *BOOTONLY create_caps_for_region(const region_t *reg, capability_t *cur, unsigned int type)
{
    while (reg->size != 0)
    {
        assert(cap_is_empty(cur) && cur != (initial_cspace + CONFIG_INITIAL_CNODE_COUNT));

        cap_ram_init(cur, (unsigned long)reg, type, reg->directmap);

        cur++;
        reg++;
    }

    return cur;
}

int BOOTONLY initial_cspace_lock_ram(void)
{
    extern const region_t ksram[];
    extern const region_t usram[];
    extern const region_t usdev[];
    extern const region_t usshmram[];
    capability_t *cur;

    cur = initial_cspace + CAP_INDEX_RAM_KERNEL;
    cap_ram_init(cur, (unsigned long)allocator_get_rbtree(), CAP_RAM_KERNEL, ksram[0].directmap);

    cur = initial_cspace + CAP_INDEX_RAM_ROOTSERVER;
    cap_ram_init(cur, (unsigned long)&usram[0], CAP_RAM_NORMAL, usram[0].directmap);

    // find the start of free caps
    while (cur != (initial_cspace + CONFIG_INITIAL_CNODE_COUNT) && !cap_is_empty(cur))
        cur++;

    cur = create_caps_for_region(&usram[1], cur, CAP_RAM_NORMAL);
    cur = create_caps_for_region(&usshmram[0], cur, CAP_RAM_SHM);
    create_caps_for_region(usdev, cur, CAP_RAM_DEVICE);

    return cur - initial_cspace;
}
