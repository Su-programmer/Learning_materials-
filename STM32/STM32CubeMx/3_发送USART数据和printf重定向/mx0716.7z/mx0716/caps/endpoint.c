/****************************************************************************************
                     Capability Operations For Endpoint
****************************************************************************************/
#include <uapi/errors.h>
#include <uapi/ipcops.h>
#include <uapi/ipcbuffer.h>

#include <endpoint.h>
#include <schedule.h>
#include <dprintf.h>

#include <caps/capability.h>
#include <caps/endpoint.h>

static inline void cap_ep_set_obj(capability_t *cap, endpoint_t *obj)
{
    assert(((unsigned long)obj & 0x3) == 0);

    cap_set_long_info(cap, (unsigned long)obj);
}

static inline unsigned int cap_ep_get_id(capability_t *cap)
{
    return (cap_get_short_info(cap) >> CAP_EP_ATTR_BIT_ID_BEGIN) 
        & lowbitsmask(CAP_EP_ATTR_BIT_ID_WIDTH);
}

static inline void cap_ep_set_id(capability_t *cap, unsigned int id)
{
    cap_set_short_info(cap, id);
}

void cap_ep_init(capability_t *cap, endpoint_t* obj, unsigned int id)
{
    endpoint_get(obj);
    cap_basic_init(cap, CAP_EP);
    cap_ep_set_obj(cap, obj);
    cap_ep_set_id(cap, id);
}

void cap_ep_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1)
{
    endpoint_t *ep = cap_ep_get_obj(cap); 
    switch(msgtag_get_op(tag))
    {
        // todo: check if call only
        case CAP_EP_OP_SEND:
            tag = msgtag_set_id(tag, cap_ep_get_id(cap));
            endpoint_send(ep, tag, m0, m1, current());
            break;
        
        case CAP_EP_OP_RECV:
            endpoint_receive(ep, tag, current());
            break;
        
        case CAP_EP_OP_CALL:
            tag = msgtag_set_id(tag, cap_ep_get_id(cap));
            endpoint_call(ep, tag, m0, m1, current());
            break;
        
        case CAP_EP_OP_REPLY:
            endpoint_reply(ep, tag, m0, m1, current());
            break;
        
        case CAP_EP_OP_REPLY_WAIT:
            endpoint_reply_wait(ep, tag, m0, m1, current());
            break;
        
        case CAP_EP_OP_CANCEL:
            endpoint_cancel(ep);
            task_set_retcode(current(), ESUCCESS);
            break;

        case CAP_EP_OP_BIND:
            endpoint_bind(ep, current());
            break;
        
        case CAP_EP_OP_UNBIND:
            endpoint_unbind(ep, current());
            break;
        
        default:
            task_set_retcode(current(), -ENOSYS);
            break;
    }
}
