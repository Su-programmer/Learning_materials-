/****************************************************************************************
                            Capability Operations For RAM Manage
****************************************************************************************/
#include <stdlib/assert.h>
#include <stdlib/ks_stdint.h>

#include <tools/macros.h>

#include <uapi/ipcops.h>
#include <uapi/ipcbuffer.h>
#include <uapi/errors.h>
#include <uapi/caps/ram.h>

#include <allocate.h>
#include <task.h>
#include <schedule.h>
#include <addrspace.h>

#include <caps/cnode.h>
#include <caps/addrspace.h>
#include <caps/ram.h>
#include <caps/task.h>
#include <caps/endpoint.h>
#include <caps/notification.h>

static inline void cap_ram_set_info(capability_t *cap, unsigned long info)
{
    cap_set_long_info(cap, info);
}

static inline unsigned long cap_ram_mk_info(unsigned long desc, unsigned int direct)
{
    assert((desc & 0x1) == 0);

    if (direct)
        desc |= bitmask(CAP_RAM_ATTR_BIT_D);
    return desc;
}

static inline void cap_ram_set_type(capability_t *cap, unsigned int type)
{
    cap_set_short_info(cap, type);
}

void cap_ram_init(capability_t *cap, unsigned long desc, unsigned int type, unsigned int direct)
{
    cap_basic_init(cap, CAP_RAM);
    cap_ram_set_info(cap, cap_ram_mk_info(desc, direct));
    cap_ram_set_type(cap, type);
}

static inline int ram_check_range(capability_t *cap, unsigned long paddr, unsigned long size)
{
    unsigned int pb = cap_ram_get_pbase(cap);
    unsigned int s = cap_ram_get_size(cap);

    return paddr >= pb && size <= s && (paddr + size <= pb + s);
}

static int handler_mkcap(unsigned long addr, unsigned int type, unsigned long targetslot)
{
    capability_t *slot = 0;
    const unsigned int *objsize = cap_get_capobj_size();
    int ret = -EINVALID;

    if (type >= CAP_COUNT || objsize == 0)
        return ret;

    slot = cnode_cptr_lookup(task_get_cnode(current()), targetslot, sizeof(unsigned long) * 8);
    if (slot == 0)
        return ret;

    if (!cap_is_empty(slot))
    {
        ret = -EOVERLAP;
        return ret;
    }

    if (allocator_alloc(addr, objsize[type]) == 0)
    {
        switch (type)
        {
        case CAP_THREAD:
            task_init((tcb_t *)addr, TTYPE_USER);
            cap_task_init(slot, (tcb_t *)addr);
            ret = ESUCCESS;
            break;

        case CAP_EP:
            endpoint_init((endpoint_t *)addr);
            cap_ep_init(slot, (endpoint_t *)addr, 0);
            ret = ESUCCESS;
            break;

        case CAP_NTFN:
            notification_init((notification_t *)addr);
            cap_ntfn_init(slot, (notification_t *)addr);
            ret = ESUCCESS;
            break;

        case CAP_CNODE: // todo:
            break;

        case CAP_ADDRSPACE: // todo:
            break;

        default:
            break;
        }
    }

    return ret;
}
static int handler_mkcap_ext(unsigned long addr, unsigned int type, unsigned long targetslot)
{
    capability_t *slot = 0;
    const unsigned int *objsize = cap_get_capobj_size();
    int ret = -EINVALID;

    if (type >= CAP_COUNT || objsize == 0)
        return ret;

    slot = cnode_cptr_lookup(task_get_cnode(current()), targetslot, sizeof(unsigned long) * 8);
    if (slot == 0)
        return ret;

    if (!cap_is_empty(slot))
    {
        ret = -EOVERLAP;
        return ret;
    }

    if (allocator_alloc(addr, objsize[type]) == 0)
    {
        switch (type)
        {
        case CAP_THREAD:
            task_init((tcb_t *)addr, TTYPE_USER);
            cap_task_init(slot, (tcb_t *)addr);
            ret = ESUCCESS;
            break;

        case CAP_EP:
            //dprintf("CAP_EP EXT = 0x9527\n");
            endpoint_init((endpoint_t *)addr);
            slot->cap_ext = 0x9527;
            cap_ep_init(slot, (endpoint_t *)addr, 0);
            ret = ESUCCESS;
            break;

        case CAP_NTFN:
            notification_init((notification_t *)addr);
            cap_ntfn_init(slot, (notification_t *)addr);
            ret = ESUCCESS;
            break;

            // case CAP_MUTEX:
            //     mutex_init((mutex_t *)addr);
            //     cap_mutex_init(slot,(mutex_t *)addr);
            //     ret = ESUCCESS;
            //     break;

        case CAP_CNODE: // todo:
            break;

        case CAP_ADDRSPACE: // todo:
            break;

        default:
            break;
        }
    }

    return ret;
}
void cap_ram_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1)
{
    unsigned int type = cap_ram_get_type(cap);
    unsigned long cptr = ipcbuffer_get_msgs(task_get_ipcbuffer(current()))[2];

    task_set_retcode(current(), -ENOSYS);

    switch (msgtag_get_op(tag))
    {
    case CAP_RAM_MKCAP:
        if (type == CAP_RAM_KERNEL && msgtag_get_len(tag) == 3)
        {
            if ((tag >> 24) == 0x95)
            {
                /* handler_mkcap_ext only for elf catch ep */
                task_set_retcode(current(), handler_mkcap_ext(m0, m1, cptr));
            }
            else
            {
                task_set_retcode(current(), handler_mkcap(m0, m1, cptr));
            }
        }
        else
            task_set_retcode(current(), -EPERMIT);
        break;

    case CAP_RAM_FREE:
        if (type == CAP_RAM_KERNEL && allocator_free(m0, m1) == 0) // todo: through caps
            task_set_retcode(current(), ESUCCESS);
        break;

    case CAP_RAM_MAP:
        // dprintf("CAP_RAM_MAP\n");
        if (type != CAP_RAM_KERNEL)
        {

            if (msgtag_get_len(tag) == 5 && ram_check_range(cap, m0, m1))
            {

                capability_t *addrcap;
                addrspace_t *addrspace = 0;
                if (cptr == 0)
                    addrspace = task_get_addrspace(current());
                else
                {
                    addrcap = cnode_cptr_lookup(task_get_cnode(current()), cptr, sizeof(int));
                    if (addrcap != 0)
                        addrspace = cap_addrspace_get_obj(addrcap);
                }

                if (addrspace != 0)
                {
                    unsigned long vbase = ipcbuffer_get_msgs(task_get_ipcbuffer(current()))[3];
                    unsigned long attr = ipcbuffer_get_msgs(task_get_ipcbuffer(current()))[4];
                    unsigned long result = addrspace_map(addrspace, &m0, &vbase, &m1, attr);
                    task_set_retcode(current(), result);
                }
            }
            else if (msgtag_get_len(tag) == 4)
            { //vbase, size, attr

                addrspace_t *addrspace = 0;
                //tcb_t *task = cap_task_get_obj(cap);
                if (cptr != 0)
                {
                    capability_t *cap = cnode_cptr_lookup(task_get_cnode(current()), cptr, sizeof(unsigned long) * 8);
                    tcb_t *task = cap_task_get_obj(cap);
                    addrspace = task->addrspace;
                }
                else
                    addrspace = task_get_addrspace(current());
                //dprintf("ram map addr: %x\n" , addrspace);
                if (addrspace != 0)
                {
                    extern addrspace_t rsspace;
                    unsigned long attr = ipcbuffer_get_msgs(task_get_ipcbuffer(current()))[3];
                    //dprintf("ram vir_to_phy m0 %x\n",m0);
                    unsigned long tpbase = vir_to_phy(&rsspace.pg, m0);

                    region_t tmp;
                    tmp.vbase = m0;
                    tmp.pbase = tpbase;
                    tmp.size = m1;
                    unsigned long result = map_single_region(addrspace, &tmp, attr);

                    // dprintf("ram vir_to_phy: %x\n",vir_to_phy(&rsspace.pg,m0));
                    task_set_retcode(current(), result);
                }
            }
        }
        break;
    case CAP_RAM_UNMAP:
    {
        // dprintf("CAP_RAM_UNMAP\n");
        //capability_t *addrcap = 0;
        addrspace_t *addrspace = 0;

        if (cptr != 0)
        {
            capability_t *cap = cnode_cptr_lookup(task_get_cnode(current()), cptr, sizeof(unsigned long) * 8);
            tcb_t *task = cap_task_get_obj(cap);
            addrspace = task->addrspace;
        }
        else
            addrspace = task_get_addrspace(current());
        // dprintf("ram unmap addr: %x, vbase: %x\n", addrspace, m0);
        if (addrspace != 0)
        {
            unsigned int result = addrspace_unmap(addrspace, &m0, &m1);
            task_set_retcode(current(), result);
        }
        //addrspace_unmap(addrspace_t *as, unsigned long vbase, unsigned long size)
        break;
    }

    default:
        break;
    }
}
