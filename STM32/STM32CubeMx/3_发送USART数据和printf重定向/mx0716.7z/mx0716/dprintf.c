/****************************************************
* Need a function to print a char:
*        void dputchar(char c);
* Only support %x %X %c %d %s \n currently.
****************************************************/
#include <config.h>
#include <dprintf.h>
#include <utils.h>

#include <stdlib/ks_limits.h>
#include <stdlib/ks_stdarg.h>

// low-level interfaces required by this module
extern void dputchar(char c);

static const char xdigitmap[] = "0123456789abcdef";
static const char Xdigitmap[] = "0123456789ABCDEF";

static char * fmt_d(char *buf, char *bufend, int value)
{
    int div = 1000000000;
    
    if(value < 0)
    {
        *buf = '-', buf++;
        value = -value; // TODO: overflow
    }
    
    while(value < div) div /= 10;
    if(div == 0 && buf < bufend)
        *buf = '0', buf++;
    
    while(div > 0 && buf < bufend)
    {
        *buf = xdigitmap[value/div], ++buf;
        value %= div;
        div /= 10;
    }
    
    return buf;
}

static char* fmt_x(char *buf, char *bufend, unsigned int value, int X)
{
    const char *map = xdigitmap;
    unsigned int len = sizeof(unsigned int)*8 - (clz(value) & (~0x3));
    
    if(X != 'x') map = Xdigitmap;
    
    while(buf < bufend && len > 4)
    {
        len -= 4;
        *buf = map[(value >> len) & 0xf], ++buf;
    }
    
    if(buf < bufend)
        *buf = map[value &0xf], ++buf;
    
    return buf;
}

static char* fmt_s(char *buf, char *bufend, const char* s)
{
    while(buf < bufend && *s != '\0')
    {
        *buf = *s, ++buf;
        ++s;
    }
    
    return buf;
}

int vsnprintf(char *buf, size_t size, const char *fmt, va_list ap)
{
    char * const bufstart = buf;
    char * const bufend = buf + size - 1; //reserved for '\0'
    
    while(buf < bufend && *fmt != '\0')
    {
        if(*fmt == '%')
        {
            ++fmt;
            switch(*fmt)
            {
                case 'c':
                    *buf = (char)va_arg(ap, int);
                    buf++;
                    break;
                
                case 'd':
                    buf = fmt_d(buf, bufend, va_arg(ap, int));
                    break;
                
                case 'x':
                    buf = fmt_x(buf, bufend, va_arg(ap, unsigned int), 'x');
                    break;
                
                case 'X':
                    buf = fmt_x(buf, bufend, va_arg(ap, unsigned int), 'X');
                    break;
                
                case 's':
                    buf = fmt_s(buf, bufend, va_arg(ap, const char*));
                    break;
                
                default:
                    goto label_ret;
            }
        }
        else
        {
            *buf = *fmt, ++buf;
            if(*fmt == '\n')
                *buf = '\r', ++buf;
        }
        
        ++fmt;
    }
    
label_ret:
    *buf = '\0', ++buf;
    return buf - bufstart;
}

int snprintf(char *buf, size_t size, const char *fmt, ...)
{
    va_list ap;
    int count;
    
    va_start(ap, fmt);
    count = vsnprintf(buf, size, fmt, ap);
    va_end(ap);
    
    return count;
}

int sprintf(char *buf,const char *fmt, ...)
{
    va_list ap;
    int count;
    
    va_start(ap, fmt);
    count = vsnprintf(buf, CONFIG_DPRINTF_BUFSIZE, fmt, ap);
    va_end(ap);
    
    return count;
}

static void print_prefix(void)
{
    dputchar('[');
    dputchar('K');
    dputchar(']');
    dputchar(' ');
}

int dprintf(const char *fmt, ...)
{
#ifdef CONFIG_ENABLE_DPRINTF
    char buf[CONFIG_DPRINTF_BUFSIZE];
    
    va_list ap;
    int count;
    char *cur = buf;
    
    va_start(ap, fmt);
    count = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    
    print_prefix();
    while(--count > 0)
    {
        dputchar(*cur);
        ++cur;
    }
    
    return (int)(cur - buf);
#else
    return 0;
#endif
}

int dputs(const char *s)
{
#ifdef CONFIG_ENABLE_DPRINTF
    int count = 0;
    
    print_prefix();
    while(*s != '\0')
        dputchar(*s), ++s, ++count;
    
    dputchar('\n');
    dputchar('\r');
    
    return count;
#else
    return 0;
#endif
}
