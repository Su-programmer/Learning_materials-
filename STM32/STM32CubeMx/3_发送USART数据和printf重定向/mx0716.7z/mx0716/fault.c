#include <uapi/ipcbuffer.h>
#include <uapi/errors.h>

#include <fault.h>
#include <schedule.h>
#include <task.h>

#include <caps/endpoint.h>

static void fault_backup(void *task)
{
    unsigned long retcode = task_get_retcode(task);
    ipcbuffer_t *buf = task_get_ipcbuffer(task);

    buf->msgs.backup.retcode = retcode;
    ks_memcpy(&buf->msgs.backup.cptr, &buf->msgs.cptr, sizeof(fault_backup_t) - sizeof(unsigned long));
}

static void fault_recovery(void *task)
{
    ipcbuffer_t *buf = task_get_ipcbuffer(task);
    task_set_retcode(task, buf->msgs.backup.retcode);
    ks_memcpy(&buf->msgs.cptr, &buf->msgs.backup.cptr, sizeof(fault_backup_t) - sizeof(unsigned long));
}

void fault_callback(void *task, long result, long useless)
{
    task_clear_flags(task, TASK_FBIT_REPORT);

    if (task_get_fault(task) != FAULT_CHILD_EXIT && result == ESUCCESS)
    {
        fault_recovery(task);
        schedule_attach(task);
    }
}

void fault_report(void *_task, int type, unsigned long info0, unsigned long info1)
{
    endpoint_t *ep;
    tcb_t *task = _task;
    unsigned int state = task_get_state(task);

    assert(tcb_is_valid(task));

    task_set_fault(task, type);
    ep = task_get_faulthandler(task);
    if (type != FAULT_CHILD_EXIT)
        fault_backup(task);

    task_set_flags(task, TASK_FBIT_REPORT);
    ipcbuffer_set_msgs(task_get_ipcbuffer(task), 2, task_get_id(task));

    // endpoint will change the state of task and detach the task from scheduler
    endpoint_call(ep, msgtag_make(3, type, 0), info0, info1, task);

    // ignore the change of state made in endpoint_call
    task_set_state(task, state);
}

void hardfault_handler(int type, unsigned long status, unsigned long addr)
{
    tcb_t *cur = current();

    // make sure we don't lose it
    tcb_get(cur);

    if (type == FAULT_UNRECOVERY)
    {
        task_set_state(cur, TASK_INACTIVE);
        task_prepare_exit(cur);
    }
    // if (type == FAULT_DATA)
    // {
    //     dprintf("FAULT_DATA schedule\n");
    //     task_set_state(cur, TASK_INACTIVE);
    //     task_prepare_exit(cur);
    //     extern schedule_data_t sd[];
    //     sd[0].action = ACTION_CHOOSE_NEW;
    // }

    fault_report(cur, type, status, addr);

    tcb_put(cur);
    schedule();
}
