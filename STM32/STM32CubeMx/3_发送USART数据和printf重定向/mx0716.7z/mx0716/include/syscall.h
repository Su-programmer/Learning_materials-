#ifndef SYSCALL_H
#define SYSCALL_H

#include <task.h>

void syscall_handler(unsigned long sn, unsigned long a0,
                unsigned long a1, unsigned long a2);
#endif
