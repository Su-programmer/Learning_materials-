#ifndef TEST_H
#define TEST_H

#include <config.h>

#ifdef CONFIG_DEBUG
void run_self_test(void);
#else
void run_self_test(void){};
#endif

#endif
