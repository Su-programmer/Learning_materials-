/***********
*
************/
#ifndef STDARG_H
#define STDARG_H

#ifndef __cplusplus
/// WARNING: this header is shared between kernel and libmx,
/// be careful with the included headers.

#ifdef __builtin_va_list

typedef __builtin_va_list va_list;
#define va_start(v, s) __builtin_va_start(v, s)
#define va_end(v) __builtin_va_end(v)
#define va_arg(v, t) __builtin_va_arg(v, t)

#else

typedef void* va_list;
#define va_start(v,s) (v = (va_list)(&s + 1))
#define va_end(v) (v = (va_list)0)
#define va_arg(v,t) (v = (va_list)((t*)v + 1), *((t*)v - 1))

#endif
#endif

#endif
