#ifndef STDLIB_ASSERT_H
#define STDLIB_ASSERT_H

#include <config.h>

#ifdef CONFIG_DEBUG
#include <dprintf.h>
#include <halt.h>

#ifdef assert
#undef assert
#endif

#define assert(x) do{ \
                        if(!(x)) \
                        {   \
						dprintf("\033[1;31m"); \
						dprintf(#x " failed at %s.%d\n", __FILE__, __LINE__); \
						dprintf("\033[1;32m"); \
                            halt(); \
                        }\
                  }while(0)

#else
#define assert(x)
#endif // CONFIG_DEBUG
        
#define assert_param(x) assert(x)

#endif
