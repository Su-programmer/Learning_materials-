/*********************************************************
*
*********************************************************/
#ifndef STDDEF_H
#define STDDEF_H

/// WARNING: this header is shared between kernel and libmx,
/// be careful with the included headers.



#ifndef __cplusplus
typedef char bool;
typedef long ptrdiff_t;
typedef unsigned int size_t;
#ifndef bool
// if there is no defination of bool, 
// then true and false must not be defined
#define true (1)
#define false (0)
#endif

#endif

#ifndef NULL
#define NULL (0)
#endif

#define DPRINTF_MUTEK_IPCBUFFER (1)
#define DPRINTF_MUTEK_SYSCALL   (1)

#define DPRINTF_MUTE_THREAD    (1)
#define DPRINTF_MUTE_FAULT     (1)

#if(1)
#define DEBUG_PRINT_MSG(msg) dprintf("[debug] "msg" at %s %d %s\n",__FILE__,__LINE__,__func__)
#define DEBUG_PRINT_ARG(msg,...) dprintf("[debug] "#__VA_ARGS__" = "msg" at %s %d %s\n",__VA_ARGS__,__FILE__,__LINE__,__func__)
#else
#define DEBUG_PRINT_MSG(msg)
#define DEBUG_PRINT_ARG(msg)
#endif


#endif
