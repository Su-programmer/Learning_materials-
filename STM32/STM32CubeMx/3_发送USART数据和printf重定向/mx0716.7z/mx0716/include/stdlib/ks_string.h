#ifndef STRING_H
#define STRING_H

#include <stdlib/assert.h>
#include <stdlib/ks_stddef.h>

static inline void ks_memset(void *p, int value, size_t size)
{
    int *pp = p;
    
    // make sure both of p and size are aligned with 4 bytes
    assert(((unsigned long)p & 0x3) == 0);
    assert((size & 0x3) == 0);

    size >>= 2;
    
    while(size != 0)
    {
        *pp = value;
        pp++, size--;
    }
}

void* ks_memcpy(void *t, const void *s, size_t size);

#endif
