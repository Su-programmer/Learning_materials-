#ifndef NOTIFICAION_H
#define NOTIFICAION_H

#include <stdlib/ks_stdint.h>

#include <tools/list.h>
#include <tools/macros.h>

#include <object.h>

#include <task.h>

typedef struct _notification
{
    object_t obj;
    list_t waiters;
    unsigned long private;
    uint8_t state;
    uint8_t count;
}DEFAULT_ALINMENT notification_t;

enum _ntfn_state{
    NTFN_IDLE = 0, NTFN_ACTIVE, NTFN_WAIT, NTFN_DIED
};

enum _ntfn_type{
    NTFN_TYPE_NORMAL, NTFN_TYPE_IRQ
};

static inline unsigned long notification_get_private_data(notification_t *ntfn)
{
    return ntfn->private;
}

static inline void notification_set_private_data(notification_t* ntfn, unsigned long data)
{
    ntfn->private = data;
}

static inline int notification_get(notification_t *ntfn)
{
    return object_get(&ntfn->obj);
}

static inline int notification_put(notification_t *ntfn)
{
    return object_put(&ntfn->obj, offset_of(notification_t, obj), sizeof(notification_t));
}

static inline int notification_has_waiters(notification_t *ntfn)
{
    return ntfn->state == NTFN_WAIT;
}

void notification_init(notification_t *ntfn);
void notification_wait(notification_t *ntfn, tcb_t* receiver, int block);
void notification_signal(notification_t *ntfn, tcb_t* sender);
void notification_cancel(notification_t *ntfn);

#endif
