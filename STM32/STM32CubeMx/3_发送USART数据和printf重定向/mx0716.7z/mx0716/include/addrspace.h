#ifndef ADDRSPACE_H
#define ADDRSPACE_H

#include <uapi/bootinfo.h>

#include <tools/macros.h>

#include <uapi/addrspace.h>

#include <atomic.h>
#include <object.h>

#include <arch/pagetable.h>

typedef struct _address_space
{
    page_table_t pg;
    object_t obj;
} addrspace_t;

typedef struct _image_info
{
    region_t code;
    region_t rwdata;
} image_info_t;

typedef struct _pagetable_info
{
    unsigned short indexbegin;
    unsigned short indexwidth;
    unsigned int size;
} pagetable_info_t;

extern image_info_t kernelinfo;
extern image_info_t rootserverinfo;
extern const pagetable_info_t pti[];

void addrspace_recycle(addrspace_t *as);

static inline int addrspace_get(addrspace_t *as)
{
    return object_get(&as->obj);
}

static inline void addrspace_put(addrspace_t *as)
{
    if (object_put(&as->obj, 0, 0) == 0)
        addrspace_recycle(as);
}

static inline int addrspace_map(addrspace_t *as, unsigned long *pbase, unsigned long *vbase,
                                unsigned long *size, unsigned attr)
{
    return page_table_map(&as->pg, pbase, vbase, size, attr);
}

static inline int addrspace_map_kernel(addrspace_t *as, unsigned long *ppbase, unsigned long *pvbase,
                                       unsigned long *psize, unsigned attr)
{
    return page_table_map_kernel(&as->pg, ppbase, pvbase, psize, attr);
}

static inline unsigned long addrspace_missing_pt(addrspace_t *as, unsigned long *vbase, unsigned long *size, unsigned int level)
{
    return page_table_missing_pt(&as->pg, vbase, size, level);
}

static inline int addrspace_unmap(addrspace_t *as, unsigned long *vbase, unsigned long *size)
{
    return page_table_unmap(&as->pg, vbase, size);
}

static inline void addrspace_switch_to(addrspace_t *to, addrspace_t *from)
{
    page_table_switch_to(&to->pg, &from->pg);
}

void addrspace_init(addrspace_t *as);
addrspace_t *kernel_addrspace(void);

// Boot Code
void kernel_addrspace_init(void);
void BOOTONLY kernel_addrspace_active(void);
addrspace_t *initial_addrspace_init(unsigned long stack, unsigned long size);
addrspace_t *thread_addrsapce_init(int elf);
#endif
