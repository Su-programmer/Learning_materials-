#ifndef DPRINTF_H
#define DPRINTF_H

#include <stdlib/ks_stddef.h>
#include <stdlib/ks_stdarg.h>

int vsnprintf(char *buf, size_t size, const char *fmt, va_list ap);
int snprintf(char *buf, size_t size, const char *fmt, ...);
int dprintf(const char *fmt, ...);
int dputs(const char *s);

#endif
