#ifndef SPINLOCK_H
#define SPINLOCK_H

#include <config.h>
#include <atomic.h>

#include <dprintf.h>

typedef struct _spinlock_t{
    atomic_t data;
}spinlock_t;

#define SPINLOCK_INIT_LOCKED {.data = {1}}
#define SPINLOCK_INIT_UNLOCKED {.data = {0}}

static inline int spin_is_locked(const spinlock_t* lock)
{
    return atomic_load(&lock->data) == 1;
}

static inline void spin_init_unlocked(spinlock_t *lock)
{
    atomic_store(&lock->data, 0);
}

static inline void spin_init_locked(spinlock_t *lock)
{
    atomic_store(&lock->data, 1);
}

static inline int spin_try_lock(spinlock_t *lock)
{
    return atomic_compare_exchange(&lock->data, 0, 1) != 0;
}

static inline void spin_lock(spinlock_t* lock)
{
    while(!spin_try_lock(lock));
}

static inline void spin_unlock(spinlock_t *lock)
{
#ifdef CONFIG_DEBUG
    if(!atomic_compare_exchange(&lock->data, 1, 0))
        dprintf("WARNING: Unlock a unlocked spin lock!\n");
#else
    atomic_store(&lock->data, 0);
#endif
}

#endif
