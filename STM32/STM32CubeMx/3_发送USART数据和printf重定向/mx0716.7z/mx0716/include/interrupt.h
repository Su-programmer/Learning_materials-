#ifndef INTERRUPT_H
#define INTERRUPT_H

#include <notification.h>

notification_t* irq_register(unsigned int irq);
void irq_unregister(notification_t *ntfn);

// enable the irq
void irq_prepare_wait(notification_t *ntfn);

 // acknowledge interrupt and enable it
void irq_ack_enable(notification_t *ntfn);

void irq_handler_entry(unsigned int irq);
void irq_handler_init(void);

// for kernel only when boot, register interrupt handlers
typedef void (*handler_t)(void);
// setup/clean the interrupt handler and enable/disable the interrupt
void BOOTONLY irq_setup_handler(unsigned int irq, handler_t handler);
void BOOTONLY irq_clean_handler(unsigned int irq);

#endif
