/*********************************************************
* Read/Write Fuctions of System Control Registers for
* ARMv7-a.
*********************************************************/
#ifndef ARMV7_A_SCR_H
#define ARMV7_A_SCR_H

#include <tools/macros.h>

#include <dprintf.h>

#include <arch/utils.h>

// format: Name CRn opc1 CRm opc2 Width Type Description Limits
// awk '{printf("SCR_%s_FUNCTIONS(%s, p15, %s, %s, %s, %s) //", $7, $1, $3, $2, $4, $5); for(i=8; i < 100; i++) if($i != "") printf("%s ", $i); else break; print ""}'
// SCR_Type_FUNCTIONS(Name, p15, opc1, CRn, CRm, opc2) //Description Limits

// Main ID Register
SCR_RO_FUNCTIONS(MIDR, p15, 0, c0, c0, 0)
// Multiprocessor Affinity Register
SCR_RO_FUNCTIONS(MPIDR, p15, 0, c0, c0, 5)

// Monitor vector base address register
SCR_RW_FUNCTIONS(MVBAR, p15, 0, c12, c0, 1)
// Vector base address register(Security Extension)
SCR_RW_FUNCTIONS(VBAR, p15, 0, c12, c0, 0)
// Interrupt status register: A, I, F
SCR_RO_FUNCTIONS(ISR, p15, 0, c12, c1, 0)

// System control register, is bancked, with some bits common to the Secure and Non-secure copies
SCR_RW_FUNCTIONS(SCTLR, p15, 0, c1, c0, 0)
// Auxillary control register
SCR_RW_FUNCTIONS(ACTLR, p15, 0, c1, c0, 1)

enum __SCR_SCTLR_BITS
{
    // sed 's/^\([a-zA-Z0-9_]\+\),[ ]*bit\[\([0-9]\+\)\] \(.\+\)$/SCR_XXX_BIT_\1 = \2, \/\/ \3/'
    SCR_SCTLR_BIT_TE = 30,      // Thumb Exception Enable
    SCR_SCTLR_BIT_AFE = 29,     // Access flag enable.
    SCR_SCTLR_BIT_TRE = 28,     // TEX remap enable.
    SCR_SCTLR_BIT_NMFI_RO = 27, // Non-maskable FIQ (NMFI) support.
    SCR_SCTLR_BIT_EE = 25,      // Exception Endianness.
    SCR_SCTLR_BIT_VE = 24,      // Interrupt Vectors Enable. 0: using the entry specified in V bit.
    SCR_SCTLR_BIT_U = 22,       // In ARMv7 this bit is RAO/SBOP.
    SCR_SCTLR_BIT_FI = 21,      // Fast interrupts configuration enable.
    SCR_SCTLR_BIT_UWXN = 20,    // Unprivileged write permission implies PL1 XN. [Virtualization Extensions]
    SCR_SCTLR_BIT_WXN = 19,     // Write permission implies XN. [Virtualization Extensions]
    SCR_SCTLR_BIT_HA = 17,      // Hardware Access flag enable.
    SCR_SCTLR_BIT_RR = 14,      // Round Robin select. [Cache]
    SCR_SCTLR_BIT_V = 13,       // Vectors bit. This bit selects the base address of the exception vectors. 1 = 0xffff0000, 0 = 0x0
    SCR_SCTLR_BIT_I = 12,       // Instruction cache enable: This is a global enable bit for instruction caches.
    SCR_SCTLR_BIT_Z = 11,       // Branch prediction enable.
    SCR_SCTLR_BIT_SW = 10,      // SWP and SWPB enable.
    SCR_SCTLR_BIT_B = 7,        // In ARMv7 this bit is RAZ/SBZP.
    SCR_SCTLR_BIT_CP15BEN = 5,  // CP15 barrier enable.
    SCR_SCTLR_BIT_C = 2,        // Cache enable. This is a global enable bit for data and unified caches.
    SCR_SCTLR_BIT_A = 1,        // Alignment check enable.
    SCR_SCTLR_BIT_M = 0,        // MMU enable.
};

// Secure configuration register
SCR_RW_FUNCTIONS(SCR, p15, 0, c1, c1, 0)
// Secure debug enable register
SCR_RW_FUNCTIONS(SDER, p15, 0, c1, c1, 1)
// Non-sercure access control register
SCR_RW_FUNCTIONS(NSACR, p15, 0, c1, c1, 2)

enum __SCR_SCR_BITS
{
    SCR_SCR_BIT_SIF = 9, // Secure instruction fetch. [Virtualization Extensions]
    SCR_SCR_BIT_HCE = 8, // Hyp Call enable. [Virtualization Extensions]
    SCR_SCR_BIT_SCD = 7, // Secure Monitor Call disable. [Virtualization Extensions]
    SCR_SCR_BIT_nET = 6, // Not Early Termination.
    SCR_SCR_BIT_AW = 5,  // CPSR.A bit writable in any security state.
    SCR_SCR_BIT_FW = 4,  // CPSR.F bit writable in any security state.
    SCR_SCR_BIT_EA = 3,  // External Abort handler. External aborts taken to Monitor mode.
    SCR_SCR_BIT_FIQ = 2, // FIQ handler. This bit controls whether FIQ exceptions are taken to Monitor mode.
    SCR_SCR_BIT_IRQ = 1, // IRQ handler. This bit controls whether IRQ exceptions are taken to Monitor mode.
    SCR_SCR_BIT_NS = 0,  // Non-secure bit.
};

//Private Timer
//Clock Frequency Register
SCR_RW_FUNCTIONS(CNTFRQ, p15, 0, c14, c0, 0)
//Timer PL1 Control Register
SCR_RW_FUNCTIONS(CNTKCTL, p15, 0, c14, c1, 0)
//PL1 Physical Timer Control Register
SCR_RW_FUNCTIONS(CNTP_CTL, p15, 0, c14, c2, 1)
//PL1 Physical Timer CompareValue Register
SCR_RW_FUNCTIONS_64(CNTP_CVAL, p15, 2, c14)
//PL1 Physical TimerValue Register
SCR_RW_FUNCTIONS(CNTP_TVAL, p15, 0, c14, c2, 0)
//Physical Count Register
SCR_RO_FUNCTIONS_64(CNTPCT, p15, 0, c14)

enum __SCR_CNTKCTL_BITS
{
    SCR_CNTKCTL_BIT_PL0PTEN = 9,
    SCR_CNTKCTL_BIT_PL0VTEN = 8,
    SCR_CNTKCTL_BIT_EVNTI = 4,
    SCR_CNTKCTL_BIT_EVNTDIR = 3,
    SCR_CNTKCTL_BIT_EVNTEN = 2,
    SCR_CNTKCTL_BIT_PL0VCTEN = 1,
    SCR_CNTKCTL_BIT_PL0PCTEN = 0,
};

enum __SCR_CNTPCTL_BITS
{
    SCR_CNTPCTL_BIT_ISTATUS = 2,
    SCR_CNTPCTL_BIT_IMASK = 1,
    SCR_CNTPCTL_BIT_ENABLE = 0,
};

// Coprocess access control register
SCR_RW_FUNCTIONS(CPACR, p15, 0, c1, c0, 2)

// Translation Table
SCR_RW_FUNCTIONS(TTBR0, p15, 0, c2, c0, 0) // 64-bit register exists
SCR_RW_FUNCTIONS(TTBR1, p15, 0, c2, c0, 1) // 64-bit register exists
SCR_RW_FUNCTIONS(TTBCR, p15, 0, c2, c0, 2)
SCR_RW_FUNCTIONS(DACR, p15, 0, c3, c0, 0) // Domain Access Control

enum __SCR_TTBCR_BITS
{
    // Extended Address Enable.[LPAE]
    // 0 = Use the 32-bit translation system, with the Short-descriptor translation table format.
    // 1 = 40-bit & Long.
    SCR_TTBCR_BIT_EAE = 31,

    // Translation table walk disable for translations using TTBRx. [Security Extensions]
    SCR_TTBCR_BIT_PD1 = 5,
    SCR_TTBCR_BIT_PD0 = 4, // Same as PD1.

    // Indicate the width of the base address held in TTBR0. [2:0]
    SCR_TTBCR_BIT_N = 0,
    SCR_TTBCR_BIT_N_WIDTH = 3,
};

enum __SCR_TTBRx_BITS
{
    SCR_TTBRx_BIT_BASEADDR = 14,
    SCR_TTBRx_BIT_BASEADDR_WIDTH = 18,

    SCR_TTBRx_BIT_NOS = 5, // Not Outer Shareable bit.
    SCR_TTBRx_BIT_RGN = 3, // Region bits.[4:3]
    SCR_TTBRx_BIT_IMP = 2,
    SCR_TTBRx_BIT_S = 1,     // Shareable bit.
    SCR_TTBRx_BIT_C = 0,     // Cacheable bit. [ARMv7-A without Multiprocessing Extensions]
    SCR_TTBRx_BIT_IRGN0 = 6, // [ARMv7-A with Multiprocessing Extensions]
    SCR_TTBRx_BIT_IRGN1 = 0, // [ARMv7-A with Multiprocessing Extensions]
};

enum __SCR_DACR_BITS
{
    SCR_DACR_BIT_Dn_BEGIN = 0,
    SCR_DACR_BIT_Dn_WIDTH = 2,
    SCR_DACR_BIT_Dn_COUNT = 16,

    SCR_DACR_NOACCESS = 0,  // No access.
    SCR_DACR_CLIENT = 0x1,  // Check the access permission
    SCR_DACR_MANAGER = 0x3, // Don't check the access permission in the pagetable
};

// Data/Instruction fault status register
SCR_RW_FUNCTIONS(DFSR, p15, 0, c5, c0, 0)
SCR_RW_FUNCTIONS(IFSR, p15, 0, c5, c0, 1)
// Auxillary data and instruction fault status registers
SCR_RO_FUNCTIONS(ADFSR, p15, 0, c5, c1, 0)
SCR_RO_FUNCTIONS(AIFSR, p15, 0, c5, c1, 1)
// Data/Instruction fault address register
SCR_RW_FUNCTIONS(DFAR, p15, 0, c6, c0, 0)
SCR_RW_FUNCTIONS(IFAR, p15, 0, c6, c0, 2)

SCR_RW_FUNCTIONS(PAR, p15, 0, c7, c4, 0)
SCR_WO_FUNCTIONS(ATS1CPR, p15, 0, c7, c8, 0) // Stage 1 Current state PL1 read
SCR_WO_FUNCTIONS(ATS1CPW, p15, 0, c7, c8, 1) // Stage 1 Current state PL1 write
SCR_WO_FUNCTIONS(ATS1CUR, p15, 0, c7, c8, 2) // Stage 1 Current state unprivileged read
SCR_WO_FUNCTIONS(ATS1CUW, p15, 0, c7, c8, 3) // Stage 1 Current state unprivileged write

enum __SCR_PAR_BITS
{
    SCR_PAR_BIT_PA = 12, // Physical Address.
    SCR_PAR_BIT_PA_WIDTH = 20,

    SCR_PAR_BIT_NOS = 10, // Not Outer Shareable attribute.
    SCR_PAR_BIT_NS = 9,   // Non-secure.
    SCR_PAR_BIT_SH = 7,   // Shareable attribute.

    SCR_PAR_BIT_Inner = 4, // Inner memory attributes
    SCR_PAR_BIT_Inner_WIDTH = 3,

    SCR_PAR_BIT_Outer = 2, // Outer memory attributes
    SCR_PAR_BIT_Outer_WIDTH = 2,

    SCR_PAR_BIT_SS = 1, // Supersection.
    SCR_PAR_BIT_F = 0,  // Indicates that the conversion completed successfully.

    // when F is 1, the FS is the Fault status
    SCR_PAR_BIT_FS = 1, // Fault status bits
    SCR_PAR_BIT_FS_WIDTH = 6,
};

static inline void scr_report_ins_fault(void)
{
    dprintf("IFSR: 0x%x, AIFSR: 0x%x, IFAR: 0x%x\n",
            scr_read_IFSR(), scr_read_AIFSR(), scr_read_IFAR());
}

static inline void scr_report_data_fault(void)
{
    dprintf("DFSR: 0x%x, ADFSR: 0x%x, DFAR: 0x%x\n",
            scr_read_DFSR(), scr_read_ADFSR(), scr_read_DFAR());
}

unsigned long scr_translate_va(unsigned long va, int iskernel, int iswrite);
void scr_report_va_info(unsigned long va, int iskernel, int iswrite);

SCR_RW_FUNCTIONS(PRRR, p15, 0, c10, c2, 0) // Primary Region Remap Register
SCR_RW_FUNCTIONS(NMRR, p15, 0, c10, c2, 1) // Normal Memory Remap Register

enum __SCR_PRRR_BITS
{
    // Primary TEX mapping for memory attributes:
    // 00 Strongly-Ordered, 01 Device, 10, Normal Memeory
    SCR_PRRR_BIT_TR_BEGIN = 0,
    SCR_PRRR_BIT_TR_WIDTH = 2,
    SCR_PRRR_BIT_TR_COUNT = 8,

    SCR_PRRR_TR_SO = 0,
    SCR_PRRR_TR_D = 1,
    SCR_PRRR_TR_NM = 2,

    // Device/NormalMemory Shareable
    SCR_PRRR_BIT_DS0 = 16, // for the device memory and S bit is 0
    SCR_PRRR_BIT_DS1 = 17, // for the device memory and S bit is 1
    SCR_PRRR_BIT_NS0 = 18, // for the normal memory and S bit is 0
    SCR_PRRR_BIT_NS1 = 19, // for the normal memory and S bit is 1

    // Not Ourter shareable if the region is shared
    SCR_PRRR_BIT_NOR_BEGIN = 24,
    SCR_PRRR_BIT_NOR_WIDTH = 1,
    SCR_PRRR_BIT_NOR_COUNT = 8,
};

enum __SCR_NMRR_BITS
{
    // Outer Cacheable property if the region is mapped as Normal memory.
    SCR_NMRR_BIT_OR_BEGIN = 16,
    SCR_NMRR_BIT_OR_WIDTH = 2,
    SCR_NMRR_BIT_OR_COUNT = 8,

    // Inner Cacheable property if the region is mapped as Normal memory.
    SCR_NMRR_BIT_IR_BEGIN = 16,
    SCR_NMRR_BIT_IR_WIDTH = 2,
    SCR_NMRR_BIT_IR_COUNT = 8,

    SCR_NMRR_NC = 0,      // no cacheable
    SCR_NMRR_WBWA = 0x1,  // write-back, write-allocate
    SCR_NMRR_WTNWA = 0x2, // write-back, no write-allocate
    SCR_NMRR_WBNWA = 0x3, // write-back, no write-allocate
};

// Floating-point
SCR_RW_FUNCTIONS_V(FPEXC)
SCR_RW_FUNCTIONS_V(FPSCR)
SCR_RW_FUNCTIONS_V(FPSID)

// Thread ID register
SCR_RW_FUNCTIONS(TPIDRPRW, p15, 0, c13, c0, 4)
SCR_RW_FUNCTIONS(TPIDRURO, p15, 0, c13, c0, 3)
SCR_RW_FUNCTIONS(TPIDRURW, p15, 0, c13, c0, 2)
SCR_RW_FUNCTIONS(CONTEXTIDR, p15, 0, c13, c0, 1)

enum __SCR_CONTEXTIDR_BITS
{
    // for short-descriptor translation table format
    SCR_CONTEXTIDR_BIT_ASID = 0,
    SCR_CONTEXTIDR_BIT_ASID_WIDTH = 8,

    SCR_CONTEXTIDR_BIT_PROCID = 8,
    SCR_CONTEXTIDR_BIT_PROCID_WIDTH = 24,
};

// Cache IDentifier Registers
SCR_RO_FUNCTIONS(CCSIDR, p15, 1, c0, c0, 0)
SCR_RO_FUNCTIONS(CLIDR, p15, 1, c0, c0, 1)
SCR_RW_FUNCTIONS(CSSELR, p15, 2, c0, c0, 0)

enum __SCR_CCSIDR_BITS
{
    SCR_CCSIDR_BIT_WT = 31,      // Indicates whether the cache level supports write-through
    SCR_CCSIDR_BIT_WB = 30,      // Indicates whether the cache level supports write-back
    SCR_CCSIDR_BIT_RA = 29,      // Indicates whether the cache level supports read-allocation
    SCR_CCSIDR_BIT_WA = 28,      // Indicates whether the cache level supports write-allocation
    SCR_CCSIDR_BIT_NumSets = 13, // the real sets = value + 1
    SCR_CCSIDR_BIT_NumSets_WIDTH = 15,
    SCR_CCSIDR_BIT_Associativity = 3, // the real ways = value + 1
    SCR_CCSIDR_BIT_Associativity_WIDTH = 10,
    SCR_CCSIDR_BIT_LineSize = 0, // the real cache line size = 2^(value + 2)
    SCR_CCSIDR_BIT_LineSize_WIDTH = 3,
};

enum __SCR_CLIDR_BITS
{
    SCR_CLIDR_BIT_CTYPE_BEGIN = 0,
    SCR_CLIDR_BIT_CTYPE_COUNT = 7,
    SCR_CLIDR_BIT_CTYPE_WIDTH = 3,
    SCR_CLIDR_BIT_LOUIS = 21,
    SCR_CLIDR_BIT_LOUIS_WIDTH = 3,
    SCR_CLIDR_BIT_LOC = 24,
    SCR_CLIDR_BIT_LOC_WIDTH = 3,
    SCR_CLIDR_BIT_LOUU = 27,
    SCR_CLIDR_BIT_LOUU_WIDTH = 3,

    // the possible value of ervery CTYPE bitfiled
    SCR_CLIDR_CTYPE_NoCache = 0,
    SCR_CLIDR_CTYPE_ICache = 1,   // Insturction Cache only
    SCR_CLIDR_CTYPE_DCache = 2,   // Data Cache only
    SCR_CLIDR_CTYPE_SIDCache = 3, // Seperate Instruction and Data Cache
    SCR_CLIDR_CTYPE_UCache = 4,   // Unified Cache
};

enum __SCR_CSSELR_BITS
{
    SCR_CSSELR_BIT_LEVEL = 1, // real level is (value + 1)
    SCR_CSSELR_BIT_LEVEL_WIDTH = 3,
    SCR_CSSELR_BIT_InD = 0, // Instruction not Data bit
};

// return 0 if succeed
int scr_get_cache_info(unsigned int level, unsigned int InD, int *sets, int *ways, int *linesize);
// return the real type of the cache
unsigned int scr_get_cache_type(unsigned int level);

void scr_clean_data_cache(void);
void scr_clean_invalidate_data_cache(void);
void scr_invalidate_data_cache(void);
void scr_enable_cpu_cache(void);

// Cache and branch predictors
SCR_WO_FUNCTIONS(BPIALL, p15, 0, c7, c5, 6)    //Branch predictor invalidate all -
SCR_WO_FUNCTIONS(BPIALLIS, p15, 0, c7, c1, 6)  //Branch predictor invalidate all IS
SCR_WO_FUNCTIONS(BPIMVA, p15, 0, c7, c5, 7)    //Branch predictor invalidate by MVA -
SCR_WO_FUNCTIONS(DCCIMVAC, p15, 0, c7, c14, 1) //Data cache clean and invalidate by MVA PoC
SCR_WO_FUNCTIONS(DCCISW, p15, 0, c7, c14, 2)   //Data cache clean and invalidate by set/way -
SCR_WO_FUNCTIONS(DCCMVAC, p15, 0, c7, c10, 1)  //Data cache clean by MVA PoC
SCR_WO_FUNCTIONS(DCCMVAU, p15, 0, c7, c11, 1)  //Data cache clean by MVA PoU
SCR_WO_FUNCTIONS(DCCSW, p15, 0, c7, c10, 2)    //Data cache clean by set/way -
SCR_WO_FUNCTIONS(DCIMVAC, p15, 0, c7, c6, 1)   //Data cache invalidate by MVA PoC
SCR_WO_FUNCTIONS(DCISW, p15, 0, c7, c6, 2)     //Data cache invalidate by set/way -
SCR_WO_FUNCTIONS(ICIALLU, p15, 0, c7, c5, 0)   //Instruction cache invalidate all PoU
SCR_WO_FUNCTIONS(ICIALLUIS, p15, 0, c7, c1, 0) //Instruction cache invalidate all PoU, IS
SCR_WO_FUNCTIONS(ICIMVAU, p15, 0, c7, c5, 1)   //Instruction cache invalidate by MVA PoU

// TLB maintaince registers
SCR_WO_FUNCTIONS(DTLBIALL, p15, 0, c8, c6, 0)   //Invalidate entire data TLB -
SCR_WO_FUNCTIONS(DTLBIASID, p15, 0, c8, c6, 2)  //Invalidate data TLB by ASID -
SCR_WO_FUNCTIONS(DTLBIMVA, p15, 0, c8, c6, 1)   //Invalidate data TLB entry by MVA -
SCR_WO_FUNCTIONS(ITLBIALL, p15, 0, c8, c5, 0)   //Invalidate entire instruction TLB -
SCR_WO_FUNCTIONS(ITLBIASID, p15, 0, c8, c5, 2)  //Invalidate instruction TLB by ASID -
SCR_WO_FUNCTIONS(ITLBIMVA, p15, 0, c8, c5, 1)   //Invalidate instruction TLB by MVA -
SCR_WO_FUNCTIONS(TLBIALL, p15, 0, c8, c7, 0)    //Invalidate entire unified TLB -
SCR_WO_FUNCTIONS(TLBIALLIS, p15, 0, c8, c3, 0)  //Invalidate entire unified TLB IS
SCR_WO_FUNCTIONS(TLBIASID, p15, 0, c8, c7, 2)   //Invalidate unified TLB by ASID -
SCR_WO_FUNCTIONS(TLBIASIDIS, p15, 0, c8, c3, 2) //Invalidate unified TLB by ASID IS
SCR_WO_FUNCTIONS(TLBIMVAA, p15, 0, c8, c7, 3)   //Invalidate unified TLB by MVA, all ASID -
SCR_WO_FUNCTIONS(TLBIMVAAIS, p15, 0, c8, c3, 3) //Invalidate unified TLB by MVA, all ASID IS
SCR_WO_FUNCTIONS(TLBIMVA, p15, 0, c8, c7, 1)    //Invalidate unified TLB by MVA -
SCR_WO_FUNCTIONS(TLBIMVAIS, p15, 0, c8, c3, 1)  //Invalidate unified TLB by MVA IS

enum __SCR_TLB_BITS
{
    SCR_TLB_BIT_MVA = 12,
    SCR_TLB_BIT_MVA_WIDTH = 20,

    SCR_TLB_BIT_ASID = 0,
    SCR_TLB_BIT_WIDTH = 8,
};

static inline void scr_invalidate_icache(void)
{
    scr_write_ICIALLU(0);
    isb();
}

static inline void scr_invalidate_tlb_all(void)
{
    dsb();
    scr_write_TLBIALL(0);
    scr_write_DTLBIALL(0);
    scr_write_ITLBIALL(0);
    scr_write_TLBIALLIS(0);
    dsb();
    isb();
}

static inline void scr_invalidate_tlb_asid(unsigned char asid)
{
    unsigned long value = asid;
    value <<= SCR_TLB_BIT_ASID;
    scr_write_TLBIASID(value);
    dsb();
}

static inline void scr_invalidate_tlb_mva(unsigned long mva, unsigned long size)
{
    unsigned long va;
    unsigned long count;

    va = mva & ~lowbitsmask(SCR_TLB_BIT_MVA);
    count = (mva - va + size + bitmask(SCR_TLB_BIT_MVA) - 1) >> SCR_TLB_BIT_MVA;

    while (count-- > 0)
    {
        scr_write_TLBIMVAA(va);
        va += bitmask(SCR_TLB_BIT_MVA);
    }

    isb();
    dsb();
}

// Performan monitors
SCR_RW_FUNCTIONS(PMCR, p15, 0, c9, c12, 0)       //Performance Monitors Control Register
SCR_RW_FUNCTIONS(PMCNTENSET, p15, 0, c9, c12, 1) //Performance Monitors Count Enable Set register
SCR_RW_FUNCTIONS(PMCNTENCLR, p15, 0, c9, c12, 2) //Performance Monitors Count Enable Clear register
SCR_RW_FUNCTIONS(PMOVSR, p15, 0, c9, c12, 3)     //Performance Monitors Overflow Flag Status Register
SCR_WO_FUNCTIONS(PMSWINC, p15, 0, c9, c12, 4)    //Performance Monitors Software Increment register
SCR_RW_FUNCTIONS(PMSELR, p15, 0, c9, c12, 5)     //Performance Monitors Event Counter Selection Register
SCR_RO_FUNCTIONS(PMCEID0, p15, 0, c9, c12, 6)    //Performance Monitors Common Event Identification register 0
SCR_RO_FUNCTIONS(PMCEID1, p15, 0, c9, c12, 7)    //Performance Monitors Common Event Identification register 1
SCR_RW_FUNCTIONS(PMCCNTR, p15, 0, c9, c13, 0)    //Performance Monitors Cycle Count Register
SCR_RW_FUNCTIONS(PMXEVTYPER, p15, 0, c9, c13, 1) //Performance Monitors Event Type Select Register
SCR_RW_FUNCTIONS(PMXEVCNTR, p15, 0, c9, c13, 2)  //Performance Monitors Event Count Register
SCR_RW_FUNCTIONS(PMUSERENR, p15, 0, c9, c14, 0)  //Performance Monitors User Enable Register
SCR_RW_FUNCTIONS(PMINTENSET, p15, 0, c9, c14, 1) //Performance Monitors Interrupt Enable Set register
SCR_RW_FUNCTIONS(PMINTENCLR, p15, 0, c9, c14, 2) //Performance Monitors Interrupt Enable Clear register
SCR_RW_FUNCTIONS(PMOVSSET, p15, 0, c9, c14, 3)   //Performance Monitors Overflow Flag Status Set register

enum __SCR_PMCNTENSET_BITS
{
    SCR_PMCNTENSET_BIT_C = 31, // Enable cycle counter,
    SCR_PMCNTENSET_BIT_Px = 0,
};

enum __SCR_PMCR_BITS
{
    SCR_PMCR_BIT_DP = 5, // Disable PMCCNTR when event counting is prohibited
    SCR_PMCR_BIT_X = 4,  // Export enable.
    SCR_PMCR_BIT_D = 3,  // Cycle counter clock divider. 0 = cpu cycle, 1 = cpu cycle/64
    SCR_PMCR_BIT_C = 2,  // Cycle counter reset.
    SCR_PMCR_BIT_P = 1,  // Event counter reset.
    SCR_PMCR_BIT_E = 0,  // Enable.
};

enum __SCR_PMUSERENR_BITS
{
    SCR_PMUSERENR_BIT_EN = 0,
};

static inline void scr_enable_pmu_counter(void)
{
    uint32_t value;

    // reset PMU counter and enable PMU
    value = scr_read_PMCR();
    value |= bitmask(SCR_PMCR_BIT_C) | bitmask(SCR_PMCR_BIT_E);
    scr_write_PMCR(value);

    // enable PMU cycle counter
    scr_write_PMCNTENSET(bitmask(SCR_PMCNTENSET_BIT_C));

    // enable user access to PMU counter
    scr_write_PMUSERENR(bitmask(SCR_PMUSERENR_BIT_EN));
}

static inline unsigned long scr_read_pmuc(void)
{
    return scr_read_PMCCNTR();
}

static inline unsigned int scr_get_cpuid(void)
{
    uint32_t id = scr_read_MPIDR();
    return id & 0xf;
}

void scr_dump_info(void);

#endif
