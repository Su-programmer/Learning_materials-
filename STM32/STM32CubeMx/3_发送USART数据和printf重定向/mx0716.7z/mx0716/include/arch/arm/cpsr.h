#ifndef ARM_CPSR_H
#define ARM_CPSR_H

#include <stdlib/ks_stdint.h>
#include <tools/macros.h>

#define MODE_User 0x10 // PL0 Always Both
#define MODE_FIQ 0x11 // PL1 Always Both
#define MODE_IRQ 0x12 // PL1 Always Both
#define MODE_Supervisor 0x13 // PL1 Always Both
#define MODE_Monitor 0x16 // PL1 With Security Extensions Secure only
#define MODE_Abort 0x17 // PL1 Always Both
#define MODE_Hyp 0x1A // PL2 With Virtualization Extensions Non-secure only
#define MODE_Undefined 0x1B // PL1 Always Both
#define MODE_System 0x1F // PL1 Always
#define MODE_MASK 0x1F

enum __CPSR_BITS{
    CPSR_BIT_N = 31, // Negative condition flag
    CPSR_BIT_Z = 30, // Zero condition flag
    CPSR_BIT_C = 29, // Carry condition flag
    CPSR_BIT_V = 28, // Overflow condition flag.
    CPSR_BIT_Q = 27, // Cumulative saturation bit.
    CPSR_BIT_J = 24, // Jazelle bit.

    // If-Then execution state bits for the Thumb IT (If-Then) instruction.
    CPSR_BIT_IT_H = 10,
    CPSR_BIT_IT_H_WIDTH = 6,
    CPSR_BIT_IT_L = 25,
    CPSR_BIT_IT_L_WIDTH = 2,

    CPSR_BIT_GE = 16, // Greater than or Equal flags.
    CPSR_BIT_GE_WIDTH = 4,

    CPSR_BIT_E = 9, // Endianness execution state bit. 1: big endian
    CPSR_BIT_A = 8, // Asynchronous abort mask bit.
    CPSR_BIT_I = 7, // IRQ mask bit.
    CPSR_BIT_F = 6, // FIQ mask bit.

    CPSR_BIT_T = 5, // Thumb execution state bit.

    CPSR_BIT_MODE = 0, // Mode.
    CPSR_BIT_MODE_WIDTH = 5,
};

static inline unsigned long cpsr_read(void)
{
    unsigned long value;

    __asm__ __volatile__("mrs %0, cpsr\n":"=r"(value):);

    return value;
}

static inline unsigned int cpsr_current_mode(void)
{
    unsigned long value = cpsr_read();
    return bitfield_get(value, CPSR_BIT_MODE, CPSR_BIT_MODE_WIDTH);
}

// return 0 if succeed.
int cpsr_change_mode(unsigned int mode);

const char* cpsr_mode_name(unsigned int mode);
void cpsr_dump_info(void);

void cpsr_enable_int(void);

#endif
