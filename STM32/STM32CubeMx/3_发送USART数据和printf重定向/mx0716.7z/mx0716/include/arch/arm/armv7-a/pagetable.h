/*********************************************************
* Simplified MMU driver for ARMv7-A:
*   * Short-descriptor Translation Table Format only
*   * TTBR0 only
*   * TEX Remap Disabled[TEX[2:0], C, B]: 8 regions
*   * AP[2:0] Access Permissions Model
*   * Use Sections and Small Pages Only
*********************************************************/
#ifndef ARMV7A_PAGETABLE_H
#define ARMV7A_PAGETABLE_H

#include <stdlib/ks_string.h>

#define L1PT_ENTRIES (4 * 1024)
#define L2PT_ENTRIES (256)

typedef struct _page_table
{
    unsigned long entry[L1PT_ENTRIES]; // todo:
} ALIGNED(1 << 14) page_table_t;

int page_unmap(page_table_t *pd, unsigned long *vbase, unsigned long *size);

///
/// Public Interfaces
///

static inline void page_table_init(page_table_t *pd)
{
    ks_memset(pd, 0, sizeof(page_table_t));
}

// Only Copy the entries in L1 Page Table
static inline void page_table_copy(page_table_t *tar, page_table_t *src)
{
    ks_memcpy(tar, src, sizeof(page_table_t));
}

static inline int page_table_unmap(page_table_t *pd, unsigned long *vbase, unsigned long *size)
{
    return page_unmap(pd, vbase, size);
}

void page_table_recycle(page_table_t *u, page_table_t *k);
int page_table_map(page_table_t *pd, unsigned long *pbase, unsigned long *vbase, unsigned long *size, unsigned int attr);
int page_table_map_kernel(page_table_t *pd, unsigned long *ppbase, unsigned long *pvbase, unsigned long *psize, unsigned int attr);
int page_table_unmap(page_table_t *pd, unsigned long *vbase, unsigned long *size);
unsigned long page_table_missing_pt(page_table_t *pd, unsigned long *vbase, unsigned long *size, unsigned int level);
void page_table_switch_to(page_table_t *pd, page_table_t *useless);

// Boot Code
void page_table_active(page_table_t *pd);
unsigned long vir_to_phy(page_table_t *pd, unsigned long vbase);

#endif
