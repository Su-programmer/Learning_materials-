#ifndef ARM_UTILS_H
#define ARM_UTILS_H

#include <config.h>

#include <stdlib/ks_stdint.h>
#include <stdlib/assert.h>

#include <tools/macros.h>

#define MRC_INLINE_FUNCTION(FUNC, CP, OP1, CRn, CRm, OP2)                \
    static inline uint32_t FUNC(void)                                    \
    {                                                                    \
        uint32_t value;                                                  \
        __asm__ __volatile__(                                            \
            "mrc " #CP ", " #OP1 ", %0, " #CRn "," #CRm ", " #OP2 "\n\t" \
            : "=r"(value)                                                \
            :);                                                          \
        return value;                                                    \
    }

#define MCR_INLINE_FUNCTION(FUNC, CP, OP1, CRn, CRm, OP2)                \
    static inline void FUNC(uint32_t value)                              \
    {                                                                    \
        __asm__ __volatile__(                                            \
            "mcr " #CP ", " #OP1 ", %0, " #CRn "," #CRm ", " #OP2 "\n\t" \
            :                                                            \
            : "r"(value));                                               \
    }

#define MRRC_INLINE_FUNCTION(FUNC, CP, OP1, CRm)           \
    static inline uint64_t FUNC(void)                      \
    {                                                      \
        uint32_t low;                                      \
        uint32_t high;                                     \
        uint64_t val;                                      \
        __asm__ __volatile__(                              \
            "mrrc " #CP ", " #OP1 ", %0, %1 ," #CRm "\n\t" \
            : "=r"(low), "=r"(high)                        \
            :);                                            \
        val = (((uint64_t)high) << 32) | low;              \
        return val;                                        \
    }

#define MCRR_INLINE_FUNCTION(FUNC, CP, OP1, CRm)           \
    static inline void FUNC(uint64_t value)                \
    {                                                      \
        uint32_t low = (uint32_t)value;                    \
        uint32_t high = (uint32_t)(value >> 32);           \
        __asm__ __volatile__(                              \
            "mcrr " #CP ", " #OP1 ", %0, %1 ," #CRm "\n\t" \
            :                                              \
            : "r"(low), "r"(high));                        \
    }

#define VMRS_INLINE_FUNCTION(FUNC, REG)            \
    static inline uint32_t FUNC(void)              \
    {                                              \
        uint32_t value;                            \
        __asm__ __volatile__("vmrs %0, " #REG "\n" \
                             : "=r"(value));       \
        return value;                              \
    }

#define VMSR_INLINE_FUNCTION(FUNC, REG)             \
    static inline void FUNC(uint32_t value)         \
    {                                               \
        __asm__ __volatile__("vmsr " #REG ", %0 \n" \
                             :                      \
                             : "r"(value));         \
    }

#define SCR_RW_FUNCTIONS(REG, CP, OP1, CRn, CRm, OP2)           \
    MRC_INLINE_FUNCTION(scr_read_##REG, CP, OP1, CRn, CRm, OP2) \
    MCR_INLINE_FUNCTION(scr_write_##REG, CP, OP1, CRn, CRm, OP2)

#define SCR_RO_FUNCTIONS(REG, CP, OP1, CRn, CRm, OP2) \
    MRC_INLINE_FUNCTION(scr_read_##REG, CP, OP1, CRn, CRm, OP2)

#define SCR_WO_FUNCTIONS(REG, CP, OP1, CRn, CRm, OP2) \
    MCR_INLINE_FUNCTION(scr_write_##REG, CP, OP1, CRn, CRm, OP2)

#define SCR_RW_FUNCTIONS_64(REG, CP, OP1, CRm)         \
    MRRC_INLINE_FUNCTION(scr_read_##REG, CP, OP1, CRm) \
    MCRR_INLINE_FUNCTION(scr_write_##REG, CP, OP1, CRm)

#define SCR_RO_FUNCTIONS_64(REG, CP, OP1, CRm) \
    MRRC_INLINE_FUNCTION(scr_read_##REG, CP, OP1, CRm)

#define SCR_WO_FUNCTIONS_64(REG, CP, OP1, CRm) \
    MCRR_INLINE_FUNCTION(scr_write_##REG, CP, OP1, CRm)

#define SCR_RW_FUNCTIONS_V(REG)               \
    VMRS_INLINE_FUNCTION(scr_read_##REG, REG) \
    VMSR_INLINE_FUNCTION(scr_write_##REG, REG)

#define SCR_RO_FUNCTIONS_V(REG) \
    VMRS_INLINE_FUNCTION(scr_read_##REG, REG)

#define SCR_WO_FUNCTIONS_V(REG) \
    VMSR_INLINE_FUNCTION(scr_write_##REG, REG)

static inline unsigned int clz(unsigned int val)
{
    unsigned int ret = 0;

#ifndef CONFIG_NO_CLZ

#ifdef __CC_ARM
    __asm {
        clz ret, val
    }
    ;
#else // __GNUC__
    __asm__("clz %0, %1;"
            : "=&r"(ret)
            : "r"(val));
#endif

#else // CONFIG_NO_CLZ
    {
        int bit = sizeof(unsigned int) * 8 - 1;
        while (bit >= 0)
        {
            if (((val >> bit) & 0x1) == 0)
                ret++;
            else
                break;
            bit--;
        }
    }
#endif

    return ret;
}

// bit index of leading 1
// return [0,31] if val contains 1
// else return (~1ul)
static inline unsigned int biol1(unsigned int val)
{
    return sizeof(unsigned int) * 8 - 1 - clz(val);
}

// round to the next integer
static inline unsigned int ln2(unsigned int val)
{
    int result;

    assert(val != 0);
    result = biol1(val);

    // round
    if ((val & ~bitmask(result)) > 0)
        result += 1;

    return result;
}

static inline void dsb(void)
{
#ifdef __CC_ARM
    __asm("dsb");
#else // __GNUC__
    __asm__ __volatile__("dsb" ::
                             : "memory");
#endif
}

static inline void dmb(void)
{
#ifdef __CC_ARM
    __asm("dmb");
#else // __GNUC__
    __asm__ __volatile__("dmb" ::
                             : "memory");
#endif
}

static inline void isb(void)
{
#ifdef __CC_ARM
    __asm("isb");
#else // __GNUC__
    __asm__ __volatile__("isb" ::
                             : "memory");
#endif
}

#endif
