/*********************************************************
*
*********************************************************/
#ifndef ARMV7_A_FPU_H
#define ARMV7_A_FPU_H

#include <tools/macros.h>

static inline void fpu_context_force_save(void)
{
    // todo
}

static inline void fpu_enable(void)
{
    // todo;
}

static inline void fpu_disable(void)
{
    // todo
}

static inline void fpu_init(void)
{
    // todo
}

#endif
