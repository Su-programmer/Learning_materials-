#ifndef ARM_SMC_H
#define ARM_SMC_H

unsigned int do_smc(unsigned long* msg, unsigned int len);

#endif
