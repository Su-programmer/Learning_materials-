/*********************************************************
*
*********************************************************/
#ifndef ARMV7A_CONTEXT_H
#define ARMV7A_CONTEXT_H

#include <stdlib/ks_stdint.h>
#include <armv7-a/regs.h>
#include <armv7-a/regs.h>

typedef struct _context{
    uint32_t regs[REGS_COUNT];
    uint32_t enablefpu; // todo
}context_t;

static inline unsigned long context_get_reg(context_t *ctx, unsigned int rx)
{
    return ctx->regs[rx];
}

static inline unsigned long context_get_pc(context_t *ctx)
{
    return context_get_reg(ctx, PC);
}

static inline unsigned long context_get_retcode(context_t *ctx)
{
    return context_get_reg(ctx, R0);
}

static inline void context_prepare_exit(context_t *ctx)
{
    // todo
}

void context_init(context_t* ctx, int type);
void context_set_stack(context_t* ctx, void* stack, void* ipcbuffer, unsigned int size);
void context_set_retcode(context_t* ctx, int code);
void context_set_reg_param(context_t *ctx, uint32_t p1, uint32_t p2, uint32_t p3);
void context_set_entry(context_t* ctx, unsigned int entry);
void context_switch_prepare(context_t *to, context_t *from);
void context_enable_fpu(context_t *ctx);

void context_restore_current(void);

#endif
