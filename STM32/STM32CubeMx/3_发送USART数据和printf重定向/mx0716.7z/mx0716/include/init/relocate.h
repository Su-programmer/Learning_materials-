/************************************************************
 *              General Kernel Image Layout
 * |kernel|:
 * 
 *    CONFIG_LOAD_ADDR
 *          |
 *          v
 * 
 *          |bootphysic|boot|text|rodata|rootserver|shared_ro|rw|
 *          |<-     k_ro_xx           ->|<-       *        ->|
 *          |<-            kernelinfo.code                   |
 * 
 *          ^                                                ^
 *          |                                                |
 *    CONFIG_EXEC_ADDR                              +--------+
 *                                                  |
 *                               The virtual base of RW sections could be different
 *                                        with RO sections.
 * |rootserver|:                                    |
 *          |entry|text & rodata|rwdata|            |
 *                              |<- #->|            |
 *          |<-  rootserverinfo.code ->|            |
 *                                                  |
 *          ^                   ^                   |
 *          |                   |                   |
 * CONFIG_ROOTSERVER_EXEC_ADDR  +-------------------+
 *
 * |rw|:
 *          |rwdata|stack|bss|shared_rw|
 *          |<- #->|         |<-  *  ->|
 *          |<-     kernelinfo.data  ->|
 * 
 *   *: Rootserver accessable
 *   #: Need be copyed to the other RAM regions or remaped
 * 
 * The |kernel| MUST be loaded in a continuous space, such as
 * RAM, ROM or Flash.
 * **********************************************************/
#ifndef ARM_RELOCATE_H
#define ARM_RELOCATE_H

extern unsigned long boot_physic_start;
extern unsigned long boot_physic_end;
extern unsigned long boot_end;

extern unsigned long k_ro_start;
extern unsigned long k_ro_end;

extern unsigned long rs_ro_start;
extern unsigned long rs_ro_end;
extern unsigned long rs_ro_size;

extern unsigned long k_ro_shared_start;
extern unsigned long k_ro_shared_end;

extern unsigned long k_rw_start;
extern unsigned long k_rw_end;

/*
* No symbols for .stack
*/

extern unsigned long k_zi_start;
extern unsigned long k_zi_end;
extern unsigned long k_shared_start;
extern unsigned long k_shared_end;
extern unsigned long k_rw_end;

#endif
