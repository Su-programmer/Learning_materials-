/*********************************************************
*
*********************************************************/
#ifndef ALLOCATE_H
#define ALLOCATE_H

#include <uapi/bootinfo.h>

void allocator_dump_status(void);
int allocator_alloc(unsigned long begin, unsigned int size);
int allocator_free(unsigned long begin, unsigned int size);
unsigned long allocator_pbase(unsigned long vbase);
unsigned long allocator_vbase(unsigned long pbase);
void *allocator_get_rbtree(void);

int check_usram_region(void* begin, unsigned int size);

void shrink_region(region_t *curr, const region_t* reserved, int count);

// BOOT Code
void* allocator_alloc_block(unsigned int size, unsigned int align);
void allocator_init(void);

#endif
