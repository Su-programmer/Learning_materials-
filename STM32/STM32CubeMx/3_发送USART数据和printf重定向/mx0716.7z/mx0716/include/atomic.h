#ifndef ATOMIC_H
#define ATOMIC_H

#include <config.h>

typedef struct _atomic_t{
    volatile int data;
}atomic_t;

#define ATOMIC_INIT(n) { .data = n }

#ifndef CONFIG_NO_HARDWARE_PRIMITIVE_SUPPORT

// return the new value
int atomic_add(atomic_t *p, int val);
int atomic_sub(atomic_t *p, int val);
int atomic_load(const atomic_t *p);
int atomic_store(atomic_t *p, int val); // todo, useless

// return the old value
int atomic_exchange(atomic_t *p, int val);

// return 0 if failed, otherwise operation succeed
int atomic_compare_exchange(atomic_t *p, int expected, int newval);

#else

// return the new value
static inline int atomic_add(atomic_t *p, int val)
{
    p->data += val;
    return p->data;
}

static inline int atomic_sub(atomic_t *p, int val)
{
    p->data -= val;
    return p->data;
}

static inline int atomic_load(const atomic_t *p)
{
    return p->data;
}

static inline int atomic_store(atomic_t *p, int val)
{
    p->data = val;
    return p->data;
}

// return the old value
static inline int atomic_exchange(atomic_t *p, int val)
{
    int tmp = p->data;
    p->data = val;
    return tmp;
}

// return 0 if failed, otherwise operation succeed
static inline int atomic_compare_exchange(atomic_t *p, int expected, int newval)
{
    if(p->data == expected)
    {
        p->data = newval;
        return 1;
    }
    else
        return 0;
}

#endif // CONFIG_NO_HARDWARE_PRIMITIVE_SUPPORT

#endif
