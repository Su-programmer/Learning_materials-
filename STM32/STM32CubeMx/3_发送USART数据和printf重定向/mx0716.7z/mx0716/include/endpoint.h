#ifndef ENDPOINT_H
#define ENDPOINT_H

#include <stdlib/ks_stdint.h>

#include <tools/list.h>

#include <object.h>

typedef struct __endpoint
{
    object_t obj;
    list_t waiters;
    void *server;
    unsigned short state;
    unsigned short free;
}DEFAULT_ALINMENT endpoint_t;

enum _ep_state{
    EP_IDLE = 0, EP_SEND, EP_RECV, EP_DIED
};

static inline void endpoint_get(endpoint_t *ep)
{
    object_get(&ep->obj);
}

static inline void endpoint_put(endpoint_t *ep)
{
    object_put(&ep->obj, offset_of(endpoint_t, obj), sizeof(endpoint_t));
}

void endpoint_init(endpoint_t* ep);
void endpoint_send(endpoint_t* ep, unsigned int tag, unsigned int m0, unsigned int m1, void* sender);
void endpoint_receive(endpoint_t* ep, unsigned int tag, void *receiver);
void endpoint_call(endpoint_t* ep, unsigned int tag, unsigned int m0, unsigned int m1, void* caller);
int endpoint_reply(endpoint_t* ep, unsigned int tag, unsigned int m0, unsigned int m1, void* replier);
void endpoint_reply_wait(endpoint_t* ep, unsigned int tag, unsigned int m0, unsigned int m1, void* replier);
void endpoint_cancel(endpoint_t* ep);
void endpoint_clean_callers(void* tsk);
void endpoint_bind(endpoint_t* ep, void* tsk);
void endpoint_unbind(endpoint_t* ep, void* tsk);

#endif
