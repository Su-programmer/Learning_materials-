#ifndef SMP_H
#define SMP_H

#include <task.h>

void smp_tranfer_task(tcb_t* task, unsigned int targetcpu);
void smp_notify_core(unsigned int targetcpu);

void smp_secondary_cores_up(void);
void smp_active_secondary_cores(void);
unsigned int smp_current_cores(void);

void smp_init(void);

#endif
