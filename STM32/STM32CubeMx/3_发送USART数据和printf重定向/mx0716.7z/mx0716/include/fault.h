/******************************************************************************
*    For every task, there are two endpoints to receive fault report. For
*  the rootserver, this two endpoints are same, but for others, this two are
*  different at most times. The first one is the endpoint called 'faulthandler' 
*  in the tcb, the another one is the endpoint keept in the csapce of the
*  task at CAP_INDEX_FAULTHANDLER. A task can only wait on the fist
*  endpoint and should not change it. The rootserver could change the first
*  one when create a task, but there is no need to do it when the task is
*  clone from others.
*     The fisrt endpoint is used for reporting some critical errors, such as
*  memeory fault, fpu fault, and all of this errors should be handled by
*  rootserver. The another endpoint is used for remainning fault, such as child
*  quited.
******************************************************************************/
#ifndef FAULT_H
#define FAULT_H

#include <uapi/fault.h>

void fault_callback(void* task, long result, long useless);
void fault_report(void* task, int type, unsigned long info1, unsigned long info2);
void hardfault_handler(int type, unsigned long status, unsigned long addr);

#endif
