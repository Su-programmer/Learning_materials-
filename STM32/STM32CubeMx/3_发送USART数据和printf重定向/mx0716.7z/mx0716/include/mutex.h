#ifndef __MUTEX_H
#define __MUTEX_H

#include <stdlib/ks_stdint.h>

#include <tools/list.h>

#include <object.h>

#include <task.h>

typedef struct __mutex
{
	atomic_t lock;
	list_t   wait_list;
	tcb_t    *owner;
	object_t obj;
}DEFAULT_ALINMENT mutex_t;

static inline void mutex_get(mutex_t *mutex)
{
	object_get(&mutex->obj);
}

static inline void mutex_put(mutex_t *mutex)
{
	object_put(&mutex->obj,offset_of(mutex_t,obj),sizeof(mutex_t));
}

void mutex_init(mutex_t *mutex);
void mutex_lock(mutex_t *mutex);
void mutex_unlock(mutex_t *mutex);
int  mutex_trylock(mutex_t *mutex);




#endif
