/*********************************************************
*
*********************************************************/
#ifndef SCHEDULE_H
#define SCHEDULE_H

#include <stdlib/ks_stdint.h>
#include <task.h>
#include <arch/cpu.h>

#define ULONG_BITS (sizeof(unsigned long) * 8)
#define ULONG_LEFT_MOST_BIT (1ul << (ULONG_BITS - 1))

#define ACTION_RUN_CURRENT ((tcb_t *)0)
#define ACTION_CHOOSE_NEW ((tcb_t *)1)
#define ACTION_RUN_IDLE ((tcb_t *)2)

typedef struct __schedule_data
{
    tcb_t *pcurrent;
    tcb_t *pidle;

    list_t readyqueue[CONFIG_MAX_PRIORITY]; //先进先出队列
    list_t pendqueue;                       //按ready时间排列的队列

    tcb_t *action;

    unsigned long lvl1bit;
    unsigned long lvl2bit[(CONFIG_MAX_PRIORITY + ULONG_BITS - 1) / ULONG_BITS];
} schedule_data_t;

static inline tcb_t *current(void)
{
    extern schedule_data_t sd[];

#ifdef CONFIG_ENABLE_SMP
    return sd[current_cpu()].pcurrent;
#else
    return sd[0].pcurrent;
#endif
}

// request to run the @task that not attached
// to scheduler or any other queues at next time
void schedule_run(tcb_t *task);

// attach the @task to the scheduler.
// @task MUST NOT in any queue and can NOT be current() and idle.
// Dont attach current() even the current() has been detached, changed it's state is enough.
void schedule_attach(tcb_t *task);

// detach the @task from scheduler.
// if @task is current():
//      the @task will loose it's timeslice at next call to schedule(),
//    and scheduler will put it to the right queue of scheduler.
// else:
//       do NOT change the state of @task before call this, scheduler will remove
//    it from queues of scheduler.
void schedule_detach(tcb_t *task);

// when timer intterrupt comming, if the time changed,
// this should be called
void schedule_wakeup(unsigned int currenttime);

// choose a new task and prepare to run it
void schedule(void);

// initialize internal state of this scheduler,
// must be called only once.
void schedule_init(tcb_t *idle);

#endif
