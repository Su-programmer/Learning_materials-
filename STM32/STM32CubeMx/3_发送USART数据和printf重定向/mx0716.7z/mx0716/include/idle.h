#ifndef IDLE_H
#define IDLE_H

void idle(void);

#endif
