#ifndef OBJECT_H
#define OBJECT_H

#include <tools/macros.h>

#include <atomic.h>
#include <spinlock.h>
#include <allocate.h>
#include <dprintf.h>

// for every kernel object, the refcount will be 0 and the lock will be free 
// after initialize it.

typedef struct __object{
    atomic_t refcount;
    spinlock_t lock;
}object_t;

static inline int object_get(object_t* obj)
{
    return atomic_add(&obj->refcount, 1);
}

// if the @size is zero, the we don't free the object and offset will be useless
static inline int object_put(object_t* obj, unsigned int offset, unsigned int size)
{
   int ret = atomic_sub(&obj->refcount, 1);
   if(ret == 0 &&
       (size == 0 || allocator_free((unsigned long)obj - offset, size) != 0))
   {
       dprintf("Memory leaked at %x, total %d bytes!\n", (unsigned long)obj - offset, size);
   }
   
   return ret;
}

static inline int object_refcount(object_t *obj)
{
    return atomic_load(&obj->refcount);
}

static inline void object_lock(object_t* obj)
{
    spin_lock(&obj->lock);
}

static inline void object_unlock(object_t* obj)
{
    spin_unlock(&obj->lock);
}

static inline int object_try_lock(object_t* obj)
{
    return spin_try_lock(&obj->lock);
}

static inline void object_init(object_t *obj)
{
    spin_init_unlocked(&obj->lock);
    atomic_store(&obj->refcount, 0);
}

#endif
