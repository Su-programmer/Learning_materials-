#ifndef TIMER_H
#define TIMER_H

// todo: 
// typedef struct __time{ unsigned long t;}time_t;
typedef unsigned long time_t;

void timer_handler(void);
void timer_next(unsigned int us);


static inline void timer_next_ms(unsigned int ms)
{
    timer_next(ms * 1000);
}

static inline time_t timer_current(void)
{
    extern time_t boottime;
    return boottime;
}

static inline int timer_expired(time_t t)
{
    // Boottime will overflow certainly when running, so if the distance
    // between the @t and boottime is larger than the half of the max value
    // of time_t, @t has expired. If @t is equal to boottime, it's expired too,
    // so decrease 1 before comparring.
    return (t - timer_current() - 1) > ((~(time_t)0) / 2);
}

#endif
