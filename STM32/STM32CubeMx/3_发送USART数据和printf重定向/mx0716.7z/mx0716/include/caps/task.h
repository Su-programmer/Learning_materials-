#ifndef CAPS_TASK_H
#define CAPS_TASK_H

#include <caps/capability.h>

#include <task.h>

static tcb_t* cap_task_get_obj(capability_t *cap)
{
    return (tcb_t*)cap_get_long_info(cap);
}

static inline void cap_task_put(capability_t *cap)
{
    assert(cap != 0 && cap_get_type(cap) == CAP_THREAD);
    tcb_put(cap_task_get_obj(cap));
}

void cap_task_init(capability_t *cap, tcb_t *tcb);

void cap_task_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1);

#endif
