#ifndef CAPS_RAM_H
#define CAPS_RAM_H

#include <caps/capability.h>

#include <uapi/caps/ram.h>

void cap_ram_init(capability_t* cap, unsigned long desc, unsigned int type, unsigned int direct);

void cap_ram_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1);

#endif
