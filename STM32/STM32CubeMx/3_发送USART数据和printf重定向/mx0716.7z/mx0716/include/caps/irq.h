#ifndef CAPS_IRQ_H
#define CAPS_IRQ_H

#include <interrupt.h>

#include <caps/capability.h>

void cap_irqc_init(capability_t *cap);

void cap_irqh_init(capability_t *cap, notification_t *ntfn);

void cap_irqc_dispatcher(capability_t *cap, unsigned long tag, unsigned long cptr, unsigned long irqn);

void cap_irqh_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1);

#endif
