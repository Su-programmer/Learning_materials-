#ifndef CAPS_ARMSMC_H
#define CAPS_ARMSMC_H

#include <uapi/caps/capability.h>
#include <caps/capability.h>

static inline void cap_armsmc_init(capability_t* cap)
{
    cap_basic_init(cap, CAP_ARMSMC);
}

void cap_armsmc_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1);

#endif
