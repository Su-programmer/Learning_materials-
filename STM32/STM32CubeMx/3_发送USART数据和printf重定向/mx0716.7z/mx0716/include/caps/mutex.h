#ifndef __CAP_MUTEX_H
#define __CAP_MUTEX_H

#include <mutex.h>
#include <caps/capability.h>

static inline mutex_t* cap_mutex_get_obj(capability_t *cap)
{
	return (mutex_t *)cap_get_long_info(cap);
}

void cap_mutex_init(capability_t *cap,mutex_t *obj);

void cap_mutex_dispacher(capability_t *cap, unsigned long tag,unsigned long m0, unsigned long m1);

#endif
