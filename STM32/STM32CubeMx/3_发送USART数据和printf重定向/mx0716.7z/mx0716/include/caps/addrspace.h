#ifndef CAPS_ADDRSPACE_H
#define CAPS_ADDRSPACE_H

#include <addrspace.h>

#include <caps/capability.h>

static inline addrspace_t* cap_addrspace_get_obj(capability_t *cap)
{
    return (addrspace_t*)cap_get_long_info(cap);
}

static inline void cap_addrspace_put(capability_t *cap)
{
    assert(cap != 0 && cap_get_type(cap) == CAP_ADDRSPACE);
    addrspace_put(cap_addrspace_get_obj(cap));
}

int cap_addrspce_map(capability_t *cap, unsigned long begin, unsigned int size);

void cap_addrspace_init(capability_t* cap, addrspace_t* as);

#endif
