#ifndef CAPS_ENDPOINT_H
#define CAPS_ENDPOINT_H

#include <endpoint.h>

#include <caps/capability.h>

#define CAP_EP_ATTR_BIT_C 0
#define CAP_EP_ATTR_BIT_B 1
#define CAP_EP_ATTR_BIT_ID_WIDTH 16
#define CAP_EP_ATTR_BIT_ID_BEGIN 0

static inline endpoint_t* cap_ep_get_obj(capability_t *cap)
{
    return (endpoint_t*)cap_get_long_info(cap);
}

static inline void cap_ep_put(capability_t *cap)
{
    endpoint_put(cap_ep_get_obj(cap));
}

static inline int cap_ep_is_call_only(capability_t *cap)
{
    return cap_get_long_info(cap) & (1ul << CAP_EP_ATTR_BIT_C);
}

static inline void cap_ep_set_call_only(capability_t *cap)
{
    unsigned long value = cap_get_long_info(cap) | (1ul << CAP_EP_ATTR_BIT_C);
    cap_set_long_info(cap, value);
}

static inline void cap_ep_clean_call_only(capability_t *cap)
{
    unsigned long value = cap_get_long_info(cap) & ~(1ul << CAP_EP_ATTR_BIT_C);
    cap_set_long_info(cap, value);
}

void cap_ep_init(capability_t *cap, endpoint_t* obj, unsigned int id);

void cap_ep_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1);

#endif
