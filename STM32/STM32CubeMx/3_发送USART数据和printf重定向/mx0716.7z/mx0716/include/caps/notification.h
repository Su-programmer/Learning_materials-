#ifndef CAPS_NOTIFICATION_H
#define CAPS_NOTIFICATION_H

#include <notification.h>
#include <caps/capability.h>

static inline notification_t* cap_ntfn_get_obj(capability_t *cap)
{
    return (notification_t*)cap_get_long_info(cap);
}

static inline int cap_ntfn_put(capability_t *cap)
{
    return notification_put(cap_ntfn_get_obj(cap));
}

void cap_ntfn_init(capability_t *cap, notification_t *obj);

void cap_ntfn_dispatcher(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1);

#endif
