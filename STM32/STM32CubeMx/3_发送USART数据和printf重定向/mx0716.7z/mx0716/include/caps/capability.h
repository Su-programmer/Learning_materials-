#ifndef CAPS_CAPABILITY_H
#define CAPS_CAPABILITY_H

#include <stdlib/ks_stdint.h>
#include <stdlib/assert.h>

#include <tools/macros.h>

#include <uapi/initialcaps.h>
#include <uapi/caps/capability.h>

static inline const unsigned int* cap_get_capobj_size(void)
{
    extern const unsigned int capobj_size[];
    return capobj_size;
}

static inline void cap_set_type(capability_t *cap, unsigned long type)
{
    assert(type <= lowbitsmask(CAP_TYPE_BITS));
    
    cap->ww &= ~lowbitsmask(CAP_TYPE_BITS);
    cap->ww |= type;
}

static inline void cap_set_long_info(capability_t *cap, unsigned long info)
{
    cap->w = info;
}

static inline void cap_set_short_info(capability_t *cap, unsigned long info)
{
    assert(info <= lowbitsmask(sizeof(unsigned long)*8 - CAP_TYPE_BITS));
    
    cap->ww &= lowbitsmask(CAP_TYPE_BITS);
    cap->ww |= info << CAP_TYPE_BITS;
}

static inline void cap_basic_init(capability_t *cap, unsigned long type)
{
    cap->parent = cap;
    cap->next = 0;
    cap_set_type(cap, type);
}

static inline void cap_copy(capability_t *to, capability_t *from)
{
    assert(to != 0 && from != 0);
    
    to->next = from->next;
    to->parent = from->parent;
    if(to->next != 0)
        to->next->parent = to;
    from->next = to;
    
    to->w = from->w;
    to->ww = from->ww;
}

static inline void cap_make_empty(capability_t *cap)
{
    cap_basic_init(cap, CAP_EMPTY);
}

void cap_dispatcher(unsigned long cptr, unsigned long tag, unsigned long m0, unsigned long m1);

typedef void (*cap_dispather_t)(capability_t *cap, unsigned long tag, unsigned long m0, unsigned long m1);
extern const cap_dispather_t cap_dispathers[];
extern const unsigned int SHARED_RO capobj_size[];

// return the index of next empty capability
int BOOTONLY initial_cspace_lock_ram(void);

// parameter @as is a pointer to addrspace_t
capability_t* BOOTONLY initial_cspace_init(void *init, void* addrspace, void* faulthandler);

#endif
