/*********************************************************
*
*********************************************************/
#ifndef MX_TASK_H
#define MX_TASK_H

#include <config.h>

#include <stdlib/ks_stdint.h>
#include <stdlib/ks_stddef.h>
#include <stdlib/ks_string.h>

#include <tools/list.h>
#include <tools/macros.h>

#include <addrspace.h>
#include <object.h>
#include <endpoint.h>
#include <timer.h>

#include <caps/capability.h>
#include <caps/cnode.h>

#include <arch/context.h> // for context_t

#include <uapi/ipcbuffer.h>

#define TTYPE_USER 0x00
#define TTYPE_KERNEL 0xff

#define TCB_MAGIC (0x6D746362) // "mtcb"

#define TASK_READY        (0x0000)
#define TASK_SLEEP        (0x0001)
#define TASK_BLOCKED      (0x0002)

#define TASK_INACTIVE     (0x8001)
#define TASK_IDLE         (0x8002)
#define TASK_EXIT_ZOMBIE  (0x8004)
#define TASK_DIED         (0x8008)

// current task has some errors and is reporting
#define TASK_FBIT_REPORT   (0x0001)
// current task is doing ipc and want to do call or be called
#define TASK_FBIT_CALL   (0x0002)

typedef struct __timeslice{
    time_t readytime;
    unsigned int timeslice;
    unsigned int timeleft;
}timeslice_t;

typedef struct _task_control_block
{
    unsigned int magic;
    
    unsigned long id;
    
    time_t readytime;
    unsigned int timeslice;

    // todo
    //timeslice_t timeslice;
    //timeslice_t* currentts;
    
    unsigned short state;
    unsigned short flags;
    
    unsigned int priority;
    unsigned int maxpriority;
    
    // ipcbuffer belong to this task same as the stack.
    // As the stack belong to user space, so we don't record it.
    void* ipcbuffer;
    
    capability_t cnode;
    addrspace_t *addrspace;
    
    endpoint_t *faulthandler;
    int currentfault;
    
    // every task can only in one @callers list, recored by @calledep and @callernode,
    // and could have many callers recored by callers.
    endpoint_t *calledep;
    list_t callernode;
    list_t callers;
    
    list_t runlist;
    object_t obj;
    
#ifdef CONFIG_DEBUG
    char name[24];
#endif
    
    context_t context;
}DEFAULT_ALINMENT tcb_t;

void tcb_recycle(tcb_t *tcb);

static inline void tcb_get(tcb_t *tcb)
{
    object_get(&tcb->obj);
}

static inline int tcb_put(tcb_t *tcb)
{
    int refcount = object_put(&tcb->obj, 0, 0); 
    if(refcount == 0)
        tcb_recycle(tcb);
    return refcount;
}

static inline bool tcb_is_valid(tcb_t *tcb)
{
    return tcb->magic == TCB_MAGIC;
}

static inline void task_set_fault(tcb_t *task, int fault)
{
    task->currentfault = fault;
}

static inline int task_get_fault(tcb_t *task)
{
    return task->currentfault;
}

static inline unsigned int task_get_state(tcb_t *task)
{
    return task->state;
}

static inline unsigned int task_get_flags(tcb_t *task)
{
    return task->flags;
}

static inline unsigned long task_get_id(tcb_t *task)
{
    return task->id;
}

static inline void task_set_state(tcb_t *tcb, unsigned int state)
{
    tcb->state = state;
}

static inline void task_set_flags(tcb_t *tcb, unsigned int bits)
{
    tcb->flags |= bits;
}

static inline void task_clear_flags(tcb_t *tcb, unsigned int bits)
{
    tcb->flags &= ~bits;
}

static inline void task_set_priority(tcb_t *tcb, unsigned int prio)
{
    tcb->priority = prio;
}

static inline void task_set_maxpriority(tcb_t *tcb, unsigned int prio)
{
    tcb->maxpriority = prio;
}

static inline unsigned int task_get_priority(tcb_t *task)
{
    return task->priority;
}

static inline unsigned int task_get_maxpriority(tcb_t *task)
{
    return task->maxpriority;
}

static inline endpoint_t* task_get_faulthandler(tcb_t *task)
{
    return task->faulthandler;
}

static inline void task_set_faulthandler(tcb_t *task, endpoint_t *fh)
{
    if(task->faulthandler != 0)
        endpoint_put(task->faulthandler);
    
    endpoint_get(fh);
    task->faulthandler = fh;
}

static inline void task_set_timeslice(tcb_t *tcb, unsigned int ts)
{
    tcb->timeslice = ts;
}

static inline ipcbuffer_t* task_get_ipcbuffer(tcb_t *tcb)
{
    return tcb->ipcbuffer;
}

static inline context_t* task_get_context(tcb_t *tcb)
{
    return &tcb->context;
}

static inline capability_t* task_get_cnode(tcb_t *task)
{
    return &task->cnode;
}

static inline addrspace_t* task_get_addrspace(tcb_t *task)
{
    return task->addrspace;
}

static inline void task_set_addrspace(tcb_t *task, addrspace_t* addrspace)
{
    addrspace_get(addrspace);
    task->addrspace = addrspace;
}

static inline unsigned long task_get_pc(tcb_t *task)
{
    return context_get_pc(&task->context);
}

#ifdef CONFIG_DEBUG

static inline void task_set_name(tcb_t* task, const char* name)
{
    ks_memcpy(task->name, name, sizeof(task->name));
    task->name[sizeof(task->name)-1] = 0;
}

static inline void task_dump_info(tcb_t* task)
{
    dprintf("Task: %x, ID: %x, Name: %s, PC: %x\n", (unsigned long)task, task->id,
            task->name, task_get_pc(task));
}

#else // ifndef CONFIG_DEBUG

#define task_set_name(x, y)
#define task_dump_info(x)

#endif // #ifdef CONFIG_DEBUG

static inline unsigned long task_get_retcode(tcb_t *task)
{
    return context_get_retcode(&task->context);
}

static inline void task_set_retcode(tcb_t *tcb, int retcode)
{
    extern void context_set_retcode(context_t* ctx, int code);
    
    context_set_retcode(task_get_context(tcb), retcode);
}

static inline void task_set_stack(tcb_t *tcb, void *stack, void* ipcbuffer, unsigned int stacklen)
{
    extern void context_set_stack(context_t* ctx, void* stack, void* ipcbuffer, unsigned int size);
    
    tcb->ipcbuffer = ipcbuffer;
    context_set_stack(task_get_context(tcb), stack, ipcbuffer, stacklen);
}

static inline void task_set_entry(tcb_t *tcb, unsigned long entry)
{
    extern void context_set_entry(context_t* ctx, unsigned int entry);
    context_set_entry(task_get_context(tcb), entry);
}

static inline void task_set_reg_param(tcb_t *tcb, uint32_t p1, uint32_t p2, uint32_t p3)
{
    extern void context_set_reg_param(context_t *ctx, uint32_t p1, uint32_t p2, uint32_t p3);
    context_set_reg_param(task_get_context(tcb), p1, p2, p3);
}

static inline void task_prepare_exit(tcb_t *task)
{
    context_prepare_exit(task_get_context(task));
}

void task_init(tcb_t* task, int type);
void task_switch_prepare(tcb_t *to, tcb_t* from);
void task_configure(tcb_t* );
void task_clone(tcb_t* target, tcb_t* src, unsigned long id);

#endif
