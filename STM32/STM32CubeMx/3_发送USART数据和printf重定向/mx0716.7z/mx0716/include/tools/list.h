/*********************************************************
* Double Linked Loop List
*********************************************************/
#ifndef MX_LIST_H
#define MX_LIST_H

/// WARNING: this folder is shared between kernel and libmx,
/// be careful with the included headers.

#include <tools/macros.h>
#define LIST_INIT(li) {.prev = &li, .next = &li}
#define list_foreach(pos, head, type, member) \
        for((pos) = container_of((head)->next, type, member); \
             &(pos)->member != (head); \
             (pos) = container_of((pos)->member.next, type, member))

#ifndef assert
#define assert(x)
#endif

typedef struct __list
{
    struct __list* prev;
    struct __list* next;
}list_t;

static inline void list_init(list_t *li)
{
    assert(li != 0);
    
    li->prev = li;
    li->next = li;
}

// after insert: front <-> node <-> orignal node
static inline void list_insert(list_t *front, list_t *node)
{
    assert(front != 0);
    assert(node != 0);
    
    node->next = front->next;
    node->prev = front;
    front->next = node;
    node->next->prev = node;
}

static inline void list_append(list_t* head, list_t *node)
{
    assert(head != 0);
    assert(node != 0);
    
    list_insert(head->prev, node);
}

static inline void list_remove(list_t *node)
{
    assert(node != 0);
    
    node->next->prev = node->prev;
    node->prev->next = node->next;
    
    list_init(node);
}

static inline int list_is_empty(list_t *head)
{
    return head->next == head;
}

#endif
