#ifndef RBTREE_H
#define RBTREE_H

/// WARNING: this folder is shared between kernel and libmx,
/// be careful with the included headers.

#include <ks_limits.h>

#ifdef __cplusplus
extern "C"{
#endif

//#define RBTREE_TEST_TOOL

typedef struct _rbnode{
    struct _rbnode *parent;
    struct _rbnode *lchild, *rchild;
    unsigned long data:(WORD_BITS-1);
    unsigned color:1;
}rbnode_t;

// compare_less(): if @lhs < @rhs, return true, else return false
void rbtree_insert(rbnode_t* tree, rbnode_t* node,
                   int (*compare_less)(rbnode_t*lhs, rbnode_t* rhs));

void rbtree_delete(rbnode_t* tree, rbnode_t* node);

// compare() : if @lhs == @data, return 0
//              if @lhs < @data, return <0
//              else   return >0
rbnode_t* rbtree_find(const rbnode_t* tree, unsigned long data,
                      int (*compare)(rbnode_t* lhs, unsigned long data));

rbnode_t* rbtree_left_most(const rbnode_t* tree);

rbnode_t* rbnode_next(const rbnode_t* tree, const rbnode_t* node);

void rbtree_head_init(rbnode_t* head);

#ifdef RBTREE_TEST_TOOL
// return 0 if failed
int tree_check(rbnode_t* tree, int *depth, int *nodes);
#endif

#ifdef __cplusplus
}
#endif

#endif
