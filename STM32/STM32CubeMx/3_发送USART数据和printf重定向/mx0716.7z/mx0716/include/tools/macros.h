#ifndef MACROS_H
#define MACROS_H

/// WARNING: this folder is shared between kernel and libmx,
/// be careful with the included headers.

#include <ks_stdint.h>
#include <assert.h>

#define offset_of(t, m) ((unsigned long)&((t*)0)->m)
    
#define container_of(p, type, member) \
    ((type*)((unsigned long)(p) - (unsigned long)(&((type*)0)->member)))

#define likely(x) (x)
#define unlikely(x) (x)
    
#define bitmask(x) (1ul << (x))
#define lowbitsmask(x) (bitmask(x)-1ul)
#define align_to(size, align) ((((size) + (align) - 1) / (align))*(align))  //鍚戜笂瀵归綈
    
#define BOOTONLY __attribute__((section(".boot")))
#define BOOTDATA __attribute__((section(".boot.data")))
#define BOOTPHYSIC __attribute__((section(".boot.physic")))
#define WEAK __attribute__((weak))

// WARNING: shared variable would NOT be initialized by kernel, it's belong to bss.
#define SHARED_BSS __attribute__((section(".shared_bss")))
#define SHARED_RO __attribute__((section(".shared_ro")))
    
// align to the size of x, x must be powered by 2.
#define ALIGNED(x) __attribute__((aligned(x)))
#define DEFAULT_ALINMENT ALIGNED(8) // aligned to 8 bytes

// for hardware registers defination
#define REG32_RW(addr) (*(volatile uint32_t*)(addr))
#define REG32_RO(addr) (*(const volatile uint32_t*)(addr))
#define REG32_WO(addr) REG32_RW(addr)
#define REG32s_RW(addr) ((volatile uint32_t*)(addr))
#define REG32s_RO(addr) ((const volatile uint32_t*)(addr))
#define REG32s_WO(addr) REG32s_RW(addr)

static inline unsigned long bitfield_get(unsigned long value, unsigned int begin, unsigned int width)
{
    assert(width > 0 && begin < (sizeof(unsigned long)*8 - 1));
    return (value >> begin) & lowbitsmask(width);
}

static inline unsigned long bitfield_clean(unsigned long value, unsigned int begin, unsigned int width)
{
    assert(width > 0 && begin < (sizeof(unsigned long)*8 - 1));
    value &= ~(lowbitsmask(width) << begin);
    return value;
}

static inline unsigned long bitfield_set(unsigned long value, unsigned int begin, unsigned int width, unsigned int bv)
{
    assert(bv < lowbitsmask(width));
    value = bitfield_clean(value, begin, width);
    value |= bv << begin;
    return value;
}

#endif
