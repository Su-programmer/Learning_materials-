#ifndef CORTEX_TIMERS_H
#define CORTEX_TIMERS_H

#include <tools/macros.h>
#include <plat/device.h>
#include <armv7-a/scr.h>

#define TIME_TEST 1
// enum __SCR_CNTPCTL_BITS{
//     SCR_CNTPCTL_BIT_ISTATUS = 2,
//     SCR_CNTPCTL_BIT_IMASK   = 1,
//     SCR_CNTPCTL_BIT_ENABLE  = 0,
// };

/*****************************************************************************************************/

#define readl(a) *(volatile unsigned int *)(unsigned long)(a)
#define writel(v, c) *(volatile unsigned int *)(unsigned long)(c) = (v)

#if 1

static inline void timer_enable(void)
{
	uint32_t val;
	val = scr_read_CNTP_CTL();
	val |= bitmask(SCR_CNTPCTL_BIT_ENABLE);
	scr_write_CNTP_CTL(val);
}

static inline void timer_disable(void)
{
	uint32_t val;
	val = scr_read_CNTP_CTL();
	val &= ~bitmask(SCR_CNTPCTL_BIT_ENABLE);
	scr_write_CNTP_CTL(val);
}

static inline void timer_enable_int(void)
{
	uint32_t val;
	val = scr_read_CNTP_CTL();
	val &= ~bitmask(SCR_CNTPCTL_BIT_IMASK);
	scr_write_CNTP_CTL(val);
}

static inline void timer_disable_int(void)
{
	uint32_t val;
	val = scr_read_CNTP_CTL();
	val |= bitmask(SCR_CNTPCTL_BIT_IMASK);
	scr_write_CNTP_CTL(val);
}

static inline void timer_ack_int(void)
{
	//scr_write_CNTP_TVAL(26000);
	return;
}

unsigned long timer_get_left(void);
unsigned long timer_set_next(unsigned long us);
unsigned long timer_stop(void);
void timer_init(void);
void count_start();
void count_end();
#endif

#endif
