#include <stdlib/ks_string.h>
#include <stdlib/assert.h>

#include <task.h>

#include <uapi/ipcbuffer.h>

void ipcbuffer_partial_transfer(void* _dst, void* _src, unsigned long tag)
{
    tcb_t* dst = _dst;
    tcb_t* src = _src;
    
    ipcbuffer_t *dbuf;
    ipcbuffer_t *sbuf;
    unsigned int len;
    
    unsigned long* dmsgs;
    unsigned long* smsgs;
    
    assert(tcb_is_valid(dst) && tcb_is_valid(src));
    
    dbuf = task_get_ipcbuffer(dst);
    sbuf = task_get_ipcbuffer(src);
    
    // the first 2 words will be transferred through registers, ignore them
    dmsgs = ipcbuffer_get_msgs(dbuf) + 2;
    smsgs = ipcbuffer_get_msgs(sbuf) + 2;
    len = msgtag_get_len(tag) - 2;
    
    if(msgtag_get_len(tag) <= 2)
        return;
    
    if(len <= (IPC_MAX_MSGWORDS - 2))
        ks_memcpy(dmsgs, smsgs, len*sizeof(unsigned long));
    else
        dprintf("Warning: too many messages words to copy!\n");
}

void ipcbuffer_regs_transfer(void* _dst, unsigned long tag, unsigned long m0, unsigned long m1)
{
    tcb_t* dst = _dst;
    
    ipcbuffer_t *buf = task_get_ipcbuffer(dst);
    
    assert(tcb_is_valid(dst));
    ipcbuffer_save(buf, tag, m0, m1);
}

void ipcbuffer_full_transfer(void* _dst, void *_src)
{
#if !DPRINTF_MUTEK_IPCBUFFER
    dprintf("ipcbuffer_full_transfer\n");
#endif
    tcb_t* dst = _dst;
    tcb_t* src = _src;
    
    unsigned long *msgs;
    unsigned long tag;   
    ipcbuffer_t *f;
    
    assert(tcb_is_valid(dst) && tcb_is_valid(src));
    
    f = task_get_ipcbuffer(src);
    msgs = ipcbuffer_get_msgs(f);
    tag = ipcbuffer_get_tag(f);

#if !DPRINTF_MUTEK_IPCBUFFER
    dprintf("tag = %x, msgs[0] = %x, msgs[1] = %x \n", tag, msgs[0], msgs[1]);    
#endif

    ipcbuffer_regs_transfer(dst, tag, msgs[0], msgs[1]);
    if(ipcbuffer_get_msglen(f) > 2)
        ipcbuffer_partial_transfer(dst, src, tag);
}
