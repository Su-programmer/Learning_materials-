#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <libmx/mxipc.h>
#include "ipccall.h"
extern cptr_t net_ep;

#define PACK_REQ(name,args) req.req_##name.args = args

#define PACK_REQ_T(name,type,args) req.req_##name.args = (type)args

#define INIT_HANDLE(qtype) \
struct socket_req req; \
struct socket_reply reply;\
memset(&req, 0,   sizeof(struct socket_req));\
memset(&reply, 0, sizeof(struct socket_reply));		\
req.reqtype = qtype

#define RECIEV_HANDLE(ep,reply)  \
mxsend(ep, (void*)&req, sizeof(struct socket_req));\
mxrecv(ep, (void*)&reply, sizeof(struct socket_reply));

extern int DEBUG_getsocket(int fd);
int socket (int _domain, int _type, int _protocol){   
	int fd = -1;
	struct socket_req req;
	struct socket_reply reply;
	memset(&req, 0,   sizeof(struct socket_req));
	memset(&reply, 0, sizeof(struct socket_reply));

	req.reqtype = SO_REQ_SOCKET;	
	
	req.req_socket.domain	= _domain;
	req.req_socket.type		= _type;	
	req.req_socket.protocol	= _protocol;
	
	mxsend(net_ep, (void*)&req, sizeof(struct socket_req));
	mxrecv(net_ep, (void*)&reply, sizeof(struct socket_reply));
	if(reply.reply_state == SOE_FAIL)
	{
		printf("Error : create socket failed when ??? !!!\n");
	} else {
		fd = reply.rtn_int;
	}
	return fd;
	
	
}
int accept(int fd, struct sockaddr *addr, socklen_t *addrlen){ 

	int nfd = -1;
	struct socket_req req;
	struct socket_reply reply;
	memset(&req, 0,   sizeof(struct socket_req));
	memset(&reply, 0, sizeof(struct socket_reply));
	
	req.reqtype = SO_REQ_ACCEPT;	
	
	req.req_accept.fd     	= fd;
	req.req_accept.addr     = addr; 
	req.req_accept.addrlen	= addrlen;
	
	mxsend(net_ep, (void*)&req, sizeof(struct socket_req));
	mxrecv(net_ep, (void*)&reply, sizeof(struct socket_reply));
	if(reply.reply_state == SOE_FAIL)
	{
		printf("Error : accept socket failed when ??? !!!\n");
	} else {
		nfd = reply.rtn_int;
	}
	printf("OUT new fd: %d\n",nfd);
	printf("OUT new skt: %d\n",DEBUG_getsocket(nfd));
	return nfd;
	
	
}
int setsockopt (int fd, int level, int optname, const void *optval, socklen_t optlen){	

	INIT_HANDLE(SO_REQ_SETSOCKOPT);
	
	PACK_REQ(setsockopt,fd);
	PACK_REQ(setsockopt,level);
	PACK_REQ(setsockopt,optname);
	PACK_REQ_T(setsockopt,void*,optval);
	PACK_REQ(setsockopt,optlen);
	
	RECIEV_HANDLE(net_ep,reply);
	
	return reply.rtn_int;
	
}

int bind(int fd, const struct sockaddr *name, socklen_t namelen){	

	INIT_HANDLE(SO_REQ_BIND);
	
	PACK_REQ(bind,fd);
	PACK_REQ_T(bind,struct sockaddr *,name);
	PACK_REQ(bind,namelen);
	
	RECIEV_HANDLE(net_ep,reply);
	
	return reply.rtn_int;	
	
}

ssize_t recvfrom(int fd, void *mem, size_t len, int flags,struct sockaddr *from,socklen_t *fromlen){
	


	INIT_HANDLE(SO_REQ_RECVFROM);	
 
	PACK_REQ(recvfrom,fd);
	PACK_REQ(recvfrom,mem);
	PACK_REQ(recvfrom,len);
	PACK_REQ(recvfrom,flags);
	PACK_REQ(recvfrom,from);
	PACK_REQ(recvfrom,fromlen);
		
	mxsend(net_ep, (void*)&req, sizeof(struct socket_req));
	mxrecv(net_ep, (void*)&reply, sizeof(struct socket_reply));
	
	return reply.rtn_ssize_t;	
	
}

ssize_t sendto(int fd, const void *dataptr, size_t size, int flags, const struct sockaddr *to, socklen_t tolen){
	
	INIT_HANDLE(SO_REQ_SENDTO);	
 
	PACK_REQ(sendto,fd);
	PACK_REQ_T(sendto,void *,dataptr);
	PACK_REQ(sendto,size);
	PACK_REQ(sendto,flags);
	PACK_REQ_T(sendto,struct sockaddr *,to);
	PACK_REQ(sendto,tolen);
	
	RECIEV_HANDLE(net_ep,reply);
	
	return reply.rtn_ssize_t;	
	
}
int connect(int fd, const struct sockaddr *name, socklen_t namelen){
	
	INIT_HANDLE(SO_REQ_CONNECT);	 
 
	PACK_REQ(connect,fd);
	PACK_REQ_T(connect,struct sockaddr *,name);
	PACK_REQ(connect,namelen);
	
	RECIEV_HANDLE(net_ep,reply);
	
	return reply.rtn_int;	
	
}


ssize_t recv(int fd, void *mem, size_t len, int flags){
	
	INIT_HANDLE(SO_REQ_RECV);	
 
	PACK_REQ(recv,fd); 	
	PACK_REQ(recv,mem);
	PACK_REQ(recv,len);
	PACK_REQ(recv,flags);
		
	RECIEV_HANDLE(net_ep,reply);
		
	return reply.rtn_ssize_t;	
	
}

ssize_t send(int fd, const void *dataptr, size_t size, int flags){
	
	INIT_HANDLE(SO_REQ_SEND);	
 
	PACK_REQ(send,fd);
	PACK_REQ_T(send,void *,dataptr);
	PACK_REQ(send,size);
	PACK_REQ(send,flags);
	
	RECIEV_HANDLE(net_ep,reply);
	
	return reply.rtn_ssize_t;	
	
}

int listen(int fd, int backlog){
	
	INIT_HANDLE(SO_REQ_LISTEN);	 
 
	PACK_REQ(listen,fd);
	PACK_REQ(listen,backlog);
	
	RECIEV_HANDLE(net_ep,reply);
	
	return reply.rtn_int;	
	
}

int closesocket(int fd){
	INIT_HANDLE(SO_REQ_CLOSESOCKET);		

	req.req_fd = fd;
	
	RECIEV_HANDLE(net_ep,reply);	
	
	return reply.rtn_int;	
	
}

