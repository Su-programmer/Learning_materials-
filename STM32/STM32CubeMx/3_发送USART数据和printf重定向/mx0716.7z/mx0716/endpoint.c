#include <tools/macros.h>
#include <tools/list.h>

#include <endpoint.h>
#include <task.h>
#include <schedule.h>
#include <fault.h>

#include <uapi/errors.h>
#include <uapi/ipcbuffer.h>

void endpoint_init(endpoint_t* ep)
{
    list_init(&ep->waiters);
    ep->state = EP_IDLE;
    ep->server = 0;
    object_init(&ep->obj);
}

static void endpoint_enque(endpoint_t* ep, tcb_t* task)
{
    tcb_t *cur;
    list_t *pos = &ep->waiters;

    schedule_detach(task);
    
    // this check is for error report
    if(~task_get_flags(task) & TASK_FBIT_REPORT)
        task_set_state(task, TASK_BLOCKED);
    
    list_foreach(cur, &ep->waiters, tcb_t, runlist)
    {
        if(cur->priority > task->priority)
        {
            pos = cur->runlist.prev;
            break;
        }
    }
    list_insert(pos, &task->runlist);
}

static inline void endpoint_deque(tcb_t* task)
{
    list_remove(&task->runlist);
    
    // this check is for error report
    if(~task_get_flags(task) & TASK_FBIT_REPORT)
        task_set_state(task, TASK_READY); // todo: handle the exiting task
}

static inline void try_promote_priority(tcb_t *dst, tcb_t *src)
{
    if(task_get_priority(src) < task_get_priority(dst))
    {
        if(!list_is_empty(&dst->runlist))
        {
            schedule_detach(dst);
            task_set_priority(dst, task_get_priority(src));
            schedule_attach(dst);
        }
        else
            task_set_priority(dst, task_get_priority(src));
    }
}

static inline void recovery_priority(tcb_t *tsk)
{
    task_set_priority(tsk, task_get_maxpriority(tsk));
}

void endpoint_send(endpoint_t* ep, unsigned int tag, unsigned int m0, unsigned int m1, void* _sender)
{
    tcb_t* receiver;
    tcb_t* sender = _sender;
    
    switch(ep->state)
    {
        case EP_SEND:
        case EP_IDLE:
            if(ep->server != 0)
                try_promote_priority(ep->server, sender);
            
            if(msgtag_get_extra(tag) != 0) // non-block send
                task_set_retcode(sender, -EAGAIN);
            else
            {
                ipcbuffer_save(task_get_ipcbuffer(sender), tag, m0, m1);
                tcb_get(sender);
                endpoint_enque(ep, sender);
                ep->state = EP_SEND;
            }
            return;
        
        case EP_RECV:
            receiver = container_of(ep->waiters.next, tcb_t, runlist);
            endpoint_deque(receiver);
            if(list_is_empty(&ep->waiters))
                ep->state = EP_IDLE;
            break;
        
        default:
            // these codes should never be executed
            task_set_retcode(sender, -EINVALID);
            return;
    }
    
    // transfer the messages and schedule the receiver
    ipcbuffer_regs_transfer(receiver, tag, m0, m1);
    ipcbuffer_partial_transfer(receiver, sender, tag);
    task_set_retcode(receiver, ESUCCESS);
    if(task_get_flags(sender) & TASK_FBIT_CALL)
    {
        // the sender want to do a call, then save the caller info to the receiver
        endpoint_get(ep);
        tcb_get(sender);
        sender->calledep = ep;
        list_insert(&receiver->callers, &sender->callernode);
        task_set_state(sender, TASK_BLOCKED);
        schedule_detach(sender);
        task_clear_flags(sender, TASK_FBIT_CALL);

        // promote the priority of receiver
        try_promote_priority(receiver, sender);
    }
    else
    {
        task_set_retcode(sender, ESUCCESS);
    }
    
    schedule_attach(receiver);
    tcb_put(receiver);
}

void endpoint_receive(endpoint_t* ep, unsigned int tag, void *_receiver)
{
    tcb_t* sender;
    tcb_t* receiver = _receiver;
    
    assert(tcb_is_valid(receiver));
    
    switch(ep->state)
    {
        case EP_IDLE:
        case EP_RECV:
            if(msgtag_get_extra(tag) != 0) // non-block receive
                task_set_retcode(receiver, -EAGAIN);
            else
            {
                tcb_get(receiver);
                endpoint_enque(ep, receiver);
                ep->state = EP_RECV;
            }
            break;
        
        case EP_SEND:
            sender = container_of(ep->waiters.next, tcb_t, runlist);
            endpoint_deque(sender);
        
            ipcbuffer_full_transfer(receiver, sender);
	  
            if(task_get_flags(sender) & TASK_FBIT_CALL)
            {
                // if sender want to do a call
                endpoint_get(ep);
                sender->calledep = ep;
                list_insert(&receiver->callers, &sender->callernode);
                task_set_state(sender, TASK_BLOCKED);
                task_clear_flags(sender, TASK_FBIT_CALL);

                try_promote_priority(receiver, sender);
            }
            else
            {
                task_set_retcode(sender, ESUCCESS);
                schedule_attach(sender);
                tcb_put(sender);
            }
        
            task_set_retcode(receiver, ESUCCESS);
        
            if(list_is_empty(&ep->waiters))
                ep->state = EP_IDLE;
            break;
        
        default:
            task_set_retcode(receiver, -EINVALID);
            break;
    }
}

void endpoint_call(endpoint_t* ep, unsigned int tag, unsigned int m0, unsigned int m1, void* _caller)
{
    tcb_t* caller = _caller;
    task_set_flags(caller, TASK_FBIT_CALL);
    endpoint_send(ep, tag, m0, m1, caller);
}

int endpoint_reply(endpoint_t* ep, unsigned int tag, unsigned int m0, unsigned int m1, void* _replier)
{
    tcb_t* replier = _replier;
    tcb_t* caller = container_of(replier->callers.next, tcb_t, callernode);
    
    assert(tcb_is_valid(replier));
    
    if(list_is_empty(&replier->callers) || caller->calledep != ep)
    {
        // there's no caller saved or the endpoint is not match
        task_set_retcode(replier, -EGENERAL);
        return -EGENERAL;
    }
    
    list_remove(&caller->callernode);
    ipcbuffer_regs_transfer(caller, tag, m0, m1);
    ipcbuffer_partial_transfer(caller, replier, tag);

    // recovery the priority of replier
    recovery_priority(replier);
    
    task_set_retcode(caller, ESUCCESS);
    if(task_get_flags(caller) & TASK_FBIT_REPORT)
    {
        // if this is a reply of fault report, then tell the fault reporter
        fault_callback(caller, m0, m1);
    }
    else
    {
        task_set_state(caller, TASK_READY);
        schedule_attach(caller);
    }
    tcb_put(caller);
    
    task_set_retcode(replier, ESUCCESS);
    endpoint_put(ep);
    return ESUCCESS;
}

void endpoint_reply_wait(endpoint_t* ep, unsigned int tag, unsigned int m0, unsigned int m1, void* replier)
{
    if(endpoint_reply(ep, tag, m0, m1, replier) == ESUCCESS)
        endpoint_receive(ep, tag, replier);
}

void endpoint_cancel(endpoint_t* ep)
{
    tcb_t *waiter;
    
    while(list_is_empty(&ep->waiters))
    {
        waiter = container_of(ep->waiters.next, tcb_t, runlist);
        endpoint_deque(waiter);
        
        task_clear_flags(waiter, TASK_FBIT_CALL);
        task_set_retcode(waiter, -ECANCELED);
        schedule_attach(waiter);
    }
    
    ep->state = EP_DIED;
}


void endpoint_clean_callers(void* _tsk)
{
    tcb_t* tsk = _tsk;
    tcb_t* cur;
    
    assert(tcb_is_valid(tsk));
    
    while(!list_is_empty(&tsk->callers))
    {
        cur = container_of(tsk->callers.next, tcb_t, callernode);
        list_remove(&cur->callernode);
        
        task_set_state(cur, TASK_READY);
        task_set_retcode(cur, -ECANCELED);
        schedule_attach(cur);
        tcb_put(cur);
        endpoint_put(cur->calledep);
    }
}

void endpoint_bind(endpoint_t* ep, void* _tsk)
{
    tcb_t *sender = container_of(ep->waiters.next, tcb_t, runlist);
    tcb_t *tsk = _tsk;

    tcb_get(tsk);
    ep->server = tsk;

    // promote the priority from now
    if(ep->state == EP_SEND)
        try_promote_priority(tsk, sender);
    task_set_retcode(tsk, ESUCCESS);
}

void endpoint_unbind(endpoint_t* ep, void* tsk)
{
    if(ep->server == tsk)
    {
        ep->server = 0;

        // recovery the priority
        recovery_priority(tsk);
        task_set_retcode(tsk, ESUCCESS);
        tcb_put(tsk);
    }
    else
        task_set_retcode(tsk, -EPERMIT);
}
