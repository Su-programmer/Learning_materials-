#include <config.h>

#ifdef CONFIG_DEBUG
#include <stdlib/assert.h>

#include <atomic.h>
#include <spinlock.h>
#include <dprintf.h>

static void atomic_test(void)
{
    atomic_t v = {0};
    int ret = 0;
    
    dprintf("Test Atomic_t Operations...\n");
    
    ret = atomic_add(&v, 10);
    assert(ret == 10 && v.data == 10);
    
    ret = atomic_sub(&v, 2);
    assert(ret == 8 && v.data == 8);
    
    ret = atomic_load(&v);
    assert(ret == 8 && v.data == 8);
    
    ret = atomic_store(&v, 20);
    assert(ret == 20 && v.data == 20);

    ret = atomic_exchange(&v, 15);
    assert(ret == 20 && v.data == 15);

    ret = atomic_compare_exchange(&v, 16, 12);
    assert(ret == 0 && v.data == 15);

    ret = atomic_compare_exchange(&v, 15, 12);
    assert(ret != 0 && v.data == 12);
    
    dprintf("Done!\n");
}

static void spin_test(void)
{
    spinlock_t locked = SPINLOCK_INIT_LOCKED;
    spinlock_t unlocked = SPINLOCK_INIT_UNLOCKED;
    
    dprintf("Test Spinlock_t Operations...\n");
    
    assert(!spin_try_lock(&locked));
    assert(spin_try_lock(&unlocked));
    assert(!spin_try_lock(&locked));
    assert(!spin_try_lock(&unlocked));
    
    spin_unlock(&locked);
    spin_unlock(&unlocked);
    assert(spin_try_lock(&locked));
    assert(spin_try_lock(&unlocked));
    
    spin_unlock(&locked);
    spin_unlock(&unlocked);
    spin_lock(&locked);
    spin_lock(&unlocked);
    assert(!spin_try_lock(&locked));
    assert(!spin_try_lock(&unlocked));
    
    dprintf("Done!\n");
}

void run_self_test(void)
{
    atomic_test();
    spin_test();
}

#endif // CONFIG_DEBUG
