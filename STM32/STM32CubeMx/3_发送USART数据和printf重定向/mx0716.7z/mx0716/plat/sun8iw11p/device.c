#include <config.h>

#include <tools/macros.h>

#include <allocate.h> //红黑树

#include <plat/device.h>
#include <init/relocate.h>

#define KB *1024
#define MB *1024 KB

// from datasheet:
// awk '{ print "{.pbase = 0x" $1 ", .vbase = 0x" $1 ", .size = " $3 " " $4 "}, // " $5 " " $6}'
// sed -i 's/_//'
// awk '{print "#define DEVICE_PBASE_" $3 " 0x" $1 " // " $4 " " $5}'

//   for all the regions defined below, if vbase is 0, the kernel
// will not map it to the adddress space.

// make sure the base of memory region and the size is aligned to 1MB
const region_t SHARED_RO ksram[] = {
    {.pbase = CONFIG_LOAD_ADDR, .vbase = CONFIG_EXEC_ADDR, .size = 128 MB},
    {.size = 0}, // end of regions
};

const region_t SHARED_RO ksdev[] = {
    // UART port
    {.pbase = DEVICE_PBASE_CCU, .vbase = DEVICE_VBASE_CCU, .size = DEVICE_SIZE_CCU_AND_TIMER},
    {.pbase = DEVICE_PBASE_UART, .vbase = DEVICE_VBASE_UART, .size = DEVICE_SIZE_UART},
    {.pbase = DEVICE_PBASE_GIC, .vbase = DEVICE_VBASE_GIC, .size = DEVICE_SIZE_GIC},
    // ARM MP
    //{.pbase = DEVICE_PBASE_ARMMP, .vbase = DEVICE_VBASE_ARMMP, .size = DEVICE_SIZE_ARMMP},
    // PL310 (L2 cache controller)
    //{.pbase = DEVICE_PBASE_L2C310, .vbase = DEVICE_VBASE_L2C310, .size = DEVICE_SIZE_L2C310},
    // System Reset Controller
    //{.pbase = DEVICE_PBASE_SRC, .vbase = DEVICE_VBASE_SRC, .size = DEVICE_SIZE_SRC},

    // {.pbase = 0x00940000, .vbase = 0x00940000, .size = 768 KB}, // OCRAM aliased
    // {.pbase = 0x00900000, .vbase = 0x00900000, .size = 256 KB}, // OCRAM 256KB

    // {.pbase = 0x00104000, .vbase = 0x00104000, .size = 48 KB}, // Reserved
    // {.pbase = 0x00100000, .vbase = 0x00100000, .size = 16 KB}, // CAAM (16K secure RAM)
    // {.pbase = 0x00018000, .vbase = 0x00018000, .size = 928 KB}, // Reserved
    // {.pbase = 0x00000000, .vbase = 0x00000000, .size = 96 KB}, // Boot ROM

    {.size = 0}, // end of regions
};

const region_t SHARED_RO usram[] = {
    {// this region belong to the kernel but is used to store the rootserver
     .pbase = (unsigned long)&rs_ro_start - CONFIG_EXEC_ADDR + CONFIG_LOAD_ADDR,
     .vbase = CONFIG_ROOTSERVER_EXEC_ADDR,
     .size = (unsigned long)&rs_ro_size},
    {// this region is for rootserver and make it map to the end of the rootserver,
     // thus the rootserver could access its data in bss segement without do any other
     // jobs.
     .pbase = 0x58000000,
     .vbase = CONFIG_ROOTSERVER_EXEC_ADDR + (unsigned long)&rs_ro_size,
     .size = 8 MB},
    {// dma region
     .pbase = 0x60000000,
     .vbase = 0x60000000,
     .size = 4 MB},
    // {// elf text data
    //  //  .pbase = 0x59000000,
    //  //  .vbase = 0x41000000,
    //  .pbase = 0x59000000,
    //  .vbase = 0x40f00000,
    //  .size = 12 MB},
    {.size = 0}, // end of regions
};
const region_t SHARED_RO usshmram[] = {
    {// share memory region
     .pbase = 0x60000000 + 3 MB,
     .vbase = 0x60000000 + 3 MB,
     .size = 5 MB},
    {.size = 0}, // end of regions
};

const region_t SHARED_RO usdev[] = {
    {.pbase = DEVICE_PBASE_UART, .vbase = CONFIG_ROOTSERVER_IOPORT_ADDR, .size = DEVICE_SIZE_UART},
    {.pbase = DEVICE_PBASE_SMHC, .vbase = CONFIG_ROOTSERVER_SMHC, .size = DEVICE_SIZE_SMHC},
    {.pbase = DEVICE_PBASE_CCU, .vbase = CONFIG_ROOTSERVER_TIMER, .size = DEVICE_SIZE_CCU_AND_TIMER},
    {.pbase = DEVICE_PBASE_EMAC, .vbase = CONFIG_ROOTSERVER_EMAC, .size = DEVICE_SIZE_EMAC},
    {.pbase = DEVICE_PBASE_SYSCRL, .vbase = CONFIG_ROOTSERVER_SYSCRL, .size = DEVICE_SIZE_SYSCRL},
    {.pbase = DEVICE_PBASE_DMA, .vbase = CONFIG_ROOTSERVER_DMA, .size = DEVICE_SIZE_DMA},
    {.pbase = 0x02000000, .vbase = 0, .size = 1 MB},   // AIPS-1
    {.pbase = 0x02100000, .vbase = 0, .size = 1 MB},   // AIPS-2
    {.pbase = 0x02200000, .vbase = 0, .size = 16 KB},  // SATA
    {.pbase = 0x02204000, .vbase = 0, .size = 16 KB},  // OpenVG
    {.pbase = 0x02208000, .vbase = 0, .size = 16 KB},  // HSI
    {.pbase = 0x0220C000, .vbase = 0, .size = 2 MB},   // Reserved
    {.pbase = 0x02400000, .vbase = 0, .size = 4 MB},   // IPU-1
    {.pbase = 0x02800000, .vbase = 0, .size = 4 MB},   // IPU-2
    {.pbase = 0x02C00000, .vbase = 0, .size = 84 MB},  // Reserved
    {.pbase = 0x08000000, .vbase = 0, .size = 128 MB}, // EIM-CS0

    {.pbase = 0x01FFC000, .vbase = 0, .size = 16 KB},    // PCIe registers
    {.pbase = 0x01000000, .vbase = 0, .size = 16368 KB}, // PCIe
    // {.pbase = 0x00D00000, .vbase = 0x00D00000, .size = 3072 KB}, // Reserved
    {.pbase = 0x00C00000, .vbase = 0, .size = 1 MB}, // GPV_1 PL301
    {.pbase = 0x00B00000, .vbase = 0, .size = 1 MB}, // GPV_0 PL301
    // {.pbase = 0x00A03000, .vbase = 0x00A03000, .size = 1012 KB}, // Reserved

    {.pbase = 0x00800000, .vbase = 0, .size = 1 MB}, // GPV_4 PL301
    {.pbase = 0x00400000, .vbase = 0, .size = 4 MB}, // Reserved
    {.pbase = 0x00300000, .vbase = 0, .size = 1 MB}, // GPV_3 PL301
    {.pbase = 0x00200000, .vbase = 0, .size = 1 MB}, // GPV_2 PL301
    // {.pbase = 0x0013C000, .vbase = 0x0013C000, .size = 784 KB}, // Reserved
    {.pbase = 0x00138000, .vbase = 0, .size = 16 KB}, // DTCP
    {.pbase = 0x00134000, .vbase = 0, .size = 16 KB}, // GPU 2D(GC 320)
    {.pbase = 0x00130000, .vbase = 0, .size = 16 KB}, // GPU 3D
    // {.pbase = 0x00129000, .vbase = 0x00129000, .size = 28 KB}, // Reserved
    {.pbase = 0x00120000, .vbase = 0, .size = 36 KB}, // HDMI
    // {.pbase = 0x00118000, .vbase = 0x00118000, .size = 32 KB}, // Reserved
    {.pbase = 0x00114000, .vbase = 0, .size = 16 KB}, // BCH
    {.pbase = 0x00112000, .vbase = 0, .size = 8 KB},  // GPMI
    {.pbase = 0x00110000, .vbase = 0, .size = 8 KB},  // APBH-Bridge-DMA

    {.size = 0}, // end of regions
};
