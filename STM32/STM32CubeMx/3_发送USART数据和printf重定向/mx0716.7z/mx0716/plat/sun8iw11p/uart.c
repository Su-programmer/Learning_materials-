/*************************************************************
*        Simple UART Driver for IMX6Q-SabreSD Board
************************************************************/
#include <tools/macros.h>

#include <plat/device.h>
#include <plat/uart.h>

#if 0
#define UART_BAUD (115200)
// UART Line Control Parameter
#define   PARITY       0           // Parity: 0,2 - no parity; 1 - odd parity; 3 - even parity
#define   STOP         0           // Number of Stop Bit: 0 - 1bit; 1 - 2(or 1.5)bits
#define   DLEN         3           // Data Length: 0 - 5bits; 1 - 6bits; 2 - 7bits; 3 - 8bits
#endif

typedef struct serial_hw
{
	volatile unsigned int rbr;		/* 0 */
	volatile unsigned int ier;		/* 1 */
	volatile unsigned int fcr;		/* 2 */
	volatile unsigned int lcr;		/* 3 */
	volatile unsigned int mcr;		/* 4 */
	volatile unsigned int lsr;		/* 5 */
	volatile unsigned int msr;		/* 6 */
	volatile unsigned int sch;		/* 7 */
}serial_hw_t;

static serial_hw_t *serial_ctrl_base = (serial_hw_t *)(DEVICE_VBASE_UART);

void uart_init(unsigned int clk)
{
    // todo;
}

void uart_putchar(char c)
{
	while((serial_ctrl_base->lsr & ( 1 << 6 )) == 0);
		serial_ctrl_base->rbr = c;
}


char uart_getchar (void)
{
	while((serial_ctrl_base->lsr & 1) == 0);
		return serial_ctrl_base->rbr;
}


#if 0
void ioport_init(void)
{
	unsigned int  uart_clk;
		
	dprintf("*****************\n");
	dprintf("ier = %x\n", serial_ctrl_base->ier);
	dprintf("fcr = %x\n", serial_ctrl_base->fcr);
	dprintf("lcr = %x\n", serial_ctrl_base->lcr);
	dprintf("mcr = %x\n", serial_ctrl_base->mcr);
	dprintf("lsr = %x\n", serial_ctrl_base->lsr);
	dprintf("msr = %x\n", serial_ctrl_base->msr);
	dprintf("sch = %x\n", serial_ctrl_base->sch);	

	serial_ctrl_base->mcr = 0x3;
	uart_clk = (24000000 + 8 * UART_BAUD)/(16 * UART_BAUD);
	serial_ctrl_base->lcr |= 0x80;
	serial_ctrl_base->ier = uart_clk>>8;   //dlh
	serial_ctrl_base->rbr = uart_clk&0xff; //dll
//	serial_ctrl_base->fcr = 0xc6;	       //iir
	serial_ctrl_base->lcr &= ~0x80;
	serial_ctrl_base->lcr = ((PARITY&0x03)<<3) | ((STOP&0x01)<<2) | (DLEN&0x03);
	serial_ctrl_base->ier = 0x8f;

	dprintf("%c \n", uart_getchar());

	dprintf("ier = %x\n", serial_ctrl_base->ier);
	dprintf("fcr = %x\n", serial_ctrl_base->fcr);
	dprintf("lcr = %x\n", serial_ctrl_base->lcr);
	dprintf("mcr = %x\n", serial_ctrl_base->mcr);
	dprintf("lsr = %x\n", serial_ctrl_base->lsr);
	dprintf("msr = %x\n", serial_ctrl_base->msr);
	dprintf("sch = %x\n", serial_ctrl_base->sch);
}
#endif

