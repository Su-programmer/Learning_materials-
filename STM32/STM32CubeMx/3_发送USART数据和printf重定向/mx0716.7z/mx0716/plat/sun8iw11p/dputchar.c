#include <config.h>
#include <plat/dputchar.h>

#include <plat/clock.h>
#include <plat/uart.h>

void dputchar_init(void)
{
    // todo:
}

void dputchar(char c)
{
#ifdef CONFIG_ENABLE_DPRINTF
    uart_putchar(c);
#endif
}
