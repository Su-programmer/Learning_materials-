#include <config.h>

#include <stdlib/ks_stdint.h>

#include <dprintf.h>
#include <halt.h>
#include <allocate.h>
#include <smp.h>

#include <cortex-a7/cpu.h>
#include <cortex-a7/scu.h>

#include <plat/src.h>

void src_enable_secondary_cpu(void)
{
#if 0
#ifdef CONFIG_ENABLE_SMP
    extern int _start;
    unsigned int i;
    unsigned int initialcores = smp_current_cores();
    uint32_t entry = allocator_pbase((uint32_t)&_start);

    dprintf("Setup entrys for secondary cores to 0x%x!\n", entry);
    PERSISTENT_ENTRY1_REG = entry;
    PERSISTENT_ENTRY2_REG = entry;
    PERSISTENT_ENTRY3_REG = entry;
    
    dprintf("Clean SRC Error Status!\n");
    SRC_GPR10_REG = 0;

    for(i = 1; i < CONFIG_SMP_CORES; i++)
    {
        dprintf("Bring up core #%d!\n", i);
        SRC_SCR_REG |= bitmask(SRC_SCR_REG_BIT_CORE1_ENABLE + i - 1);

        while(smp_current_cores() != (initialcores + i))
        {
            if(SRC_GPR10_REG != 0)
            {
                dprintf("Failed to bring up core #%d!\n", i);
                halt();
            }
        }
    }

    dprintf("Secondary cores enabled!\n");
    dprintf("Clean all entrys for secondary cores!\n");
    PERSISTENT_ENTRY1_REG = 0;
    PERSISTENT_ENTRY2_REG = 0;
    PERSISTENT_ENTRY3_REG = 0;

    scu_dump_info();
#endif
#endif
}
