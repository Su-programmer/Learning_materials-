#include <plat/src.h>

#include <armv7-a/scr.h>
#include <cortex-a7/scu.h>
#include <cortex-a7/cpu.h>
#include <drivers/l2c310_r3p1.h>
#include <drivers/gic_v2.h>

void platform_init(void)
{
    // initialize other controllers
//    l2c310_init(16, 64 * 1024, 4);
    //gicd_init();
}

void platform_bring_up_secondary_cores(void)
{
    src_enable_secondary_cpu();
}
