#include <config.h>

#include <timer.h>
#include <schedule.h>

#include <arch/systick.h>

#ifdef DEBUG_DOT_PER_10_INT
#include <plat/dputchar.h>

static int dotcount = 0;
#endif

time_t boottime = 0xFFA00000;
static unsigned int countdown = 0;

void timer_handler(void)
{
#ifdef DEBUG_DOT_PER_10_INT
    if(++dotcount == 10)
        dputchar('.'), dotcount = 0;
#endif

    boottime += countdown;
	/*清除中断标志*/
    systick_ack_int();
    
    schedule_wakeup(boottime);
    schedule();
}

/*激活时钟，us代表每一次时钟中断周期*/
void timer_next(unsigned int us)
{
    unsigned int left = systick_set_next(us);
    /*更改时钟周期时，减去现在时钟计数寄存器中还剩下的时间，这样计算时间更精确*/
    boottime += countdown - left;
    countdown = us;
}

