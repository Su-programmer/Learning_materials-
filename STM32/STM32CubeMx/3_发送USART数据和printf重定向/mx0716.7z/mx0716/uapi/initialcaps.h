#ifndef UAPI_INITIALCAPS_H
#define UAPI_INITIALCAPS_H

enum _intialcaps_index{
    // internal use for reference count and spinlock
    CAP_INDEX_AUDIT = 0,
    CAP_INDEX_FAULTHANDLER,
    
    CAP_INDEX_THREAD,
    CAP_INDEX_ADDRSPACE,
    
    // only for root server
    CAP_INDEX_IRQ_CONTROL,
    CAP_INDEX_RAM_KERNEL,
    CAP_INDEX_RAM_ROOTSERVER,
    CAP_INDEX_COUNT,
};

#endif
