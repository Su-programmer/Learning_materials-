#ifndef UAPI_IPCOPS_H
#define UAPI_IPCOPS_H

// basic format:
//   cptr, msgtag(msglen + id/op + extrainfo) + parameters
enum _cap_ntfn_operation
{
    CAP_NTFN_OP_WAIT,
    CAP_NTFN_OP_SIGNAL,
    CAP_NTFN_OP_CANCEL
};

enum _cap_ep_operation
{
    CAP_EP_OP_SEND, // parameter: messages
    CAP_EP_OP_RECV,
    CAP_EP_OP_CALL,
    CAP_EP_OP_REPLY,
    CAP_EP_OP_REPLY_WAIT,
    CAP_EP_OP_CANCEL, // parameters: none
    CAP_EP_OP_BIND,   // parameters: none
    CAP_EP_OP_UNBIND, // parameters: none
};

enum _cap_irq_operation
{
    CAP_IRQ_OP_GET,
    CAP_IRQ_OP_PUT,
    CAP_IRQ_OP_WAIT,
    CAP_IRQ_OP_ACK,
    CAP_IRQ_OP_ACK_WAIT
};

enum _cap_ram_operation
{
    CAP_RAM_MKCAP, // parameter: blockaddr, captype, targetslot
    CAP_RAM_FREE,  // parameter: blockaddr, captype
    CAP_RAM_MAP,   // parameters: pbase, size, addrspace, vbase, attr
    CAP_RAM_UNMAP,
};

enum _cap_addrspace_operation
{
    CAP_ADDRS_INIT,
    CAP_ADDRS_COPY,
    CAP_ADDRS_MAP,
    CAP_ADDRS_UNMAP
};

enum _cap_task_operation
{
    CAP_THREAD_CONFIG, // paramters: entry, ipcbuffer, stack, stacklen, args[0-n]
    CAP_THREAD_CLONE,  // parameters: source cap(0 stand for current task), id
};

enum _cap_mutex_operation
{
    CAP_MUTEX_OP_LOCK,
    CAP_MUTEX_OP_UNLOCK,
    CAP_MUTEX_OP_TRYLOCK
};

#endif
