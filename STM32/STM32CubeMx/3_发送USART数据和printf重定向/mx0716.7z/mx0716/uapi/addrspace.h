#ifndef UAPI_ADDRSPACE_H
#define UAPI_ADDRSPACE_H

enum __MAP_ATTRS{
    // Access Permissions
    // Kernel RW/RO, User No Access/RO/RW
    MAP_AP_KRW_UNA = 0x0,
    MAP_AP_KRW_URO = 0x1,
    MAP_AP_KRW_URW = 0x2,
    MAP_AP_KRO_UNA = 0x3,
    MAP_AP_KRO_URO = 0x4,
    MAP_AP_COUNT,
    MAP_AP_MASK = 0x0000f,

    // Type
    MAP_TYPE_MASK = 0x000f0,
    MAP_TYPE_DEVICE = 0x10,
    MAP_TYPE_RAM = 0x20,

    // Extra Attribute, Mask: 0xff00
    MAP_FLAG_NONE = 0x0000,
    MAP_FLAG_EXECUTABLE = 0x0100,
    MAP_FLAG_CACHEABLE = 0x0200,
    MAP_FLAG_SHAREABLE = 0x0400,
    MAP_FLAG_GLOBAL = 0x0800,

    // Page Table Level
    MAP_PTL_MASK = 0xf0000,
    MAP_PTL_PAGES = 0x00000,
    MAP_PTL_L1 = 0x10000,
    MAP_PTL_L2 = 0x20000,
    MAP_PTL_L3 = 0x30000,
    MAP_PTL_L4 = 0x40000,
};

static inline unsigned int map_mk_attr(unsigned level, unsigned type, unsigned ap, unsigned flag)
{
    return level | type | ap | flag;
}

#endif
