#ifndef IPC_BUFFER_H
#define IPC_BUFFER_H

#include <config.h>

#include <uapi/bootinfo.h>
#include <uapi/fault.h>

#define IPC_MAX_MSGWORDS (128 - 2)

typedef union _ipcbuffer
{
    bootinfo_t bi;
    
    struct _msgs
    {
        // identify which capability this operation should be applied to
        unsigned long cptr;
        
        // bitfileds of tag: msglen(8 bits) + info(id/op)(16 bits) + extra(8 bits)
        //   msglen: the amount of valid message words in current message, cptr & tag do NOT counted
        //   info(id/op): the operation code or one kind of ID
        //   extra: currently if extra > 0, the operation is non-blocked(todo)
        // example:(a valid message maybe)
        //   cptr: 0xffffff00
        //   msglen: 2
        //   id/op: 0x7
        //   extra: 0
        //   msgs: 0x01234567, 0x89abcdef
        unsigned long tag;
        
        // valid message words
        // the first 2 words of msgs will be transferred through registers
        unsigned long msgs[IPC_MAX_MSGWORDS];
        
        // used to save some context when fault reporting
        fault_backup_t backup;
    }msgs;
}ipcbuffer_t;

static inline unsigned long msgtag_get_len(unsigned long tag)
{
    return (tag >> 16) & 0xff;
}

static inline unsigned long msgtag_get_info(unsigned long tag)
{
    return  tag & 0xffff;
}

static inline unsigned long msgtag_set_info(unsigned long tag, unsigned short info)
{
    tag &= ~(0xffff);
    tag |= info;
    
    return tag;
}

#define msgtag_get_op(tag) msgtag_get_info(tag)
#define msgtag_get_id(tag) msgtag_get_info(tag)
#define msgtag_set_op(tag, op) msgtag_set_info(tag, op)
#define msgtag_set_id(tag, op) msgtag_set_info(tag, op)

static inline unsigned long msgtag_get_extra(unsigned long tag)
{
    return  (tag >> 24) & 0xff;
}

static inline unsigned long msgtag_set_extra(unsigned long tag, unsigned char extra)
{
    tag &= ~(0xff000000);
    tag |= extra << 24;
    
    return tag;
}

static inline unsigned long msgtag_make(unsigned char len, unsigned short id_op, unsigned char extra)
{
    return (extra << 24) | (len << 16) | id_op;
}

static inline unsigned long* ipcbuffer_get_msgs(ipcbuffer_t* buf)
{
    return buf->msgs.msgs;
}

static inline void ipcbuffer_set_msgs(ipcbuffer_t* buf, unsigned int index, unsigned long value)
{
    buf->msgs.msgs[index] = value;
}

static inline unsigned long ipcbuffer_get_cptr(ipcbuffer_t* buf)
{
    return buf->msgs.cptr;
}

static inline unsigned char ipcbuffer_get_msglen(ipcbuffer_t* buf)
{
    return msgtag_get_len(buf->msgs.tag);
}

static inline unsigned short ipcbuffer_get_id(ipcbuffer_t* buf)
{
    return msgtag_get_id(buf->msgs.tag);
}

static inline unsigned long ipcbuffer_get_tag(ipcbuffer_t* buf)
{
    return buf->msgs.tag;
}

static inline void ipcbuffer_set_cptr(ipcbuffer_t* buf, unsigned long cptr)
{
    buf->msgs.cptr = cptr;
}

static inline void ipcbuffer_set_tag(ipcbuffer_t* buf, unsigned char msglen, unsigned short info, unsigned char extra)
{
    buf->msgs.tag = msgtag_make(msglen, info, extra);
}

static inline void ipcbuffer_save(ipcbuffer_t* buf, unsigned long tag, unsigned long m0, unsigned long m1)
{
    buf->msgs.tag = tag;
    buf->msgs.msgs[0] = m0;
    buf->msgs.msgs[1] = m1;
}

// interfaces for kernel ONLY, all (void*) stand for (tcb_t*)
void ipcbuffer_partial_transfer(void* dst, void* src, unsigned long tag);
void ipcbuffer_regs_transfer(void* dst, unsigned long tag, unsigned long m0, unsigned long m1);
void ipcbuffer_full_transfer(void* dst, void* src);

#endif
