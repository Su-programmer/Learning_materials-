#ifndef UAPI_FAULT_H
#define UAPI_FAULT_H

enum _fault_type{
    FAULT_INS, FAULT_DATA, FAULT_FPU,
    FAULT_CHILD_EXIT, FAULT_UNRECOVERY
};

typedef struct __fault_backup{
    unsigned long retcode;
    unsigned long cptr;
    unsigned long tag;
    unsigned long msgs[3];
}fault_backup_t;

// message format of fault report:
//   tag::id_op: fault type
//   msgs[0]: hardware fault status 0
//   msgs[1]: hardware fault status 1
//   msgs[2]: task id
// message format of fault response:
//   msgs[0]: error code

#endif
