#ifndef UAPI_BOOTINFO_H
#define UAPI_BOOTINFO_H

#include <uapi/caps/capability.h>

typedef struct _region
{
    unsigned long pbase;
    unsigned long vbase;
    unsigned int size;
    unsigned int directmap;
}region_t;

static inline void region_init(region_t *r, unsigned int pbase, unsigned int vbase, unsigned int size)
{
    r->pbase = pbase;
    r->vbase = vbase;
    r->size = size;
}

typedef struct _boot_info
{
    void* ipcbuffer;
    unsigned int ipcbufferlen;
    
    void* stack;
    unsigned int stacklen;
    
    unsigned int guardlen;
    unsigned int guard;
    unsigned int radix;
    unsigned int freeindex;
    capability_t *cspace;
    
    const unsigned int *caps_size;
}bootinfo_t;

#endif
