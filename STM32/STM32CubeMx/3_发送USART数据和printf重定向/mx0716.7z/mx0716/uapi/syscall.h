#ifndef UAPI_SYSCALL_H
#define UAPI_SYSCALL_H

enum _syscall_number
{
    SYS_exit = 0,
    SYS_nanosleep,
    SYS_yield,
    SYS_usleep,
    SYS_test_prepare,
    SYS_test,
    SYS_test_end,
    SYS_cache_op,
    SYS_COUNT,
};

#endif
