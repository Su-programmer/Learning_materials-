#ifndef UAPI_CAPS_CAPABILITY_H
#define UAPI_CAPS_CAPABILITY_H

#include <tools/macros.h>

#define CAP_TYPE_BITS (4)

enum _capability_type
{
    CAP_EMPTY = 0,
    CAP_CNODE,
    CAP_NTFN,
    CAP_EP,
    CAP_IRQ_CONTROL,
    CAP_IRQ_HANDLER,
    CAP_THREAD,
    CAP_RAM,
    CAP_ADDRSPACE,
    CAP_AUDIT,

    // todo: maybe we should reserved some capability types for architecture specified functions
    CAP_ARMSMC, // Only for ARM platform, Secure Monitor Call
    CAP_MUTEX,  //mutex
    CAP_COUNT,

    // todo: allocate memory block from kernel device, these are not kernel block
    KOBJECT_AS_PUD,
    KOBJECT_AS_PMD,
    KOBJECT_AS_PT,
    KOBJECT_IPCBUFFER
};

typedef struct __capability
{
    // this filed can be fully used to keep capability specified infomation
    unsigned long w;

    // this filed can be used to keep capability specified infomation EXCEPT the low CAP_TYPE_BITS
    unsigned long ww; // todo: rename to pw(partial word)

    unsigned long cap_ext;

    // reuse next as reference count, and parent as spinlock
    // do NOT changed the position of this 2 pointer:
    struct __capability *next;
    struct __capability *parent;
} capability_t;

static inline unsigned long cap_get_type(const capability_t *cap)
{
    return cap->ww & lowbitsmask(CAP_TYPE_BITS);
}

static inline unsigned long cap_get_long_info(const capability_t *cap)
{
    return cap->w;
}

static inline unsigned long cap_get_short_info(const capability_t *cap)
{
    return cap->ww >> CAP_TYPE_BITS;
}

static inline int cap_is_empty(const capability_t *cap)
{
    return cap_get_type(cap) == CAP_EMPTY;
}

#endif
