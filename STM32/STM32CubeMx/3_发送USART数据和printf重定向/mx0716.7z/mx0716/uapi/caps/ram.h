#ifndef UAPI_CAPS_RAM_H
#define UAPI_CAPS_RAM_H

#include <config.h>
#include <tools/macros.h>
#include <uapi/bootinfo.h>
#include <uapi/caps/capability.h>

enum _cap_ram_type{
    CAP_RAM_KERNEL, CAP_RAM_NORMAL, CAP_RAM_DEVICE, CAP_RAM_SHM
};

#define CAP_RAM_ATTR_BIT_D (0)

static inline unsigned int cap_ram_get_type(const capability_t *cap)
{
    return cap_get_short_info(cap);
}

static inline unsigned long cap_ram_get_desc(const capability_t *cap)
{
    return cap_get_long_info(cap) & (~1ul);
}

static inline int cap_ram_is_direct_map_only(const capability_t *cap)
{
    return cap_get_long_info(cap) & (1ul << CAP_RAM_ATTR_BIT_D);
}

static inline unsigned long cap_ram_get_size(const capability_t *cap)
{
    const region_t *desc = (region_t*)cap_ram_get_desc(cap);

    if(cap_ram_get_type(cap) == CAP_RAM_KERNEL)
        return 0;
    else
        return desc->size;
}

static inline unsigned long cap_ram_get_vbase(const capability_t *cap)
{
    const region_t *desc = (region_t*)cap_ram_get_desc(cap);

    if(cap_ram_get_type(cap) == CAP_RAM_KERNEL)
        return 0;
    else
        return desc->vbase;
}

static inline unsigned long cap_ram_get_pbase(const capability_t *cap)
{
    const region_t *desc = (region_t*)cap_ram_get_desc(cap);
    
    if(cap_ram_get_type(cap) == CAP_RAM_KERNEL)
        return 0;
    else
        return desc->pbase;
}

#endif
