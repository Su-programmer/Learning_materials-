#include <tools/macros.h>
#include <tools/list.h>

#include <mutex.h>
#include <task.h>
#include <schedule.h>

#include <uapi/errors.h>
#include <uapi/ipcbuffer.h>

#include <arch/context.h>


//˵��
//����mutex.c mutex.h caps/mutex.c caps/mutex.h 
//�޸�ram.c capability.c ipcops.h capability.h errors.h
//rootserver��ֻ�� rootserver/mutex.c rootserver/mutex.h

#include <dprintf.h>


void mutex_init(mutex_t *mutex)
{
	atomic_store(&mutex->lock,1);
	list_init(&mutex->wait_list);
	mutex->owner = (void *)0;
	mutex_get(mutex);
}

void mutex_lock(mutex_t *mutex)
{
		if(atomic_compare_exchange(&mutex->lock,1,0)!=0){
			mutex->owner = current();
		}
		else{	
			tcb_get(current());
			schedule_detach(current());
			task_set_state(current(), TASK_BLOCKED);
			list_append(&mutex->wait_list,&current()->runlist);
		}
}

void mutex_unlock(mutex_t *mutex)
{
	if(mutex->owner != current()){
		dprintf("this mutex is not own to the current thread\r\n");
		return;
	}
	tcb_t *wakeup = (void *)0;
	if(atomic_compare_exchange(&mutex->lock,0,1)!=0){
		if(!list_is_empty(&mutex->wait_list)){
			atomic_compare_exchange(&mutex->lock,1,0);
			wakeup = container_of(mutex->wait_list.next,tcb_t,runlist);
			list_remove(&wakeup->runlist);
			task_set_state(wakeup, TASK_READY);
			if(0==tcb_put(wakeup)){
				mutex->owner = (void *)0;
				return;
			}
			mutex->owner = wakeup;
			schedule_attach(wakeup);
		}
		else{
			mutex->owner = (void *)0;
		}
	}
	else{
		dprintf("unlock an unlocked mutex\r\n");
	}
}

int mutex_trylock(mutex_t *mutex)
{
		if(atomic_compare_exchange(&mutex->lock,1,0)!=0){
			mutex->owner = current();
			return ESUCCESS;
		}
		else{	
		    dprintf("lock an locked mutex\r\n");
			return -EMUTEXLOCKED;
		}

}
