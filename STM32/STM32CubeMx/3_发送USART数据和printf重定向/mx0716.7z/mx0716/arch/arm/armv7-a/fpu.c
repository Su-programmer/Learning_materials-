#include <dprintf.h>
#include <armv7-a/fpu.h>

void raise(void)
{
    // todo
    dprintf("raise called!\n");
}
