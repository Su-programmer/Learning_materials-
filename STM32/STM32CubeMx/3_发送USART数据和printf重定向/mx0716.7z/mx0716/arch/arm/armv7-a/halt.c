/*********************************************************
*
*********************************************************/
#include <dprintf.h>
#include <halt.h>

void halt(void)
{
    unsigned int mask = 1;
    
    dprintf("oops: system will be halt permanently!\n");
    
    // todo:
    while(1);
    
    // add this to avoid warning
    mask = mask;
}
