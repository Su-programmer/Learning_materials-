#include <stdlib/ks_stdint.h>

#include <tools/macros.h>

#include <arch/scr.h>

int scr_get_cache_info(unsigned int level, unsigned int InD, int* sets, int* ways, int* linesize)
{
    uint32_t value;
    unsigned int linesizeshift;

    if(level > SCR_CLIDR_BIT_CTYPE_COUNT || level <= 0 || InD > 1)
        return -1;

    value = ((level - 1) << SCR_CSSELR_BIT_LEVEL) | (InD << SCR_CSSELR_BIT_InD);
	
    scr_write_CSSELR(value);

	//__asm__ __volatile__("mrc p15, 1, %0, c0, c0, 0\n":"=r" (value):);
    value = scr_read_CCSIDR();

    *sets = (value >> SCR_CCSIDR_BIT_NumSets) & lowbitsmask(SCR_CCSIDR_BIT_NumSets_WIDTH);
    *sets += 1;
    *ways = (value >> SCR_CCSIDR_BIT_Associativity) & lowbitsmask(SCR_CCSIDR_BIT_Associativity_WIDTH);
    *ways += 1;
    linesizeshift = (value >> SCR_CCSIDR_BIT_LineSize) & lowbitsmask(SCR_CCSIDR_BIT_LineSize_WIDTH);
    linesizeshift += 2;
	
    *linesize = 1 << linesizeshift;

    return 0;
}

unsigned int scr_get_cache_type(unsigned int level)
{
    uint32_t value;
    unsigned int type = ~0;

    if(level <= SCR_CLIDR_BIT_CTYPE_COUNT && level > 0)
    {
        value = scr_read_CLIDR();
        value >>= (level - 1) * SCR_CLIDR_BIT_CTYPE_WIDTH;
        value &= lowbitsmask(SCR_CLIDR_BIT_CTYPE_WIDTH);
        type = value;
    }

    return type;
}


static inline void dump_cache_size(unsigned int level, unsigned int InD)
{
    int sets;
    int ways;
    int linesize;

    scr_get_cache_info(level, InD, &sets, &ways, &linesize);
    dprintf("  %d sets, %d ways, %d words per line.\n", sets, ways, linesize);
}

static void cache_dump_info(void)
{
    unsigned int level;
    unsigned int type;

    for(level = 1; level <= SCR_CLIDR_BIT_CTYPE_COUNT; level++)
    {
        type = scr_get_cache_type(level);
        if(type != SCR_CLIDR_CTYPE_NoCache)
            dprintf("L%d Cache:\n", level);

        switch(type)
        {
            case SCR_CLIDR_CTYPE_DCache:
            case SCR_CLIDR_CTYPE_UCache:
                dprintf(" Data or Unified Cache.\n");
                dump_cache_size(level, 0);
                break;

            case SCR_CLIDR_CTYPE_ICache:
                dprintf("  Instruction Cache.\n");
                dump_cache_size(level, 1);
                break;

            case SCR_CLIDR_CTYPE_SIDCache:
                dprintf("  Seperated Instruction Cache and Data Cache.\n");
                dprintf("  Instruction Cache:\n");
                dump_cache_size(level, 1);
                dprintf("  Data Cache:\n");
                dump_cache_size(level, 0);
                break;
                
            case SCR_CLIDR_CTYPE_NoCache:
                break;

            default:
                dprintf("  Unkonwn Cache Type!\n");
                level = SCR_CLIDR_BIT_CTYPE_COUNT;
                break;
        }
    }
}

// make sure the data cache exist
static void maintain_data_cache_level(void(*maintain_setway)(uint32_t), unsigned int level)
{
    int sets;
    int ways;
    int linesize;
    unsigned int waybegin;
    unsigned int setbegin;
    uint32_t value = 0;

    scr_get_cache_info(level, 0, &sets, &ways, &linesize);
    assert(sets > 0 && ways > 0 && linesize > 0);

    waybegin = 32 - ln2(ways);
    setbegin = ln2(linesize * sizeof(void*));

    while(ways-- > 0)
    {
        int j = sets;
        while(j-- > 0)
        {
            value = (ways << waybegin) | (j << setbegin) | (level << 1);
            maintain_setway(value);
        }
    }
}

static void maintain_data_cache_all(void(*maintain_setway)(uint32_t))
{
    unsigned int i;
    unsigned int ctype;

    // clean all data cache
    for(i = 1; i <= SCR_CLIDR_BIT_CTYPE_COUNT; i++)
    {
        ctype = scr_get_cache_type(i);
        switch(ctype)
        {
            case SCR_CLIDR_CTYPE_NoCache:
                // quit the loop right now
                i = SCR_CLIDR_BIT_CTYPE_COUNT;
                break;

            case SCR_CLIDR_CTYPE_DCache:
            case SCR_CLIDR_CTYPE_UCache:
            case SCR_CLIDR_CTYPE_SIDCache:
                maintain_data_cache_level(maintain_setway, i);
                break;
            
            default:
                break;
        }
    }
    dsb();
}

void scr_clean_data_cache(void)
{
    maintain_data_cache_all(scr_write_DCCSW);
}

void scr_clean_invalidate_data_cache(void)
{
    maintain_data_cache_all(scr_write_DCCISW);
}

void scr_invalidate_data_cache(void)
{
    maintain_data_cache_all(scr_write_DCISW);
}

void scr_enable_cpu_cache(void)
{
    uint32_t value = 0;

    scr_write_BPIALL(value);
    scr_write_ICIALLU(value);
    value = scr_read_SCTLR();
    value |= bitmask(SCR_SCTLR_BIT_Z) | bitmask(SCR_SCTLR_BIT_I) | bitmask(SCR_SCTLR_BIT_C);
    scr_write_SCTLR(value);
}

void scr_dump_info(void)
{
    uint32_t value;

    value = scr_read_SCR();
    dprintf(" Security State: %s\n", (value & bitmask(SCR_SCR_BIT_NS)) > 0 ? "Non-Secure" : "Secure");
    cache_dump_info();
}

unsigned long scr_translate_va(unsigned long va, int iskernel, int iswrite)
{
    if(iskernel != 0)
    {
        if(iswrite != 0)
            scr_write_ATS1CPW(va);
        else
            scr_write_ATS1CPR(va);
    }
    else
    {
        if(iswrite != 0)
            scr_write_ATS1CUW(va);
        else
            scr_write_ATS1CUR(va);
    }

    isb();
    return scr_read_PAR();
}

void scr_report_va_info(unsigned long va, int iskernel, int iswrite)
{
    unsigned long info = scr_translate_va(va, iskernel, iswrite);

    dprintf("Translatation result: 0x%x => 0x%x\n", va, info);
    if(info & bitmask(SCR_PAR_BIT_F))
    {
        dprintf("  Fault Status: 0x%x\n", 
            bitfield_get(info, SCR_PAR_BIT_FS, SCR_PAR_BIT_FS_WIDTH));
    }
    else
        dprintf("  Page Base Address: %x\n", info & ~lowbitsmask(SCR_PAR_BIT_PA));
}


//---------------------------------------------------------------
//cache operations
//---------------------------------------------------------------
#define ARMV7_DCACHE_INVAL_ALL			1
#define ARMV7_DCACHE_CLEAN_INVAL_ALL	2
#define ARMV7_DCACHE_INVAL_RANGE		3
#define ARMV7_DCACHE_CLEAN_INVAL_RANGE	4

#define CCSIDR_LINE_SIZE_OFFSET		0
#define CCSIDR_LINE_SIZE_MASK		0x7

#define CP15ISB	asm volatile ("mcr     p15, 0, %0, c7, c5, 4" : : "r" (0))
#define CP15DSB	asm volatile ("mcr     p15, 0, %0, c7, c10, 4" : : "r" (0))
#define CP15DMB	asm volatile ("mcr     p15, 0, %0, c7, c10, 5" : : "r" (0))

typedef struct pl310_regs {
	uint32_t pl310_cache_id;
	uint32_t pl310_cache_type;
	uint32_t pad1[62];
	uint32_t pl310_ctrl;
	uint32_t pl310_aux_ctrl;
	uint32_t pl310_tag_latency_ctrl;
	uint32_t pl310_data_latency_ctrl;
	uint32_t pad2[60];
	uint32_t pl310_event_cnt_ctrl;
	uint32_t pl310_event_cnt1_cfg;
	uint32_t pl310_event_cnt0_cfg;
	uint32_t pl310_event_cnt1_val;
	uint32_t pl310_event_cnt0_val;
	uint32_t pl310_intr_mask;
	uint32_t pl310_masked_intr_stat;
	uint32_t pl310_raw_intr_stat;
	uint32_t pl310_intr_clear;
	uint32_t pad3[323];
	uint32_t pl310_cache_sync;
	uint32_t pad4[15];
	uint32_t pl310_inv_line_pa;
	uint32_t pad5[2];
	uint32_t pl310_inv_way;
	uint32_t pad6[12];
	uint32_t pl310_clean_line_pa;
	uint32_t pad7[1];
	uint32_t pl310_clean_line_idx;
	uint32_t pl310_clean_way;
	uint32_t pad8[12];
	uint32_t pl310_clean_inv_line_pa;
	uint32_t pad9[1];
	uint32_t pl310_clean_inv_line_idx;
	uint32_t pl310_clean_inv_way;
	uint32_t pad10[64];
	uint32_t pl310_lockdown_dbase;
	uint32_t pl310_lockdown_ibase;
	uint32_t pad11[190];
	uint32_t pl310_addr_filter_start;
	uint32_t pl310_addr_filter_end;
	uint32_t pad12[190];
	uint32_t pl310_test_operation;
	uint32_t pad13[3];
	uint32_t pl310_line_data;
	uint32_t pad14[7];
	uint32_t pl310_line_tag;
	uint32_t pad15[3];
	uint32_t pl310_debug_ctrl;
	uint32_t pad16[7];
	uint32_t pl310_prefetch_ctrl;
	uint32_t pad17[7];
	uint32_t pl310_power_ctrl;
}pl310_regs_t;

struct pl310_regs *const pl310 = (struct pl310_regs *)0xfff06000;

/*
 * Write the level and type you want to Cache Size Selection Register(CSSELR)
 * to get size details from Current Cache Size ID Register(CCSIDR)
 */
void set_csselr(uint32_t level, uint32_t type)
{
	uint32_t csselr = level << 1 | type;
	/* Write to Cache Size Selection Register(CSSELR) */
	asm volatile ("mcr p15, 2, %0, c0, c0, 0" : : "r" (csselr));
}

static uint32_t get_ccsidr(void)
{
	uint32_t ccsidr;
	/* Read current CP15 Cache Size ID Register */
	asm volatile ("mrc p15, 1, %0, c0, c0, 0":"=r" (ccsidr):);
	return ccsidr;
}

uint32_t get_clidr(void)
{
	uint32_t clidr;
	/* Read current CP15 Cache Level ID Register */
	asm volatile ("mrc p15, 1, %0, c0, c0, 1" : "=r" (clidr));
	return clidr;
}

static void v7_dcache_clean_inval_range(uint32_t start, uint32_t stop, uint32_t line_len)
{
	uint32_t mva;

	/* Align start to cache line boundary */
	start &= ~(line_len - 1);
	for (mva = start; mva < stop; mva = mva + line_len) {
		/* DCCIMVAC - Clean & Invalidate data cache by MVA to PoC */
		asm volatile ("mcr p15, 0, %0, c7, c14, 1" : : "r" (mva));
	}
}

static void v7_dcache_inval_range(uint32_t start, uint32_t stop, uint32_t line_len)
{
	uint32_t mva;

	/*
	 * If start address is not aligned to cache-line do not
	 * invalidate the first cache-line
	 */
	if (start & (line_len - 1)) {
		dprintf("ERROR: %s - start address is not aligned - 0x%08x\n",
			__func__, start);
		/* move to next cache line */
		start = (start + line_len - 1) & ~(line_len - 1);
	}

	/*
	 * If stop address is not aligned to cache-line do not
	 * invalidate the last cache-line
	 */
	if (stop & (line_len - 1)) {
		dprintf("ERROR: %s - stop address is not aligned - 0x%08x\n",
			__func__, stop);
		/* align to the beginning of this cache line */
		stop &= ~(line_len - 1);
	}

	for (mva = start; mva < stop; mva = mva + line_len) {
		/* DCIMVAC - Invalidate data cache by MVA to PoC */
		asm volatile ("mcr p15, 0, %0, c7, c6, 1" : : "r" (mva));
	}
}


static void v7_dcache_maint_range(uint32_t start, uint32_t stop, uint32_t range_op)
{
	uint32_t line_len, ccsidr;
	
	ccsidr = get_ccsidr();//0x701fe019
	
	line_len = ((ccsidr & CCSIDR_LINE_SIZE_MASK) >>
			CCSIDR_LINE_SIZE_OFFSET) + 2;
	/* Converting from words to bytes */
	line_len += 2;
	/* converting from log2(linelen) to linelen */
	line_len = 1 << line_len; 		//32
	
	switch (range_op) {
	case ARMV7_DCACHE_CLEAN_INVAL_RANGE:
		v7_dcache_clean_inval_range(start, stop, line_len);
		break;
	case ARMV7_DCACHE_INVAL_RANGE:
		v7_dcache_inval_range(start, stop, line_len);
		break;
	}

	/* DSB to make sure the operation is complete */
	CP15DSB;
}

static void pl310_cache_sync(void)
{
	*(volatile unsigned long *)&pl310->pl310_cache_sync = 0;
}

/* Flush(clean invalidate) memory from start to stop-1 */
void v7_outer_cache_flush_range(uint32_t start, uint32_t stop)
{
	/* PL310 currently supports only 32 bytes cache line */
	uint32_t pa, line_size = 32;

	/*
	 * Align to the beginning of cache-line - this ensures that
	 * the first 5 bits are 0 as required by PL310 TRM
	 */
	start &= ~(line_size - 1);

	for (pa = start; pa < stop; pa = pa + line_size)
		*(volatile unsigned long *)&pl310->pl310_clean_inv_line_pa = pa;

	pl310_cache_sync();
}

/* invalidate memory from start to stop-1 */
void v7_outer_cache_inval_range(uint32_t start, uint32_t stop)
{
	/* PL310 currently supports only 32 bytes cache line */
	uint32_t pa, line_size = 32;

	/*
	 * If start address is not aligned to cache-line do not
	 * invalidate the first cache-line
	 */
	if (start & (line_size - 1)) {
		dprintf("ERROR: %s - start address is not aligned - 0x%08x\n",
			__func__, start);
		/* move to next cache line */
		start = (start + line_size - 1) & ~(line_size - 1);
	}

	/*
	 * If stop address is not aligned to cache-line do not
	 * invalidate the last cache-line
	 */
	if (stop & (line_size - 1)) {
		dprintf("ERROR: %s - stop address is not aligned - 0x%08x\n",
			__func__, stop);
		/* align to the beginning of this cache line */
		stop &= ~(line_size - 1);
	}

	for (pa = start; pa < stop; pa = pa + line_size)
		*(volatile unsigned long *)&pl310->pl310_inv_line_pa = pa;

	pl310_cache_sync();
}

/*
 * Flush range(clean & invalidate) from all levels of D-cache/unified
 * cache used:
 * Affects the range [start, stop - 1]
 */
void flush_dcache_range(unsigned long start, unsigned long stop)
{
	v7_dcache_maint_range(start, stop, ARMV7_DCACHE_CLEAN_INVAL_RANGE);

	v7_outer_cache_flush_range(start, stop);
}

void  __flush_cache(unsigned long start, unsigned long size)
{
	flush_dcache_range(start, start + size);
}

/*
 * Invalidates range in all levels of D-cache/unified cache used:
 * Affects the range [start, stop - 1]
 */
void invalidate_dcache_range(unsigned long start, unsigned long stop)
{
	v7_dcache_maint_range(start, stop, ARMV7_DCACHE_INVAL_RANGE);
	v7_outer_cache_inval_range(start, stop);
}


