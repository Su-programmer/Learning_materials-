#include <config.h>

#include <stdlib/ks_string.h>

#include <schedule.h>
#include <dprintf.h>
#include <task.h>

#include <arch/cpsr.h>
#include <armv7-a/context.h>
#include <armv7-a/scr.h>

void context_init(context_t* ctx, int type)
{
    // set all registers to default value
#ifdef DEBUG_DUMP_CONTEXT
    int i = 0;

    for(; i < REGS_COUNT; i++)
        ctx->regs[i] = i + 0xffff0000;
#else
    ks_memset(ctx, 0, sizeof(ctx));
#endif

    // update the mode for the task
    if(type == TTYPE_USER)
        ctx->regs[CPSR] = (MODE_User << CPSR_BIT_MODE);
    else
        ctx->regs[CPSR] = (MODE_System << CPSR_BIT_MODE);
}

void context_set_stack(context_t* ctx, void* stack, void* ipcbuffer, unsigned int size)
{
#ifdef DEBUG_DUMP_CONTEXT
    dprintf("CTX(0x%x): Stack = 0x%x, IPCBuffer = 0x%x, StackSize = %d\n", ctx, stack, ipcbuffer, size);
#endif

    ctx->regs[SP] = (uint32_t)stack + size;
    ctx->regs[TPIDRURO] = (uint32_t)ipcbuffer;
}

void context_set_retcode(context_t* ctx, int code)
{
    ctx->regs[R0] = code;
}

void context_set_reg_param(context_t *ctx, uint32_t p1, uint32_t p2, uint32_t p3)
{
    ctx->regs[R1] = p1;
    ctx->regs[R2] = p2;
    ctx->regs[R3] = p3;
}

void context_set_entry(context_t* ctx, unsigned int entry)
{
    ctx->regs[PC] = entry;
}

void context_switch_prepare(context_t *to, context_t *from)
{
    // todo
}

void context_enable_fpu(context_t *ctx)
{
    // todo
}


#ifdef DEBUG_DUMP_CONTEXT
static void context_dump(context_t *ctx)
{
    int i = 0;
    while(i < REGS_COUNT)
    {
        dprintf("R[%d] = 0x%x\n", i, ctx->regs[i]);
        i++;
    }
    dprintf("FPU: %d\n", ctx->enablefpu);
}
#endif

void context_restore_current(void)
{
    uint32_t* regs = task_get_context(current())->regs;

#ifdef DEBUG_DUMP_CONTEXT
    context_dump(task_get_context(current()));
#endif


    scr_write_TPIDRURO(regs[TPIDRURO]);

    __asm__ __volatile__(
        "mov sp, %0\n\t"
        "ldmdb sp, {r0-r14}^\n\t"
        "rfeia sp\n\t"
        :
        :"r"(&regs[PC])
    );
}

uint32_t* BOOTONLY current_context_sp(void)
{
    return &task_get_context(current())->regs[PC];
}
