#include <config.h>

#include <stdlib/ks_string.h>
#include <tools/macros.h>

#include <uapi/errors.h>
#include <uapi/addrspace.h>

#include <addrspace.h>

#include <armv7-a/scr.h>
#include <armv7-a/pagetable.h>

#include <plat/device.h>

#define L1PT_INDEX_BEGIN 20
#define L1PT_INDEX_WIDTH 12
#define L1PT_SIZE (L1PT_ENTRIES * 4)
#define L2PT_INDEX_BEGIN 12
#define L2PT_INDEX_WIDTH 8
#define L2PT_SIZE (L2PT_ENTRIES * 4)

#define SECTION_SIZE_SHIFT (20)
#define SECTION_SIZE (1 << SECTION_SIZE_SHIFT)
#define PAGE_SIZE_SHIFT (12)
#define PAGE_SIZE (1 << PAGE_SIZE_SHIFT)

const SHARED_RO pagetable_info_t pti[] = {
    [1] = {.indexbegin = L1PT_INDEX_BEGIN, .indexwidth = L1PT_INDEX_WIDTH, .size = L1PT_SIZE},
    [2] = {.indexbegin = L2PT_INDEX_BEGIN, .indexwidth = L2PT_INDEX_WIDTH, .size = L2PT_SIZE},
    [3] = {0, 0, 0},
    [4] = {0, 0, 0},
};

///
/// Bitfield Defination
///

enum __AP_VALUES
{
    AP_NA = 0x0, // No Access
    AP_PRW_UNA = 0x1,
    AP_PRW_URO = 0x2,
    AP_PRW_URW = 0x3,

    AP_PRO_UNA = 0x5,
    // AP_PRO_URO = 0x6, // deprecated from VMSAv7
    AP_PRO_URO = 0x7, // Introduced in VMSAv7
};

enum __L1D_BITS
{
    L1D_INVALID = 0x0,

    L1D_PT_FIXED = 0x01,
    L1D_PT_FIXED_MASK = 0x3,
    L1D_PT_BIT_PXN = 2,    // Privileged Execute-Never
    L1D_PT_BIT_NS = 3,     // Non-Secure, Apply to all the entrys in L2PT
    L1D_PT_BIT_DOMAIN = 5, // Apply to all the entrys in L2PT
    L1D_PT_BIT_DOMAIN_WIDTH = 4,
    L1D_PT_BIT_PA = 10,

    L1D_SEC_FIXED = 0x02,
    L1D_SEC_FIXED_MASK = 0x40002,
    L1D_SECs_BIT_PXN = 0, // Sections and SuperSections Descriptors has the same bitfield
    L1D_SECs_BIT_B = 2,   // Bufferable
    L1D_SECs_BIT_C = 3,   // Cachable
    L1D_SECs_BIT_XN = 4,  // Execute-Never
    L1D_SEC_BIT_DOMAIN = 5,
    L1D_SEC_BIT_DOMAIN_WIDTH = 4,
    L1D_SECs_BIT_AP0 = 10, // Access Permission
    L1D_SECs_BIT_AP1 = 11,
    L1D_SECs_BIT_TEX = 12,
    L1D_SECs_BIT_TEX_WIDTH = 3,
    L1D_SECs_BIT_AP2 = 15,
    L1D_SECs_BIT_S = 16,
    L1D_SECs_BIT_nG = 17,
    L1D_SECs_BIT_NS = 19,
    L1D_SEC_BIT_PA = 20,

    // domain is 0 always for SuperSetion
    L1D_SSEC_FIXED = 0x40002,
    L1D_SSEC_FIXED_MASK = 0x40002,
    L1D_SSEC_BIT_PA = 24,
};

enum __L2D_BITS
{
    L2D_INVALID = 0x0,

    // for large page
    L2D_LP_FIXED = 0x1,
    L2D_LP_FIXED_MASK = 0x3,

    L2D_LP_BIT_B = 2,
    L2D_LP_BIT_C = 3,
    L2D_LP_BIT_AP0 = 4,
    L2D_LP_BIT_AP1 = 5,
    L2D_LP_BIT_AP2 = 9,
    L2D_LP_BIT_S = 10, // Shareable
    L2D_LP_BIT_nG = 11,
    L2D_LP_BIT_TEX = 12,
    L2D_LP_BIT_TEX_WIDTH = 3,
    L2D_LP_BIT_XN = 15,
    L2D_LP_BIT_PA = 16,

    // for small page
    L2D_SP_FIXED = 0x2,
    L2D_SP_FIXED_MASK = 0x2,
    L2D_SP_BIT_XN = 0,
    L2D_SP_BIT_B = 2,
    L2D_SP_BIT_C = 3,
    L2D_SP_BIT_AP0 = 4,
    L2D_SP_BIT_AP1 = 5,
    L2D_SP_BIT_TEX = 6,
    L2D_SP_BIT_TEX_WIDTH = 3,
    L2D_SP_BIT_AP2 = 9,
    L2D_SP_BIT_S = 10,
    L2D_SP_BIT_nG = 11, // not Global
    L2D_SP_BIT_PA = 12,
};

///
/// Translation the attribute from kernel
///

static const unsigned char tr_ap[] = {
    [MAP_AP_KRW_UNA] = AP_PRW_UNA,
    [MAP_AP_KRW_URO] = AP_PRW_URO,
    [MAP_AP_KRW_URW] = AP_PRW_URW,
    [MAP_AP_KRO_UNA] = AP_PRO_UNA,
    [MAP_AP_KRO_URO] = AP_PRO_URO,
};

// common bit index in L1 Sections and L2 Small Pages
struct bit_index
{
    unsigned char ap0, ap1, ap2;
    unsigned char tex, c, b;
    unsigned char s, xn, ng;
};

const struct bit_index bitindexs[] = {
    // L1 Section Descriptor Bit Index
    [0] = {
        .ap0 = L1D_SECs_BIT_AP0,
        .ap1 = L1D_SECs_BIT_AP1,
        .ap2 = L1D_SECs_BIT_AP2,
        .tex = L1D_SECs_BIT_TEX,
        .c = L1D_SECs_BIT_C,
        .b = L1D_SECs_BIT_B,
        .s = L1D_SECs_BIT_S,
        .xn = L1D_SECs_BIT_XN,
        .ng = L1D_SECs_BIT_nG,
    },

    // L2 Small Page Bit Index
    [1] = {
        .ap0 = L2D_SP_BIT_AP0,
        .ap1 = L2D_SP_BIT_AP1,
        .ap2 = L2D_SP_BIT_AP2,
        .tex = L2D_SP_BIT_TEX,
        .c = L2D_SP_BIT_C,
        .b = L2D_SP_BIT_B,
        .s = L2D_SP_BIT_S,
        .xn = L2D_SP_BIT_XN,
        .ng = L2D_SP_BIT_nG,
    },
};

static inline unsigned int attr_get_ap(unsigned int attr)
{
    assert(sizeof(tr_ap) / sizeof(tr_ap[0]) == MAP_AP_COUNT);
    return tr_ap[attr & MAP_AP_MASK];
}

static unsigned long trans_attr(unsigned long attr, const struct bit_index *const bi)
{
    unsigned long ret = 0;
    unsigned long tmp;
    unsigned long type = attr & MAP_TYPE_MASK;

    // setup access permission
    tmp = attr_get_ap(attr);
    ret |= (tmp & 0x1) << bi->ap0;
    ret |= ((tmp >> 1) & 0x1) << bi->ap1;
    ret |= ((tmp >> 2) & 0x1) << bi->ap2;

    if (!(attr & MAP_FLAG_EXECUTABLE))
        ret |= bitmask(bi->xn);

    // setup extra attribute
    if (type == MAP_TYPE_DEVICE)
    {
        if (attr & MAP_FLAG_SHAREABLE)
            // shareable device tex:c:b = 0:0:1
            ret |= 1 << bi->b;
        else
            // non-shareable device tex:c:b = 2:0:0
            ret |= 2 << bi->tex;
    }
    else
    {
        // Inner and Outer Write-Back, Write-Allocate, S bit
        // tex:c:b = 0b101:0:1
        ret |= (5 << bi->tex) | (1 << bi->b);
        if (attr & MAP_FLAG_SHAREABLE)
            ret |= bitmask(bi->s);
    }

    if (!(attr & MAP_FLAG_GLOBAL))
        ret |= bitmask(bi->ng);

    return ret;
}

static unsigned long sections_trans_attr(unsigned long attr)
{
    unsigned long ret = trans_attr(attr, &bitindexs[0]);

    // setup privileged executable attribute
    if ((attr & MAP_AP_MASK) == AP_PRW_URW)
        ret |= bitmask(L1D_SECs_BIT_PXN);

    return ret;
}

static inline unsigned long page_trans_attr(unsigned long attr)
{
    return trans_attr(attr, &bitindexs[1]);
}

///
/// Map implementation
///

static unsigned long entry_sec2sp(unsigned long e)
{
    unsigned long ret = e & ~lowbitsmask(L1D_SEC_BIT_PA);

    ret |= L2D_SP_FIXED;
    ret |= bitfield_get(e, L1D_SECs_BIT_AP0, 1) << L2D_SP_BIT_AP0;
    ret |= bitfield_get(e, L1D_SECs_BIT_AP1, 1) << L2D_SP_BIT_AP1;
    ret |= bitfield_get(e, L1D_SECs_BIT_AP2, 1) << L2D_SP_BIT_AP2;
    ret |= bitfield_get(e, L1D_SECs_BIT_B, 1) << L2D_SP_BIT_B;
    ret |= bitfield_get(e, L1D_SECs_BIT_S, 1) << L2D_SP_BIT_S;
    ret |= bitfield_get(e, L1D_SECs_BIT_C, 1) << L2D_SP_BIT_C;
    ret |= bitfield_get(e, L1D_SECs_BIT_TEX, L1D_SECs_BIT_TEX_WIDTH) << L2D_SP_BIT_TEX;
    ret |= bitfield_get(e, L1D_SECs_BIT_XN, 1) << L2D_SP_BIT_XN;
    ret |= bitfield_get(e, L1D_SECs_BIT_nG, 1) << L2D_SP_BIT_nG;

    return ret;
}

static int pt_map(page_table_t *pd, unsigned long *pbase, unsigned long *vbase, unsigned long *size, unsigned int attr)
{
    unsigned int l1index;
    unsigned int entries;
    unsigned long value;

    dprintf("Map PT: %x -> %x, %d bytes\n", *vbase, *pbase, *size);
    entries = *size / L2PT_SIZE;
    l1index = *vbase >> L1PT_INDEX_BEGIN;

    if (*size == 0 || *size % L2PT_SIZE != 0 || (*pbase & lowbitsmask(L1D_PT_BIT_PA)) != 0 || (*vbase & lowbitsmask(L1PT_INDEX_BEGIN)) != 0 || l1index + entries > L1PT_ENTRIES)
        return -EINVALID;

    while (entries > 0)
    {
        value = pd->entry[l1index];

        // if the entry point to a valid PageTable, then failed
        if ((value & L1D_PT_FIXED) == L1D_PT_FIXED_MASK)
            return -EINVALID;

        // if the entry point to a Section, fill L2PD according the entry
        if ((value & L1D_SEC_FIXED_MASK) == L1D_SEC_FIXED)
        {
            int i = 0;
            unsigned long *e = (void *)allocator_vbase(*pbase);
            unsigned long fill = entry_sec2sp(value);

            while (i < L2PT_ENTRIES)
            {
                e[i] = fill;
                fill += PAGE_SIZE;
                i++;
            }

            // clean the TLB entries
            scr_invalidate_tlb_mva(l1index << L1PT_INDEX_BEGIN, /*SECTION_SIZE*/ 4096);
        }
        else
            ks_memset((void *)allocator_vbase(*pbase), 0, L2PT_SIZE);

        value = *pbase | L1D_PT_FIXED;
        if (!(attr & MAP_FLAG_EXECUTABLE))
            value |= bitmask(L1D_PT_BIT_PXN);
        pd->entry[l1index] = value;

        l1index++;
        *pbase += L2PT_SIZE;
        entries--;
    }
    return ESUCCESS;
}

static int pt_map_kernel(page_table_t *pd, unsigned long *ppbase, unsigned long *pvbase, unsigned long *psize, unsigned int attr)
{
    unsigned int l1index;
    unsigned int entries;
    unsigned long value;

    dprintf("Map PT: %x -> %x, %d bytes\n", *pvbase, *ppbase, *psize);
    entries = *psize / L2PT_SIZE;
    l1index = *pvbase >> L1PT_INDEX_BEGIN;

    if (*psize == 0 || *psize % L2PT_SIZE != 0 || (*ppbase & lowbitsmask(L1D_PT_BIT_PA)) != 0 || (*pvbase & lowbitsmask(L1PT_INDEX_BEGIN)) != 0 || l1index + entries > L1PT_ENTRIES)
        return -EINVALID;

    while (entries > 0)
    {
        value = pd->entry[l1index];

        // if the entry point to a valid PageTable, then failed
        if ((value & L1D_PT_FIXED) == L1D_PT_FIXED_MASK)
            return -EINVALID;

        // if the entry point to a Section, fill L2PD according the entry
        if ((value & L1D_SEC_FIXED_MASK) == L1D_SEC_FIXED)
        {
            int i = 0;
            unsigned long *e = (void *)allocator_vbase(*ppbase);
            unsigned long fill = entry_sec2sp(value);

            while (i < L2PT_ENTRIES)
            {
                e[i] = fill;
                fill += PAGE_SIZE;
                i++;
            }

            // clean the TLB entries
            scr_invalidate_tlb_mva(l1index << L1PT_INDEX_BEGIN, /*SECTION_SIZE*/ 4096);
        }
        else
            ks_memset((void *)allocator_vbase(*ppbase), 0, L2PT_SIZE);

        value = *ppbase | L1D_PT_FIXED;
        if (!(attr & MAP_FLAG_EXECUTABLE))
            value |= bitmask(L1D_PT_BIT_PXN);
        pd->entry[l1index] = value;
        dprintf("Map PT pd->entry[0x%x]=%x\n", l1index, value);

        l1index++;
        *ppbase += L2PT_SIZE;
        entries--;
    }
    return ESUCCESS;
}
unsigned long vir_to_phy(page_table_t *pd, unsigned long vbase)
{
    // dprintf("vir_to_phy \n");
    unsigned int l1index;
    unsigned long entry;
    unsigned long vb = vbase;
    unsigned long tem = 0;
    unsigned int offset;
    l1index = vbase >> L1PT_INDEX_BEGIN;
    entry = pd->entry[l1index];

    if ((entry & L1D_SEC_FIXED_MASK) == L1D_SEC_FIXED)
    {
        offset = vbase & (~0xfff00000);
        // dprintf("offset: %x\n", offset);
        // dprintf("vir_to_phy a section: %x -> ", vbase);
        // if((vbase & lowbitsmask(SECTION_SIZE_SHIFT)) != 0)
        //     return -EINVALID;
        tem = (pd->entry[l1index] & 0xfff00000) + offset;
    }
    else if ((entry & L1D_PT_FIXED_MASK) == L1D_PT_FIXED)
    {
        unsigned long *l2e = (void *)allocator_vbase(entry & ~lowbitsmask(L1D_PT_BIT_PA));
        unsigned int l2index = bitfield_get(vbase, L2PT_INDEX_BEGIN, L2PT_INDEX_WIDTH);

        // dprintf("offset: %x\n", offset);
        // dprintf("vir_to_phy a pt: %x -> ", vbase);
        if (l2index < L2PT_ENTRIES)
        {
            offset = vbase & (~0xfffff000);
            tem = (l2e[l2index] & 0xfffff000) + offset;
        }
        //dprintf("l2e %x\n",l2e);
    }
    else
    {
        // we don't use supper section, so do nothing here
    }
    dprintf("%x\n", tem);
    // clean the TLB entries
    scr_invalidate_tlb_mva(vb, vbase - vb);
    scr_clean_data_cache();

    return tem;
}
static int page_map(page_table_t *pd, unsigned long *pbase, unsigned long *vbase, unsigned long *size, unsigned int attr)
{
    unsigned long vb = *vbase;

    dprintf("Map address: %x -> %x, %d bytes\n", *pbase, *vbase, *size);

    if ((*size & lowbitsmask(PAGE_SIZE_SHIFT)) > 0 || (*vbase & lowbitsmask(PAGE_SIZE_SHIFT)) > 0 || (*pbase & lowbitsmask(L2D_SP_BIT_PA)) > 0)
    {
        dprintf("map error11\n");
        return -EINVALID;
    }

    while (*size > 0)
    {
        unsigned int l1index = *vbase >> L1PT_INDEX_BEGIN;

        // if the size >= 1MB, then check if we can map it by sections
        if (*size >= SECTION_SIZE && (*vbase & lowbitsmask(SECTION_SIZE_SHIFT)) == 0 && (*pbase & lowbitsmask(L1D_SEC_BIT_PA)) == 0)
        {
            pd->entry[l1index] = (*pbase) | L1D_SEC_FIXED | sections_trans_attr(attr);
            *vbase += SECTION_SIZE;
            *pbase += SECTION_SIZE;
            *size -= SECTION_SIZE;
            //dprintf("l1index:0x%x,pd->entry[l1index]:0x%x\n",l1index,pd->entry[l1index]);
        }
        else
        {
            unsigned long *l2e = (void *)allocator_vbase(pd->entry[l1index] & ~lowbitsmask(L1D_PT_BIT_PA));
            unsigned int l2index = bitfield_get(*vbase, L2PT_INDEX_BEGIN, L2PT_INDEX_WIDTH);

            if ((pd->entry[l1index] & L1D_PT_FIXED_MASK) != L1D_PT_FIXED)
            {
                // dprintf("(pd->entry[l1index] & L1D_PT_FIXED_MASK) != L1D_PT_FIXED\n");
                return -ENOL2PT;
            }

            l2e[l2index] = (*pbase) | L2D_SP_FIXED | page_trans_attr(attr);
            *vbase += PAGE_SIZE;
            *pbase += PAGE_SIZE;
            *size -= PAGE_SIZE;
            //dprintf("l2e:0x%x,l2index:0x%x,l2e[l2index]:0x%x\n",(uint32_t)l2e,l2index,l2e[l2index]);
        }
    }

    // clean the TLB entries
    scr_invalidate_tlb_mva(vb, (*vbase) - vb);
    scr_clean_data_cache();

    return ESUCCESS;
}

static int page_map_kernel(page_table_t *pd, unsigned long *ppbase, unsigned long *pvbase, unsigned long *psize, unsigned int attr)
{
    unsigned long vb = *pvbase;

    dprintf("page Map address: %x -> %x, %d bytes\n", *ppbase, *pvbase, *psize);

    if ((*psize & lowbitsmask(PAGE_SIZE_SHIFT)) > 0 || (*pvbase & lowbitsmask(PAGE_SIZE_SHIFT)) > 0 || (*ppbase & lowbitsmask(L2D_SP_BIT_PA)) > 0)
    {
        dprintf("map error\n");
        return -EINVALID;
    }

    while (*psize > 0)
    {
        unsigned int l1index = *pvbase >> L1PT_INDEX_BEGIN;
        unsigned long *l2e = (void *)allocator_vbase(pd->entry[l1index] & ~lowbitsmask(L1D_PT_BIT_PA));
        unsigned int l2index = bitfield_get(*pvbase, L2PT_INDEX_BEGIN, L2PT_INDEX_WIDTH);

        if ((pd->entry[l1index] & L1D_PT_FIXED_MASK) != L1D_PT_FIXED)
        {
            scr_invalidate_tlb_mva(vb, (*pvbase) - vb);
            scr_clean_data_cache();
            //dprintf("(pd->entry[0x%x] %x & L1D_PT_FIXED_MASK) != L1D_PT_FIXED,vbase 0x%x\n",l1index,pd->entry[l1index],*pvbase);
            return -ENOL2PT;
        }

        l2e[l2index] = *ppbase | L2D_SP_FIXED | page_trans_attr(attr);
        *pvbase += PAGE_SIZE;
        *ppbase += PAGE_SIZE;
        *psize -= PAGE_SIZE;
        //dprintf("l2e:0x%x,l2index:0x%x,l2e[l2index]:0x%x\n",(uint32_t)l2e,l2index,l2e[l2index]);
    }

    // clean the TLB entries
    scr_invalidate_tlb_mva(vb, (*pvbase) - vb);
    scr_clean_data_cache();

    return ESUCCESS;
}

int page_unmap(page_table_t *pd, unsigned long *vbase, unsigned long *size)
{
    unsigned int l1index;
    unsigned long entry;
    unsigned long vb = *vbase;

    if ((*size & lowbitsmask(PAGE_SIZE_SHIFT)) != 0 || (*vbase & lowbitsmask(PAGE_SIZE_SHIFT)) != 0)
        return -EINVALID;

    while (*size > 0)
    {
        l1index = *vbase >> L1PT_INDEX_BEGIN;
        entry = pd->entry[l1index];

        if ((entry & L1D_SEC_FIXED_MASK) == L1D_SEC_FIXED)
        {
            if (*size < SECTION_SIZE || (*vbase & lowbitsmask(SECTION_SIZE_SHIFT)) != 0)
                return -EINVALID;

            pd->entry[l1index] = L1D_INVALID;

            *vbase += SECTION_SIZE;
            *size -= SECTION_SIZE;
        }
        else if ((entry & L1D_PT_FIXED_MASK) == L1D_PT_FIXED)
        {
            unsigned long *l2e = (void *)allocator_vbase(entry & ~lowbitsmask(L1D_PT_BIT_PA));
            unsigned int l2index = bitfield_get(*vbase, L2PT_INDEX_BEGIN, L2PT_INDEX_WIDTH);

            while (*size > 0 && l2index < L2PT_ENTRIES)
            {
                l2e[l2index] = L2D_INVALID;

                *vbase += PAGE_SIZE;
                *size -= PAGE_SIZE;
                l2index++;
            }
        }
        else
        {
            // we don't use supper section, so do nothing here
            *size -= (*size >= SECTION_SIZE) ? SECTION_SIZE : *size;
        }
    }

    // clean the TLB entries
    scr_invalidate_tlb_mva(vb, (*vbase) - vb);
    scr_clean_data_cache();

    return ESUCCESS;
}

unsigned long page_table_missing_pt(page_table_t *pd, unsigned long *vbase, unsigned long *size, unsigned int level)
{
    int l1index = (*vbase) >> L1PT_INDEX_BEGIN;
    int l1end = ((*vbase) + (*size) - 1) >> L1PT_INDEX_BEGIN;
    int count = (l1end >= l1index) ? (l1end - l1index + 1) : 0;
    dprintf("page_table_missing_pt l1index, l1end count %d, %d, %d\n", l1index, l1end, count);
    if (level != 2)
        return 0;

    while (count > 0)
    {
        if ((pd->entry[l1index] & L1D_PT_FIXED_MASK) != L1D_PT_FIXED)
        {
            // dprintf("page_table_missing_pt l1index << L1PT_INDEX_BEGIN\n");
            return l1index << L1PT_INDEX_BEGIN;
        }

        l1index++;
        count--;
    }

    return 0;
}

void page_table_recycle(page_table_t *u, page_table_t *k)
{
    int i;
    unsigned long block;

    for (i = 0; i < L1PT_ENTRIES; i++)
    {
        // don't free the L2PT in kernel space
        if ((u->entry[i] & L1D_PT_FIXED_MASK) != L1D_PT_FIXED || u->entry[i] == k->entry[i])
            continue;

        // free the L2PT
        block = allocator_vbase(u->entry[i] & ~lowbitsmask(L1D_PT_BIT_PA));
        if (allocator_free(block, L2PT_SIZE) != 0)
            dprintf("Memory Leaked at 0x%x, total %d bytes!\n", block, L2PT_SIZE);
    }
}

int page_table_map(page_table_t *pd, unsigned long *pbase, unsigned long *vbase, unsigned long *size, unsigned int attr)
{
    unsigned int ptl = attr & MAP_PTL_MASK;

    if (ptl == MAP_PTL_L2)
        return pt_map(pd, pbase, vbase, size, attr);
    else if (ptl == MAP_PTL_PAGES)
        return page_map(pd, pbase, vbase, size, attr);
    else
        return -EINVALID;
}

int page_table_map_kernel(page_table_t *pd, unsigned long *ppbase, unsigned long *pvbase, unsigned long *psize, unsigned int attr)
{
    unsigned int ptl = attr & MAP_PTL_MASK;

    if (ptl == MAP_PTL_L2)
        return pt_map_kernel(pd, ppbase, pvbase, psize, attr);
    else if (ptl == MAP_PTL_PAGES)
        return page_map_kernel(pd, ppbase, pvbase, psize, attr);
    else
        return -EINVALID;
}

#ifdef DEBUG_DUMP_KERNEL_SPACE
static void dump_l2pd(page_table_t *pd, unsigned int index)
{
    unsigned long *entry = (void *)allocator_vbase(pd->entry[index] & ~lowbitsmask(L1D_PT_BIT_PA));
    int i = 0;

    dprintf(" -- %x\n", entry);
    for (; i < L2PT_ENTRIES; i++)
    {
        if (entry[i] != 0)
            dprintf(" --[%d] = %x\n", i, entry[i]);
    }
}

static void dump_l1pd(page_table_t *pd)
{
    int i = 0;

    for (; i < L1PT_ENTRIES; i++)
    {
        if (pd->entry[i] != 0)
        {
            dprintf(" [%d] = %x\n", i, pd->entry[i]);
            if (((unsigned long)pd->entry[i] & L1D_PT_FIXED_MASK) == L1D_PT_FIXED)
            {
                dump_l2pd(pd, i);
            }
        }
    }
}
#endif // DEBUG_DUMP_KERNEL_SPACE

// todo: manage asid pool
unsigned int asid = 1;

void page_table_switch_to(page_table_t *pd, page_table_t *useless)
{
    //dprintf("in %s,file:%s,line:%d\n",__FUNCTION__,__FILE__,__LINE__);
    unsigned long base = allocator_pbase((unsigned long)pd);

    //dprintf("in %s,file:%s,line:%d\n",__FUNCTION__,__FILE__,__LINE__);
    // scr_clean_data_cache();
    scr_write_CONTEXTIDR(0);
    dsb();
    //dprintf("in %s,file:%s,line:%d\n",__FUNCTION__,__FILE__,__LINE__);
    //scr_write_TTBR0(base | bitmask(SCR_TTBRx_BIT_S));
    scr_write_TTBR0(base | 1ul << 1 | 1ul << 6 | 1ul << 0 | 1ul << 5);
    isb();
    //dprintf("in %s,file:%s,line:%d\n",__FUNCTION__,__FILE__,__LINE__);
    scr_write_CONTEXTIDR(asid & 0xff);
    dsb();
    // clean the old entries
    //dprintf("in %s,file:%s,line:%d\n",__FUNCTION__,__FILE__,__LINE__);
    scr_invalidate_tlb_all();
    isb();
    dsb();
    //dprintf("in %s,file:%s,line:%d\n",__FUNCTION__,__FILE__,__LINE__);
    // update ASID for next change
    ++asid;
    if (asid == 0xff)
        asid = 1;

#ifdef DEBUG_DUMP_KERNEL_SPACE
    dprintf("Addrspace switch to %x(vaddr: %x)\n", base, (unsigned long)pd);
    dprintf("sctlr = %x, ttbr0 = %x, ttbcr = %x\n", scr_read_SCTLR(),
            scr_read_TTBR0(), scr_read_TTBCR());
    dump_l1pd(pd);
#endif
}

void dump_current_pd(void)
{
#ifdef DEBUG_DUMP_KERNEL_SPACE
    unsigned long base = scr_read_TTBR0() & ~0x3ff;

    dprintf("PT BASE: %x\n", base);
    dprintf("PT VBASE: %x\n", base - CONFIG_LOAD_ADDR + CONFIG_EXEC_ADDR);
    dump_l1pd((void *)(base - CONFIG_LOAD_ADDR + CONFIG_EXEC_ADDR));
#endif
}

// Boot Code

void BOOTONLY page_table_active(page_table_t *pd)
{
    dprintf("in %s\n", __FUNCTION__);
    page_table_switch_to(pd, 0);

#ifdef DEBUG_DUMP_KERNEL_SPACE
    dprintf("Active page table %x with DACR 0x%x!\n", pd, scr_read_DACR());
    dprintf("sctlr = %x, ttbr0 = %x, ttbcr = %x\n", scr_read_SCTLR(),
            scr_read_TTBR0(), scr_read_TTBCR());
    dump_l1pd(pd);
#endif

    // clean the old entries
    scr_invalidate_tlb_all();
    isb();
    dsb();
}

static BOOTDATA page_table_t _bootpd;
static BOOTDATA unsigned long _l2pt[L2PT_ENTRIES];

static void BOOTPHYSIC init_boot_pd(void)
{
    extern const region_t ksram[];
    extern const region_t ksdev[];
    extern unsigned long boot_physic_end;

    const region_t *pksram = (void *)ksram - CONFIG_EXEC_ADDR + CONFIG_LOAD_ADDR;
    const region_t *pksdev = (void *)ksdev - CONFIG_EXEC_ADDR + CONFIG_LOAD_ADDR;

    page_table_t *bootpd = (void *)&_bootpd - CONFIG_EXEC_ADDR + CONFIG_LOAD_ADDR;
    unsigned long *l2pt = (void *)_l2pt - CONFIG_EXEC_ADDR + CONFIG_LOAD_ADDR;

    int l1index;
    int l2index;
    unsigned long pbase;
    int count;

    for (l1index = 0; l1index < L1PT_ENTRIES; l1index++)
        bootpd->entry[l1index] = L1D_INVALID;

    for (l2index = 0; l2index < L2PT_ENTRIES; l2index++)
        l2pt[l2index] = L2D_INVALID;

    // map the .boot.physic to physical memory
    l1index = CONFIG_LOAD_ADDR >> L1PT_INDEX_BEGIN;                                                        //0x2000_0000 >> 20 = 0x200
    count = ((unsigned long)&boot_physic_end - CONFIG_EXEC_ADDR + SECTION_SIZE - 1) >> SECTION_SIZE_SHIFT; //计算boot大概有多少M
    pbase = CONFIG_LOAD_ADDR;
    while (count > 0)
    {
        bootpd->entry[l1index] = pbase | L1D_SEC_FIXED | bitmask(L1D_SECs_BIT_nG) | (0x15404);

        l1index++;
        pbase += SECTION_SIZE;
        count--;
    }

    // map the ram of kernel
    while (pksram->size > 0)
    {
        l1index = pksram->vbase >> L1PT_INDEX_BEGIN;
        count = pksram->size >> SECTION_SIZE_SHIFT;
        pbase = pksram->pbase;
        while (count > 0)
        {
            bootpd->entry[l1index] = pbase | L1D_SEC_FIXED | (0x15404);

            l1index++;
            pbase += SECTION_SIZE;
            count--;
        }

        pksram++;
    }

    // map the L2PT for kernel devices
    l1index = CONFIG_KDEV_ADDR >> L1PT_INDEX_BEGIN;
    bootpd->entry[l1index] = (unsigned long)l2pt | L1D_PT_FIXED | (0x0);

    // map the device of kernel
    while (pksdev->size > 0)
    {
        l2index = (pksdev->vbase >> L2PT_INDEX_BEGIN) & lowbitsmask(L2PT_INDEX_WIDTH);
        count = pksdev->size / PAGE_SIZE;
        pbase = pksdev->pbase;
        while (count > 0)
        {
            l2pt[l2index] = pbase | L2D_SP_FIXED | (0x14);

            l2index++;
            pbase += PAGE_SIZE;
            count--;
        }

        pksdev++;
    }
}

void BOOTPHYSIC setup_mmu(int coreid)
{
    unsigned long value;
    page_table_t *pd = (void *)&_bootpd - CONFIG_EXEC_ADDR + CONFIG_LOAD_ADDR;

    if (coreid == 0)    //主核
        init_boot_pd(); //boot代码，ram地址，设备地址，设置映射表

    // pd is PA when boot
    assert(((unsigned long)pd & lowbitsmask(SCR_TTBRx_BIT_BASEADDR)) == 0); //地址是否16k对其

    // disable EAE and set N to 0
    scr_write_TTBCR(0);

    // enable access permission check
    scr_write_DACR(0x55555555);

    // invalide all tlbs
    scr_invalidate_tlb_all();

    scr_write_CONTEXTIDR(0xff);

    // Non-Cacheable, Shareable
    value = (unsigned long)pd;
    scr_write_TTBR0(value | bitmask(SCR_TTBRx_BIT_S));

    value = scr_read_SCTLR();
    value &= ~bitmask(SCR_SCTLR_BIT_AFE);
    value &= ~bitmask(SCR_SCTLR_BIT_TRE);
    value |= bitmask(SCR_SCTLR_BIT_A);
    scr_write_SCTLR(value);
    isb();
}
