#include <dprintf.h>
#include <halt.h>
#include <fault.h>
#include <interrupt.h>
#include <syscall.h>

#include <armv7-a/context.h>
#include <armv7-a/scr.h>

#include <arch/exception.h>
#include <arch/cpsr.h>

#include <plat/irqn.h>

void undef_traps_entry(void)
{
    dprintf("Undefied Instruction Detected!\n");
    scr_report_ins_fault();
    hardfault_handler(FAULT_INS, scr_read_IFSR(), scr_read_IFAR());

    context_restore_current();
}

void abort_traps_entry(unsigned long type, unsigned long spsr, void *pc)
{
    unsigned long mode = spsr & MODE_MASK;
    unsigned long ftype;
    unsigned long status, addr;

    dprintf("%s Abort @%X in mode %x!\n", type != 0 ? "Prefetech" : "Data", pc, mode);

    if (type != 0)
    {
        scr_report_ins_fault();
        ftype = FAULT_INS;
        status = scr_read_IFSR();
        addr = scr_read_IFAR();
    }
    else
    {
        scr_report_data_fault();
        ftype = FAULT_DATA;
        status = scr_read_DFSR();
        addr = scr_read_DFAR();
    }

    if (mode != MODE_User)
        halt();
    else
        hardfault_handler(ftype, status, addr);

    context_restore_current();
}

//#define ENABLE_PERFORMANT_TEST
// CAUTIONS: change the arch/arm/armv7-a/vector.s#40 to call syscall_handler_trap()
// when measure the perfomance of SVC.
#define PERFORMANCE_COUNTER_INCREASE
#ifdef ENABLE_PERFORMANT_TEST
#define ENABLE_PERFORMANT_TEST_SVC
//#define ENABLE_PERFORMANT_TEST_IRQ

static inline unsigned long ts(void)
{
#if 1
    // PMU cycle counter, ARMv7-a
    unsigned long ret;
    __asm__ __volatile__("mrc p15, 0, %0, c9, c13, 0\n"
                         : "=r"(ret)
                         :);
    return ret;
#else
    // systick counter, ARMv7-M
    return *(volatile uint32_t *)0xE000E018;
#endif
}
#endif

void irq_traps_entry(void)
{
#ifdef ENABLE_PERFORMANT_TEST_IRQ
    unsigned long begin = ts();
    unsigned long end;
    static unsigned long tscount = 0;
    static unsigned long tss = 0;
    static unsigned long max = 0;
#endif
    unsigned int irq = exception_current_irq();
    if (irq == 87)
    {
        dprintf("irq = %d \n", irq);
    }
    irq_handler_entry(irq);

#ifdef ENABLE_PERFORMANT_TEST_IRQ
    end = ts();
#ifdef PERFORMANCE_COUNTER_INCREASE
    {
        unsigned long tmp = end;
        end = begin;
        begin = tmp;
    }
#endif
    if (begin > end && irq != CONFIG_IRQN_SYSTICK)
    {
        tscount++;
        tss += begin - end;

        if (begin - end > max)
            max = begin - end;

        if (tscount % 5 == 0)
        {
            dprintf("%s(): count = %d, total = %d, avr = %d, max = %d\n", __FUNCTION__,
                    tscount, tss, tss / tscount, max);
        }
    }
#endif

    context_restore_current();
}

void syscall_handler_trap(unsigned long a0, unsigned long a1, unsigned long a2, unsigned long a3)
{
#ifdef ENABLE_PERFORMANT_TEST_SVC
    unsigned long begin = ts();
    unsigned long end;
    static unsigned long tscount = 0;
    static unsigned long tss = 0;
    static unsigned long max = 0;
#endif

    syscall_handler(a0, a1, a2, a3);

#ifdef ENABLE_PERFORMANT_TEST_SVC
    end = ts();
#ifdef PERFORMANCE_COUNTER_INCREASE
    {
        unsigned long tmp = end;
        end = begin;
        begin = tmp;
    }
#endif
    if (begin > end && begin - end < 10000)
    {
        tscount++;
        tss += begin - end;

        if (begin - end > max)
            max = begin - end;

        if (tscount % 5 == 0)
        {
            dprintf("%s(): count = %d, total = %d, avr = %d, max = %d\n", __FUNCTION__,
                    tscount, tss, tss / tscount, max);
        }
    }
#endif
}
