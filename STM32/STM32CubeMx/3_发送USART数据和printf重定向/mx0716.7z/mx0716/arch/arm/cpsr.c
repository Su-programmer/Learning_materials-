#include <stdlib/assert.h>

#include <tools/macros.h>

#include <dprintf.h>

#include <cpsr.h>

static const char* const names[] = {
    [MODE_User] = "User",
    [MODE_FIQ] = "FIQ",
    [MODE_IRQ] = "IRQ",
    [MODE_Supervisor] = "Supervisor",
    [MODE_Monitor] = "Monitor",
    [MODE_Abort] = "Abort",
    [MODE_Hyp] = "Hyp",
    [MODE_Undefined] = "Undefined",
    [MODE_System] = "System",
};

const char* cpsr_mode_name(unsigned int mode)
{
    assert(mode <= (sizeof(names)/sizeof(names[0])) && names[mode] != 0);
    return names[mode];
}

void cpsr_dump_info(void)
{
    unsigned long value = cpsr_read();

    dprintf("CPSR: %x\n", value);
    dprintf("  Endian: %s\n", (value & bitmask(CPSR_BIT_E)) > 0 ? "Big" : "Little");
    dprintf("  Asynchronous Abort: %s\n", (value & bitmask(CPSR_BIT_A)) > 0 ? "Masked" : "Enabled");
    dprintf("  IRQ: %s, FIQ: %s\n", (value & bitmask(CPSR_BIT_I)) > 0 ? "Masked" : "Enabled",
        (value & bitmask(CPSR_BIT_F)) > 0 ? "Masked" : "Enabled");
    dprintf("  Jazelle: %s, Thumb: %s\n", (value & bitmask(CPSR_BIT_J)) > 0 ? "Yes" : "No",
        (value & bitmask(CPSR_BIT_T)) > 0 ? "Yes" : "No");
    dprintf("  Mode: %s\n", cpsr_mode_name((value >> CPSR_BIT_MODE) & lowbitsmask(CPSR_BIT_MODE_WIDTH)));
}

int cpsr_change_mode(unsigned int mode)
{
    unsigned long value;

    assert(mode <= (sizeof(names)/sizeof(names[0])) && names[mode] != 0);

    __asm__ __volatile__(
        "mrs %0, cpsr\n\t"
        "and %0, %0, %2\n\t"
        "orr %0, %0, %1\n\t"
        "msr cpsr, %0\n\t"
        :"=r"(value)
        :"r"(mode), "r"(lowbitsmask(CPSR_BIT_MODE_WIDTH))
    );

    return cpsr_current_mode() != mode;
}

void cpsr_enable_int(void)
{
    unsigned int mask = bitmask(CPSR_BIT_A) | bitmask(CPSR_BIT_I) | bitmask(CPSR_BIT_F);
    unsigned long value;

    mask = ~mask;

    __asm__ __volatile__(
        "mrs %0, cpsr\n\t"
        "and %0, %0, %1\n\t"
        "msr cpsr, %0\n\t"
        :"=r"(value)
        :"r"(mask)
    );
}
