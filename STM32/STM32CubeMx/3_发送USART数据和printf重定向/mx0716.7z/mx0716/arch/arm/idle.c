#include <idle.h>
#include <dprintf.h>
//#include <plat/device.h>
#if 1
#define DEVICE_VBASE_TIMER  (0xFFF01c00)

typedef unsigned int u32;


/* General purpose timer */
struct sunxi_timer {
        volatile u32 ctl;
        volatile u32 inter;  //保存计数值
        volatile u32 val;    //累计器
        unsigned int res[1];
};

/* Audio video sync*/
struct sunxi_avs {
        volatile u32 ctl;               /* 0x80 */
        volatile u32 cnt0;              /* 0x84 */
        volatile u32 cnt1;              /* 0x88 */
        volatile u32 div;               /* 0x8c */
};

/* Watchdog */
struct sunxi_wdog {
        volatile u32 ctrl;
        volatile u32 mode;

};

struct sunxi_timer_reg {
        volatile u32       tirqen;              /* 0x00 */
        volatile u32       tirqsta;     /* 0x04 */
        unsigned int       res1[2];
        struct sunxi_timer timer[6];    /* We have 6 timers */
        unsigned int       res2[4];
        struct sunxi_avs   avs;
        struct sunxi_wdog  wdog[1];
};
#endif

void idle(void)
{
    struct sunxi_timer_reg *timer_reg = (struct sunxi_timer_reg *)DEVICE_VBASE_TIMER; 
	if(0)timer_reg=timer_reg;//@SurpressWarning
    while(1)
    {
//    	dprintf("ctrl = %d\n",  timer_reg->timer[0].ctl);
        __asm("wfi");
    }

}

