#include <config.h>
#include <tools/macros.h>

#include <dprintf.h>
#include <interrupt.h>

#include <cortex-a7/cpu.h>
#include <cortex-a7/timers.h>
#include <cortex-a7/exception.h>

#include <plat/irqn.h>

#if 1
static const int sys_tick = 24;

unsigned long timer_get_left(void)
{
    return scr_read_CNTP_TVAL() / sys_tick;
}

unsigned long timer_set_next(unsigned long us)
{
    uint32_t ticks = us * sys_tick;
    if(ticks != 0){
        scr_write_CNTP_TVAL(ticks);
        pt_enable_int();
        pt_enable();
    }
    else
    {
        pt_stop();
    }

    return 0;
}

unsigned long timer_stop(void)
{
    pt_disable();
	pt_disable_int();
    pt_ack_int();

    return 0;
}


void timer_init(void)
{	
    pt_disable();
    //disable PL0 access, disable events stream
    scr_write_CNTKCTL(0);
    //set system counter, 1 MHz
    scr_write_CNTFRQ(24 * 1000000);

    pt_enable_int();
    pt_enable();
	

}

#endif
unsigned long begin;    
unsigned long end;
unsigned long tscount = 0;
unsigned long tss = 0;
unsigned long max = 0;

void count_start()
{
    timer_set_next(1000000);    
    begin = timer_get_left();/* 读取当前定时器的tick */

}

void count_end()
{
    end = timer_get_left();/* 读取当前定时器的tick */
    //timer_disable();
    if(end < begin)   
    {
        tscount++;  
        tss += begin - end;   
        if(begin - end > max)                 
            max = begin - end;     
        if(tscount % 5 == 0)                  
        {
            dprintf("count end: count = %d, total = %d, avr = %d, max = %d\n",
                tscount, tss, tss/tscount, max);
        }
    } 
}




